package generated.de.thb.dim.pizzaPronto.u2;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.Period;

/**
 * CustomerVO represents objects of customer.
 * @author Robert Fischer, Gabriele Schmidt
 * @version 3.0
 */
public class CustomerVO {

    private static int nextId = 0;

    private int id;

    private String lastName;

    private String firstName;

    private String gender;

    private LocalDate dateOfBirth;

    /**
     * initializing constructor
     * Initialize all instance attributes with values.
     *
     * @param lastName - Customer's second name
     * @param firstName - Customer's first name
     * @param gender - Customer's gender
     * @param dateOfBirth - Customer's date of birth
     */
    public CustomerVO(String lastName, String firstName, String gender, LocalDate dob) {
        id = nextId;
        nextId++;
        setLastName(lastName);
        setFirstName(firstName);
        setGender(gender);
        setDateOfBirth(dob);
    }

    public CustomerVO(String lastName) {
        this(lastName, null, null, null);
    }

    public CustomerVO(String lastName, String firstName) {
        this(lastName, firstName, null, null);
    }

    public CustomerVO(String lastName, String firstName, String gender) {
        this(lastName, firstName, gender, null);
    }

    /**
     * default constructor
     * calls initializing constructor with default values for instance attributes
     */
    public CustomerVO() {
        this(null, null, null, null);
    }

    /**
     * Returns the birth date in human-readable form.
     *
     * @return - the complete string
     */
    public String dobToString() {
        return dateOfBirth.format(DateTimeFormatter.ofPattern("dd MMM yyyy"));
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public LocalDate getDateOfBirth() {
        return dateOfBirth;
    }

    public void setDateOfBirth(LocalDate dob) {
        this.dateOfBirth = dob;
        if (this.calculateAge() < 18)
            this.dateOfBirth = null;
    }

    public int getNextId() {
        return nextId;
    }

    public int getId() {
        return id;
    }

    public short calculateAge() {
        short alter = -1;
        Period age;
        LocalDate today = LocalDate.now();
        if (dateOfBirth != null) {
            Period age;
            age = Period.between(dateOfBirth, today);
            alter = (short) age.getYears();
        }
        return alter;
    }

    @Override
    public String toString() {
        return "CustomerVO [" + "id= " + this.id + ",  " + "lastName= " + this.lastName + ",  " + "firstName= " + this.firstName + ",  " + "gender= " + this.gender + ",  " + "dateOfBirth= " + this.dobToString() + "  ,  " + "Age= " + this.calculateAge() + "]";
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        CustomerVO other = (CustomerVO) obj;
        return Objects.equals(lastName, other.lastName) && Objects.equals(firstName, other.firstName) && Objects.equals(gender, other.gender) && Objects.equals(dateOfBirth, other.dateOfBirth);
    }

    @Override
    public int hashCode() {
        return Objects.hash(lastName, firstName, gender, dateOfBirth);
    }
}
