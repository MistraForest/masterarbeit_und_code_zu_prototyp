// End  of class
package generated.de.thb.dim.pizzaPronto.u1;

import java.awt.Color;

/**
 * ChefVO represents the objects of chef
 * @author Robert Fischer, Gabriele Schmidt
 * @version 3.0
 */
public class ChefVO {

    private String lastName;

    private String firstName;

    private Color colorApron;

    /**
     * initializing constructor
     * Initialize all instance attributes with values.
     *
     * @param lastName - Chef's second name
     * @param firstName - Chef's first name
     * @param colorApron - Color of apron
     */
    public ChefVO(String lastName, String firstName, Color colorApron) {
        setLastName(lastName);
        setFirstName(firstName);
        setColorApron(colorApron);
    }

    public ChefVO(String lastName, String firstName) {
        this(lastName, firstName, null);
    }

    public ChefVO(String lastName) {
        this(lastName, null, null);
    }

    /**
     * default constructor
     * calls initializing constructor with default values for instance attributes
     */
    public ChefVO() {
        this(null, null, null);
    }

    // /
    // / Setter und Getter
    // /
    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public Color getColorApron() {
        return colorApron;
    }

    public void setColorApron(Color colorApron) {
        this.colorApron = colorApron;
    }
}
