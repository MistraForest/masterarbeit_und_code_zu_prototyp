package generated.de.thb.dim.pizzaPronto.u2;

/**
 * The methods of the class PizzaVO are tested.
 *
 * Special assert statements are used for testing <br>
 *
 * @author Gabriele Schmidt
 * @version 4.0 10.03.2020
 */
public class PizzaVO {

    private String name;

    private float price;

    private String[] ingredients;

    /**
     * initializing constructor
     * Initialize all instance attributes with values.
     *
     * @param name - Name of the pizza
     * @param ingredients - ingredients of the pizza
     * @param price - price  of the pizza
     */
    public PizzaVO(String name, String[] ingredients, float price) {
        setName(name);
        setIngredients(ingredients);
        setPrice(price);
    }

    public PizzaVO(String name, String[] ingredients) {
        this(name, ingredients, 0.0f);
    }

    public PizzaVO(String name) {
        this(name, null, 0.0f);
    }

    /**
     * default constructor
     * calls initializing constructor with default values for instance attributes
     */
    public PizzaVO() {
        this(null, null, 0.0f);
    }

    // /
    // / Setter und Getter
    // /
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public float getPrice() {
        return price;
    }

    public void setPrice(float price) {
        this.price = (price > 0) ? price : 0;
    }

    public String[] getIngredients() {
        return ingredients;
    }

    public void setIngredients(String[] ingredients) {
        this.ingredients = ingredients;
    }

    @Override
    public String toString() {
        return "PizzaVO [" + "name= " + this.name + ",  " + "price= " + this.price + ",  " + "ingredients= " + Arrays.toString(ingredients) + "  ]";
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        PizzaVO other = (PizzaVO) obj;
        return Objects.equals(name, other.name) && (Float.floatToIntBits(price) == Float.floatToIntBits(other.price)) && Arrays.equals(ingredients, other.ingredients);
    }

    @Override
    public int hashCode() {
        int result = 1;
        final int prime = 31;
        result = prime * result + ((name == null) ? 0 : name.hashCode());
        result = prime * result + Float.floatToIntBits(price);
        result = prime * result + Arrays.hashCode(ingredients);
        return result;
    }

    @Override
    protected PizzaVO clone() throws CloneNotSupportedException {
        return (PizzaVO) super.clone();
    }
}
