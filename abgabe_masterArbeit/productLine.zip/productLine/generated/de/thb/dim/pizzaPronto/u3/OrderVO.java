package generated.de.thb.dim.pizzaPronto;

import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * The class OrderVO contains the begin and the end, i.e. delivery, of order as
 * a date timestamp Furthermore the class provides an objectmamagement of the
 * ordered pizzas (later dishes). The order has an identifiers.
 *
 * @author Gabriele Schmidt
 * @version 2.1
 */
public class OrderVO {

    private static final int MAX_DISHES = 10;

    private static int nextOrderNo = 0;

    private int orderNo;

    private int index;

    private LocalDateTime timestampStartedOrder;

    private LocalDateTime timestampDeliveredOrder;

    private PizzaVO[] shoppingBasket;

    private CustomerVO customer;

    public OrderVO(LocalDateTime timestampStartedOrder, CustomerVO customer) {
        if (nextOrderNo == 0 || (nextOrderNo / 100000 < LocalDate.now().getYear()))
            nextOrderNo = LocalDateTime.now().getYear() * 100000;
        this.orderNo = ++nextOrderNo;
        this.setTimestampStartedOrder(timestampStartedOrder);
        this.setCustomer(customer);
        index = 0;
        shoppingBasket = new PizzaVO[MAX_DISHES];
    }

    /**
     * Methode for adding a dish to the shopping basket of OrderVO. Object is
     * inserted in the position index, if the maximum number yet was not reached.
     * index is increased even if dish is null.
     *
     * @param dish - the to be added dish, dish can be null
     */
    public void addDish(PizzaVO dish) {
        if (shoppingBasket != null) {
            if (index < MAX_DISHES) {
                // if maximum is not achieved
                // add dish at the position which is the index
                shoppingBasket[index] = dish;
                // index is incremented, maximum value is MAX_DISHES, e.g. 10
                index++;
            }
        }
    }

    /**
     * Methode for deleting the last dish from the shopping basket of OrderVO.
     *
     * @param dish - the to be deleted dish
     */
    public void deleteDish() {
        if (shoppingBasket != null) {
            if (index > 0) {
                // set object at position index - 1 null ...
                shoppingBasket[index - 1] = null;
                // decrement index, minimum value of index is 0
                this.index--;
            } else if (index == 0)
                shoppingBasket[0] = null;
        }
    }

    /**
     * Method returns the dish at the position of index.
     *
     * @param index - Index
     * @return - objects of PizzaVO later Dishes, is null if no object exists on
     *         position index
     */
    public PizzaVO getDish(int index) {
        if (shoppingBasket != null) {
            if (index < MAX_DISHES && shoppingBasket[index] != null)
                return shoppingBasket[index];
            else
                return null;
        } else
            return null;
    }

    /**
     * Method returns number of pizzas later dishes
     *
     * @return - number of pizzas
     */
    public int getNumberOfDishes() {
        // no test, the index could be wrong
        return index;
    }

    // Setter and Getter
    public PizzaVO[] getShoppingBasket() {
        return shoppingBasket;
    }

    public void setShoppingBasket(PizzaVO[] warenkorb) {
        this.shoppingBasket = warenkorb;
    }

    public int getIndex() {
        return index;
    }

    public static int getNextOrderNo() {
        return nextOrderNo;
    }

    public LocalDateTime getTimestampStartedOrder() {
        return timestampStartedOrder;
    }

    public void setTimestampStartedOrder(LocalDateTime order) {
        this.timestampStartedOrder = order;
    }

    public LocalDateTime getTimestampDeliveredOrder() {
        return timestampDeliveredOrder;
    }

    public void setTimestampDeliveredOrder(LocalDateTime delivery) {
        this.timestampDeliveredOrder = delivery;
    }

    public CustomerVO getCustomer() {
        return customer;
    }

    public void setCustomer(CustomerVO customer) {
        this.customer = customer;
    }

    public static int getMAX_DISHES() {
        return MAX_DISHES;
    }

    public int getOrderNo() {
        return orderNo;
    }

    // default management method of Java
    // Solution with StringBuffer is efficient!
    // public String toString() {
    // 
    // StringBuilder text = new StringBuilder(String.format(
    // "OrderVO " + getOrderNo()
    // + " from %1$tm/%1$td/%1$tY %1$tH:%1$tM with delivery at  %1$tm/%1$td/%1$tY %2$tH:%2$tM\n",
    // timestampStartedOrder, timestampDeliveredOrder));
    // 
    // text.append("of customer: " + customer.getLastName() + " " + customer.getFirstName() + ", ID of customer: "
    // + customer.getId() + "\n");
    // 
    // if (shoppingBasket != null) {
    // for (int i = 0; i < index; i++) {
    // if (shoppingBasket[i] != null) {
    // text.append(shoppingBasket[i].toString());
    // text.append("\n");
    // }
    // }
    // }
    // 
    // return text.toString();
    // 
    // }
    // Solution with String, not efficient
    public String toString() {
        // special formatting by using String.format() see API class String
        String text = String.format("OrderVO " + getOrderNo() + " from %1$tm/%1$td/%1$tY %1$tH:%1$tM with delivery at  %1$tm/%1$td/%1$tY %2$tH:%2$tM\n", timestampStartedOrder, timestampDeliveredOrder);
        text += "of customer: " + customer.getLastName() + " " + customer.getFirstName() + ", ID of customer: " + customer.getId() + "\n";
        if (shoppingBasket != null) {
            for (int i = 0; i < shoppingBasket.length; i++) {
                // instead of shoppingBasket.length index is also possible
                // index is more efficient,
                // but shoppingBasket.length is saver because the index could be wrong
                if (shoppingBasket[i] != null) {
                    // call of  toString method of PizzaVO
                    text += shoppingBasket[i].toString();
                    text += "\n";
                }
            }
        }
        return text;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass()) {
            return false;
        }
        OrderVO other = (OrderVO) obj;
        if (orderNo != other.getOrderNo()) {
            return false;
        }
        return true;
    }

    /*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#hashCode()
	 */
    @Override
    public int hashCode() {
        int hc = 0;
        final int hashMultiplier = 59;
        hc = hashMultiplier * orderNo;
        return hc;
    }
}
