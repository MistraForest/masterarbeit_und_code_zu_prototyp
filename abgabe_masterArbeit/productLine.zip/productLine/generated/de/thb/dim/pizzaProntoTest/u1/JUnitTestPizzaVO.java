package generated.de.thb.dim.pizzaProntoTest.u1;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import generated.de.thb.dim.pizzaPronto.u1.PizzaVO;

/**
 * The methods of the class PizzaVO are tested.
 *
 * Special assert statements are used for testing <br>
 *
 * @author Gabriele Schmidt
 * @version 2.0 04.02.2017
 */
public class JUnitTestPizzaVO {

    private static Class<PizzaVO> myPizzaVOClass;

    @BeforeEach
    public void initEach() {
    }

    @Test
    @DisplayName("Class has 3 instance attributes")
    public void test3Attributes() {
        myPizzaVOClass = PizzaVO.class;
        Field[] attributes = myPizzaVOClass.getDeclaredFields();
        assertEquals(3, attributes.length);
    }

    @Test
    @DisplayName("Information hiding principle (Geheimnisprinzip): Attributes are private")
    public void testAttributesPrivate() {
        myPizzaVOClass = PizzaVO.class;
        Field[] attributes = myPizzaVOClass.getDeclaredFields();
        int modifiersAttributes;
        for (Field f : attributes) {
            modifiersAttributes = f.getModifiers();
            assertTrue(Modifier.isPrivate(modifiersAttributes));
        }
    }

    @Test
    @DisplayName("All Methods are public")
    public void testMethodsPublic() {
        myPizzaVOClass = PizzaVO.class;
        Method[] methods = myPizzaVOClass.getDeclaredMethods();
        int modifiersMethods;
        for (Method m : methods) {
            modifiersMethods = m.getModifiers();
            assertTrue(Modifier.isPublic(modifiersMethods));
        }
    }

    @Test
    @DisplayName("Default constructor initializes with default values")
    public void testDefaultConstructor() {
        PizzaVO pizzaWithout = new PizzaVO();
        assertEquals(null, pizzaWithout.getName());
        assertEquals(0.0f, pizzaWithout.getPrice());
        assertEquals(null, pizzaWithout.getIngredients());
    }

    @Test
    @DisplayName("Initialization constructor with 3 parameters")
    public void testIniConstructor() {
        float price = 2.020f;
        String name = "tonno prima";
        String[] ingredis = { "Tomaten", "K?se", "Basilikum" };
        PizzaVO pizzaIni = new PizzaVO(name, ingredis, price);
        assertEquals(name, pizzaIni.getName());
        assertEquals(ingredis, pizzaIni.getIngredients());
        assertEquals(price, pizzaIni.getPrice());
    }

    @Test
    @DisplayName("Information hiding principle (Geheimnisprinzip): Setter/getter name")
    public void setGetName() {
        String name = "BBB";
        PizzaVO pizzaWithout = new PizzaVO();
        pizzaWithout.setName(name);
        assertEquals(name, pizzaWithout.getName());
    }

    @Test
    @DisplayName("Information hiding principle (Geheimnisprinzip): Setter/getter ingredients")
    public void setGetIngredients() {
        String[] ingredients = { "Tomaten", "K?se", "Basilikum", "Pfeffer" };
        PizzaVO pizzaWithout = new PizzaVO();
        pizzaWithout.setIngredients(ingredients);
        ;
        assertArrayEquals(ingredients, pizzaWithout.getIngredients());
    }

    @Test
    @DisplayName("Test ingredients with constructor")
    public void testConstructorWithIngredients() {
        PizzaVO pizzaIni = new PizzaVO("Marghrita", new String[] { "Tomaten", "K?se", "Basilikum" }, 8.0f);
        assertArrayEquals(new String[] { "Tomaten", "K?se", "Basilikum" }, pizzaIni.getIngredients(), pizzaIni.getClass() + " checks the ingredients");
    }

    @Test
    @DisplayName("Information hiding principle (Geheimnisprinzip): Test ingredients with setter")
    public void setIngredientsTest() {
        String[] s = { "Tomaten", "K?se", "Anchovis" };
        PizzaVO pizzaWithout = new PizzaVO();
        pizzaWithout.setIngredients(s);
        assertArrayEquals(s, pizzaWithout.getIngredients(), pizzaWithout.getClass() + " checks the setter of ingredients");
    }

    @Test
    @DisplayName("Information hiding principle (Geheimnisprinzip): Setter/getter price")
    public void setGetPrice() {
        float price = 2020.2020f;
        PizzaVO pizzaWithout = new PizzaVO();
        pizzaWithout.setPrice(price);
        assertEquals(price, pizzaWithout.getPrice());
    }

    @Test
    @DisplayName("Information hiding principle (Geheimnisprinzip): Setter: Price should not be negative and is set to 0.")
    public void setPriceNegative() {
        PizzaVO pizzaWithout = new PizzaVO();
        pizzaWithout.setPrice(-10.5f);
        assertEquals(0f, pizzaWithout.getPrice(), pizzaWithout.getClass() + " checks the setter of price sets no negative price");
    }

    @Test
    @DisplayName("Information hiding principle (Geheimnisprinzip): Setter: Price is 0.")
    public void setPrice0() {
        PizzaVO pizzaWithout = new PizzaVO();
        pizzaWithout.setPrice(.0f);
        assertEquals(0f, pizzaWithout.getPrice(), pizzaWithout.getClass() + " checks the setter of price sets no negative price");
    }

    @Test
    @DisplayName("Initializing Constructor: Price should not be negative and is set to 0.")
    public void testIniConstructorPriceNegative() {
        PizzaVO pizzaIni = new PizzaVO("Marghrita", new String[] { "Tomaten", "K?se", "Basilikum" }, -8.0f);
        assertTrue(pizzaIni.getPrice() >= 0, pizzaIni.getClass() + " not a negative price ");
    }

    @Test
    @DisplayName("Initializing Constructor: Price is 0.")
    public void testIniConstructorPrice0() {
        PizzaVO pizzaIni = new PizzaVO("Marghrita", new String[] { "Tomaten", "K?se", "Basilikum" }, .0f);
        assertTrue(pizzaIni.getPrice() >= 0, pizzaIni.getClass() + " not a negative price ");
    }

    @Test
    @DisplayName("Initialization constructor with 1 parameters")
    public void testIniConstructor_01_Param() {
        String name = "BBB";
        PizzaVO pizzaIni = new PizzaVO(name);
        assertEquals(name, pizzaIni.getName());
    }

    @Test
    @DisplayName("Initialization constructor with 2 parameters")
    public void testIniConstructor_02_Param() {
        String name = "BBB";
        String[] ingredients = { "Tomato", "Käse", "Basilikum" };
        PizzaVO pizzaIni = new PizzaVO(name, ingredients);
        assertEquals(name, pizzaIni.getName());
        assertEquals(ingredients, pizzaIni.getIngredients());
    }
}
