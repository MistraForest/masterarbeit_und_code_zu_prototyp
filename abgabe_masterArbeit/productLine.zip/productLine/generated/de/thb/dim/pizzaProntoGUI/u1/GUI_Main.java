package generated.de.thb.dim.pizzaProntoGUI.u1;

import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import generated.de.thb.dim.pizzaProntoGUI.u1.controller.CustomerController;
import generated.de.thb.dim.pizzaProntoGUI.u1.controller.MenuController;
import generated.de.thb.dim.pizzaProntoGUI.u1.controller.StaffController;
import generated.de.thb.dim.pizzaProntoGUI.u1.view.MainView;

public class GUI_Main {

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {

            public void run() {
                try {
                    UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
                } catch (ClassNotFoundException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                } catch (InstantiationException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                } catch (IllegalAccessException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                } catch (UnsupportedLookAndFeelException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
                MainView view = new MainView();
                StaffController staffController = new StaffController(view);
                CustomerController customerController = new CustomerController(view);
                MenuController menuController = new MenuController(view);
            }
        });
    }
}
