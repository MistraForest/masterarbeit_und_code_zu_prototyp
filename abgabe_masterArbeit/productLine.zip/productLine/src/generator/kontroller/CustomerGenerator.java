package generator.kontroller;

import java.io.File;

import generator.configurator.TestCustomerBasicVariantConfiguration;
import generator.kontroller.featureFabrik.fabrikImplementation.AssociationAttributGeneration;
import generator.kontroller.featureFabrik.fabrikImplementation.BasicCustomerConfigGeneration;
import generator.kontroller.featureFabrik.fabrikImplementation.BasicOptionConfigGeneration;
import generator.kontroller.featureFabrik.fabrikImplementation.ConstructorConfigGeneration;
import generator.kontroller.featureFabrik.fabrikImplementation.CustomerTestConfig2ndGeneration;
import generator.kontroller.featureFabrik.fabrikImplementation.CustomerThirdTestConfigGeneration;
import generator.kontroller.featureFabrik.fabrikImplementation.EqualsImplicitNullCheckWithInstanceOfConfigGeneration;
import generator.kontroller.featureFabrik.fabrikImplementation.EqualsImplicitNullCheckWithoutInstanceOfConfigGeneration;
import generator.kontroller.featureFabrik.fabrikImplementation.EqualsNullCheckWithInstanceOfGeneration;
import generator.kontroller.featureFabrik.fabrikImplementation.EqualsNullCheckWithoutInstanceOfGeneration;
import generator.kontroller.featureFabrik.fabrikImplementation.FirstConstructorOptionConfigGeneration;
import generator.kontroller.featureFabrik.fabrikImplementation.HashLongVariantConfigGeneration;
import generator.kontroller.featureFabrik.fabrikImplementation.HashShortVariantConfigGeneration;
import generator.kontroller.featureFabrik.fabrikImplementation.NewAttributesConfigGeneration;
import generator.kontroller.featureFabrik.fabrikImplementation.SecondConstructorOptionConfigGeneration;
import generator.kontroller.featureFabrik.fabrikImplementation.ThirdConstructorOptionConfigGeneration;
import generator.kontroller.featureFabrik.fabrikImplementation.ToString01OptionConfigGeneration;
import generator.kontroller.featureFabrik.fabrikImplementation.ToString02OptionConfigGeneration;
import generator.kontroller.featureFabrik.fabrikImplementation.ToString03OptionConfigGeneration;
import generator.kontroller.featureFabrik.fabrikImplementation.ToStringConfigGeneration;
import utils.DirExplorerUtil;
import utils.FilterUtil.FileNameFilter;
import utils.generator.handler.AstTransformationHandler;
import utils.generator.handler.Filter;

/**
 * This class hold all the different feature creators for the class CustomerVO
 * @author forest
 *
 */
public class CustomerGenerator {

	private String javaFileName;
	private AstTransformationHandler handler;
	private Filter filter;
	
	private BasicCustomerConfigGeneration basicConfigGeneration;
	private BasicOptionConfigGeneration basicOptionConfigGeneration;
	private ConstructorConfigGeneration constructorConfigGeneration;
	private ThirdConstructorOptionConfigGeneration thirdConstructorOptionConfigGeneration;
	private SecondConstructorOptionConfigGeneration secondConstructorOptionConfigGeneration;
	private FirstConstructorOptionConfigGeneration firstConstructorOptionConfigGeneration;
	private EqualsNullCheckWithInstanceOfGeneration equalsExplicitNullCheckWithInstanceOf;
	private EqualsNullCheckWithoutInstanceOfGeneration equalsExplicitNullCheckWithoutInstanceOf;
	private EqualsImplicitNullCheckWithInstanceOfConfigGeneration equalsImplicitNullCheckWithInstanceOf;
	private EqualsImplicitNullCheckWithoutInstanceOfConfigGeneration equalsImplicitNullCheckWithoutInstanceOf;
	private HashShortVariantConfigGeneration hashShortVariantConfig;
	private NewAttributesConfigGeneration newAttributesConfigGeneration;
	private ToStringConfigGeneration toStringConfigGeneration;
	private ToString03OptionConfigGeneration string03OptionConfigGeneration;
	private ToString02OptionConfigGeneration toString02OptionConfigGeneration;
	private ToString01OptionConfigGeneration toString01OptionConfigGeneration;
	private CustomerTestConfig2ndGeneration testConfig2ndGeneration;
	private HashLongVariantConfigGeneration hashLongVariantConfigGeneration;
	private CustomerThirdTestConfigGeneration customerThirdTestConfigGeneration;
	private AssociationAttributGeneration associationAttributGeneration;

	public CustomerGenerator(String javaFileName) {
		this.javaFileName = javaFileName;
		this.filter = new FileNameFilter(javaFileName);
		
		this.basicConfigGeneration = new BasicCustomerConfigGeneration();
		this.basicOptionConfigGeneration = new BasicOptionConfigGeneration();
		this.setConstructorConfigGeneration(new ConstructorConfigGeneration(javaFileName));
		this.setThirdConstructorOptionConfigGeneration(new ThirdConstructorOptionConfigGeneration());
		this.secondConstructorOptionConfigGeneration = new SecondConstructorOptionConfigGeneration();
		this.firstConstructorOptionConfigGeneration = new FirstConstructorOptionConfigGeneration();
		this.setEqualsExplicitNullCheckWithInstanceOf(new EqualsNullCheckWithInstanceOfGeneration());
		this.setEqualsExplicitNullCheckWithoutInstanceOf(new EqualsNullCheckWithoutInstanceOfGeneration());
		this.setEqualsImplicitNullCheckWithInstanceOf(new EqualsImplicitNullCheckWithInstanceOfConfigGeneration());
		this.setEqualsImplicitNullCheckWithoutInstanceOf(new EqualsImplicitNullCheckWithoutInstanceOfConfigGeneration());
		this.setHashShortVariantConfig(new HashShortVariantConfigGeneration());
		this.setNewAttributesConfigGeneration(new NewAttributesConfigGeneration());
		this.setToStringConfigGeneration(new ToStringConfigGeneration());
		this.setString03OptionConfigGeneration(new ToString03OptionConfigGeneration());
		this.setToString02OptionConfigGeneration(new ToString02OptionConfigGeneration());
		this.setToString01OptionConfigGeneration(new ToString01OptionConfigGeneration());
		this.setTestConfig2ndGeneration(new CustomerTestConfig2ndGeneration());
		this.setHashLongVariantConfigGeneration(new HashLongVariantConfigGeneration());
		this.setCustomerThirdTestConfigGeneration(new CustomerThirdTestConfigGeneration());
		this.setAssociationAttributGeneration(new AssociationAttributGeneration());
	}

	// Element of core asset to be reused in different variants
	public void basicVariantTestConfiguration(File projectDir, String clazzUnderTest) {
		this.handler = new TestCustomerBasicVariantConfiguration(javaFileName, clazzUnderTest);

		new DirExplorerUtil(filter, handler).explore(projectDir);
	}

	public BasicCustomerConfigGeneration getBasicConfigGeneration() {
		return basicConfigGeneration;
	}

	public void setBasicConfigGeneration(BasicCustomerConfigGeneration basicConfigGeneration) {
		this.basicConfigGeneration = basicConfigGeneration;
	}

	public BasicOptionConfigGeneration getBasicOptionConfigGeneration() {
		return basicOptionConfigGeneration;
	}

	public void setBasicOptionConfigGeneration(BasicOptionConfigGeneration basicOptionConfigGeneration) {
		this.basicOptionConfigGeneration = basicOptionConfigGeneration;
	}

	public ConstructorConfigGeneration getConstructorConfigGeneration() {
		return constructorConfigGeneration;
	}

	public void setConstructorConfigGeneration(ConstructorConfigGeneration constructorConfigGeneration) {
		this.constructorConfigGeneration = constructorConfigGeneration;
	}

	public ThirdConstructorOptionConfigGeneration getThirdConstructorOptionConfigGeneration() {
		return thirdConstructorOptionConfigGeneration;
	}

	public void setThirdConstructorOptionConfigGeneration(ThirdConstructorOptionConfigGeneration thirdConstructorOptionConfigGeneration) {
		this.thirdConstructorOptionConfigGeneration = thirdConstructorOptionConfigGeneration;
	}

	public SecondConstructorOptionConfigGeneration getSecondConstructorOptionConfigGeneration() {
		return secondConstructorOptionConfigGeneration;
	}

	public void setSecondConstructorOptionConfigGeneration(SecondConstructorOptionConfigGeneration secondConstructorOptionConfigGeneration) {
		this.secondConstructorOptionConfigGeneration = secondConstructorOptionConfigGeneration;
	}

	public FirstConstructorOptionConfigGeneration getFirstConstructorOptionConfigGeneration() {
		return firstConstructorOptionConfigGeneration;
	}

	public void setFirstConstructorOptionConfigGeneration(FirstConstructorOptionConfigGeneration firstConstructorOptionConfigGeneration) {
		this.firstConstructorOptionConfigGeneration = firstConstructorOptionConfigGeneration;
	}

	public EqualsNullCheckWithInstanceOfGeneration getEqualsExplicitNullCheckWithInstanceOf() {
		return equalsExplicitNullCheckWithInstanceOf;
	}

	public void setEqualsExplicitNullCheckWithInstanceOf(EqualsNullCheckWithInstanceOfGeneration equalsExplicitNullCheckWithInstanceOf) {
		this.equalsExplicitNullCheckWithInstanceOf = equalsExplicitNullCheckWithInstanceOf;
	}

	public HashShortVariantConfigGeneration getHashShortVariantConfig() {
		return hashShortVariantConfig;
	}

	public void setHashShortVariantConfig(HashShortVariantConfigGeneration hashShortVariantConfig) {
		this.hashShortVariantConfig = hashShortVariantConfig;
	}

	public NewAttributesConfigGeneration getNewAttributesConfigGeneration() {
		return newAttributesConfigGeneration;
	}

	public void setNewAttributesConfigGeneration(NewAttributesConfigGeneration newAttributesConfigGeneration) {
		this.newAttributesConfigGeneration = newAttributesConfigGeneration;
	}

	public ToStringConfigGeneration getToStringConfigGeneration() {
		return toStringConfigGeneration;
	}

	public void setToStringConfigGeneration(ToStringConfigGeneration toStringConfigGeneration) {
		this.toStringConfigGeneration = toStringConfigGeneration;
	}

	public CustomerTestConfig2ndGeneration getTestConfig2ndGeneration() {
		return testConfig2ndGeneration;
	}

	public void setTestConfig2ndGeneration(CustomerTestConfig2ndGeneration testConfig2ndGeneration) {
		this.testConfig2ndGeneration = testConfig2ndGeneration;
	}

	public EqualsNullCheckWithoutInstanceOfGeneration getEqualsExplicitNullCheckWithoutInstanceOf() {
		return equalsExplicitNullCheckWithoutInstanceOf;
	}

	public void setEqualsExplicitNullCheckWithoutInstanceOf(EqualsNullCheckWithoutInstanceOfGeneration equalsExplicitNullCheckWithoutInstanceOf) {
		this.equalsExplicitNullCheckWithoutInstanceOf = equalsExplicitNullCheckWithoutInstanceOf;
	}

	public HashLongVariantConfigGeneration getHashLongVariantConfigGeneration() {
		return hashLongVariantConfigGeneration;
	}

	public void setHashLongVariantConfigGeneration(HashLongVariantConfigGeneration hashLongVariantConfigGeneration) {
		this.hashLongVariantConfigGeneration = hashLongVariantConfigGeneration;
	}

	public ToString03OptionConfigGeneration getString03OptionConfigGeneration() {
		return string03OptionConfigGeneration;
	}

	public void setString03OptionConfigGeneration(ToString03OptionConfigGeneration string03OptionConfigGeneration) {
		this.string03OptionConfigGeneration = string03OptionConfigGeneration;
	}

	public EqualsImplicitNullCheckWithInstanceOfConfigGeneration getEqualsImplicitNullCheckWithInstanceOf() {
		return equalsImplicitNullCheckWithInstanceOf;
	}

	public void setEqualsImplicitNullCheckWithInstanceOf(EqualsImplicitNullCheckWithInstanceOfConfigGeneration equalsImplicitNullCheckWithInstanceOf) {
		this.equalsImplicitNullCheckWithInstanceOf = equalsImplicitNullCheckWithInstanceOf;
	}

	public EqualsImplicitNullCheckWithoutInstanceOfConfigGeneration getEqualsImplicitNullCheckWithoutInstanceOf() {
		return equalsImplicitNullCheckWithoutInstanceOf;
	}

	public void setEqualsImplicitNullCheckWithoutInstanceOf(EqualsImplicitNullCheckWithoutInstanceOfConfigGeneration equalsImplicitNullCheckWithoutInstanceOf) {
		this.equalsImplicitNullCheckWithoutInstanceOf = equalsImplicitNullCheckWithoutInstanceOf;
	}

	public ToString01OptionConfigGeneration getToString01OptionConfigGeneration() {
		return toString01OptionConfigGeneration;
	}

	public void setToString01OptionConfigGeneration(ToString01OptionConfigGeneration toString01OptionConfigGeneration) {
		this.toString01OptionConfigGeneration = toString01OptionConfigGeneration;
	}

	public CustomerThirdTestConfigGeneration getCustomerThirdTestConfigGeneration() {
		return customerThirdTestConfigGeneration;
	}

	public void setCustomerThirdTestConfigGeneration(CustomerThirdTestConfigGeneration customerThirdTestConfigGeneration) {
		this.customerThirdTestConfigGeneration = customerThirdTestConfigGeneration;
	}

	public AssociationAttributGeneration getAssociationAttributGeneration() {
		return associationAttributGeneration;
	}

	public void setAssociationAttributGeneration(AssociationAttributGeneration associationAttributGeneration) {
		this.associationAttributGeneration = associationAttributGeneration;
	}

	public ToString02OptionConfigGeneration getToString02OptionConfigGeneration() {
		return toString02OptionConfigGeneration;
	}

	public void setToString02OptionConfigGeneration(ToString02OptionConfigGeneration toString02OptionConfigGeneration) {
		this.toString02OptionConfigGeneration = toString02OptionConfigGeneration;
	}
}
