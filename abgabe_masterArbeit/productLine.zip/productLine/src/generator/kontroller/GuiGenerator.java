package generator.kontroller;

import java.io.File;

import generator.configurator.BasicGUIConfiguration;
import generator.configurator.GUI2ndConfiguration;
import generator.configurator.GUI3rdConfiguration;
import generator.configurator.ImageConfig;
import utils.DirExplorerUtil;
import utils.FilterUtil.ImageFilter;
import utils.generator.handler.AstTransformationHandler;
import utils.generator.handler.Filter;

/**
 * This class hold all the different GUI code generation in a single place
 * @author forest
 *
 */
public class GuiGenerator {
	
	private static final String PNG = ".png";
	private static final String IMG_BASIC_DIR = "generated/de/thb/dim/pizzaProntoGUI/u1/images/";
	private static final String IMG_2ND_DIR = "generated/de/thb/dim/pizzaProntoGUI/u2/images/";
	private static final String IMG_3RD_DIR = "generated/de/thb/dim/pizzaProntoGUI/u3/images/";
	
	private AstTransformationHandler handler;
	private Filter filter;

	public void withBasicConfiguration(File projectDir) {

		handleFile(projectDir);
		
		handleImage(projectDir);
	}
	
	
	public void with2ndGuiConfiguration(File projectDirGui) {
		
		this.handler = new GUI2ndConfiguration();
		this.filter  = new JavaFileFilter();
		new DirExplorerUtil(filter, handler).explore(projectDirGui);
		
		handle2ndImage(projectDirGui);
	}
	
	public void with3rdGuiConfiguration(File projectDirGui) {
		
		this.handler = new GUI3rdConfiguration();
		this.filter  = new JavaFileFilter();
		new DirExplorerUtil(filter, handler).explore(projectDirGui);
		
		handle3rdImage(projectDirGui);		
	}

	private void handle3rdImage(File projectDirGui) {
		this.handler = new ImageConfig(IMG_3RD_DIR, PNG);
		this.filter  = new ImageFilter(PNG);
		new DirExplorerUtil(filter, handler).explore(projectDirGui);		
	}
	
	public void handleImage(File projectDir) {
		this.handler = new ImageConfig(IMG_BASIC_DIR, PNG);
		this.filter  = new ImageFilter(PNG);
		new DirExplorerUtil(filter, handler).explore(projectDir);
	}
	
	public void handle2ndImage(File projectDir) {
		this.handler = new ImageConfig(IMG_2ND_DIR, PNG);
		this.filter  = new ImageFilter(PNG);
		new DirExplorerUtil(filter, handler).explore(projectDir);
	}
	
	public void handleFile(File projectDir) {
		this.handler = new BasicGUIConfiguration();
		this.filter  = new JavaFileFilter();
		new DirExplorerUtil(filter, handler).explore(projectDir);
	}

	class JavaFileFilter implements Filter{ 
		
		@Override
		public boolean filterFile(int level, String path, File file) {
			boolean found = false;
			if(path.endsWith(".java")) {
				found = true;
			}			
			return found;
		}	
	}
	
}
