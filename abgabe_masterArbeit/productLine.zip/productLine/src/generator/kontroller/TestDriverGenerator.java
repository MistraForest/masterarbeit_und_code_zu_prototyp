package generator.kontroller;

import java.io.File;

import generator.configurator.BasicConfiguration;
import utils.DirExplorerUtil;
import utils.FilterUtil.FileNameFilter;
import utils.generator.handler.AstTransformationHandler;
import utils.generator.handler.Filter;

public class TestDriverGenerator {
	
	private String javaFileName;
	private AstTransformationHandler handler;
	private Filter filter;

	public TestDriverGenerator(String javaFileName) {
		this.javaFileName = javaFileName;
		this.filter = new FileNameFilter(javaFileName);
	}

	public void withBasicConfiguration(File projectDir) {
		this.handler = new BasicConfiguration(javaFileName);

		DirExplorerUtil explorator = new DirExplorerUtil(filter, handler);
		explorator.explore(projectDir);

	}

}
