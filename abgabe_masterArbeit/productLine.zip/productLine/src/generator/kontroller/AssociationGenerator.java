package generator.kontroller;

import generator.kontroller.featureFabrik.fabrikImplementation.AssociationTestClazzGeneration;
import generator.kontroller.featureFabrik.fabrikImplementation.ToStingLessEfficiencyConfigGeneration;
import generator.kontroller.featureFabrik.fabrikImplementation.ToStringBetterEfficiencyConfigGeneration;

/**
 * This hold all the feature creators in one place regarding the association relationship
 * between the classes CustomerVO and OrderVO
 * @author forest
 *
 */
public class AssociationGenerator {

	private AssociationTestClazzGeneration associationTestClazzGeneration;
	private ToStingLessEfficiencyConfigGeneration toStingLessEfficiencyConfigGeneration;
	private ToStringBetterEfficiencyConfigGeneration toStringBetterEfficiencyConfigGeneration;
	
	public AssociationGenerator(String javaFile) {
		
		this.setAssociationTestClazzGeneration(new AssociationTestClazzGeneration());
		this.setToStingLessEfficiencyConfigGeneration(new ToStingLessEfficiencyConfigGeneration());
		this.setToStringBetterEfficiencyConfigGeneration(new ToStringBetterEfficiencyConfigGeneration());
	}

	public AssociationTestClazzGeneration getAssociationTestClazzGeneration() {
		return associationTestClazzGeneration;
	}

	public void setAssociationTestClazzGeneration(AssociationTestClazzGeneration associationTestClazzGeneration) {
		this.associationTestClazzGeneration = associationTestClazzGeneration;
	}

	public ToStingLessEfficiencyConfigGeneration getToStingLessEfficiencyConfigGeneration() {
		return toStingLessEfficiencyConfigGeneration;
	}

	public void setToStingLessEfficiencyConfigGeneration(ToStingLessEfficiencyConfigGeneration toStingLessEfficiencyConfigGeneration) {
		this.toStingLessEfficiencyConfigGeneration = toStingLessEfficiencyConfigGeneration;
	}

	public ToStringBetterEfficiencyConfigGeneration getToStringBetterEfficiencyConfigGeneration() {
		return toStringBetterEfficiencyConfigGeneration;
	}

	public void setToStringBetterEfficiencyConfigGeneration(ToStringBetterEfficiencyConfigGeneration toStringBetterEfficiencyConfigGeneration) {
		this.toStringBetterEfficiencyConfigGeneration = toStringBetterEfficiencyConfigGeneration;
	}

}
