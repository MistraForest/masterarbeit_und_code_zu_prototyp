package generator.kontroller.featureFabrik;


import java.io.File;

import utils.DirExplorerUtil;
import utils.generator.handler.Filter;
import utils.generator.handler.AstTransformationHandler;

/**
 * This class is the model to create/generate the logic behind a set of feature selection 
 * @author forest
 *
 */
public abstract class FeatureGenerator {
	
	/**
	 * This is the generic method to generate the logic of a feature selection.
	 * All concrete configurations should implement this method accordingly.
	 * @param filter to filter the concerned java file 
	 * @param projectDirectory the directory of the java file
	 */
	public void generateFeature(Filter filter, File projectDirectory) {
		AstTransformationHandler handler = handleKonfiguration();
		new DirExplorerUtil(filter, handler).explore(projectDirectory);
	}
	
	/**
	 * This method will be used to handle correctly the configuration selection.
	 * Every single configuration need to be implemented as needed
	 * @return a transformation handler which should be specified
	 */
	protected abstract AstTransformationHandler handleKonfiguration();
	

}
