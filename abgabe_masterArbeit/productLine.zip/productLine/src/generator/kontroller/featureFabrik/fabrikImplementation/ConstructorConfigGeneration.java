package generator.kontroller.featureFabrik.fabrikImplementation;

import generator.configurator.ConstructorConfiguration;
import generator.kontroller.featureFabrik.FeatureGenerator;
import utils.generator.handler.AstTransformationHandler;

/**
 * This component is a concrete feature generator that generate a constructor 
 * based on the model located in {@utils.ConstructorUtil}
 * @author forest
 *
 */
public class ConstructorConfigGeneration extends FeatureGenerator {
	
	private int numberOfParameter;
	private String javaFileName;

	public ConstructorConfigGeneration(String javaFileName) {
		this.javaFileName = javaFileName;
	}

	public String getJavaFileName() {
		return javaFileName;
	}
	
	public void setJavaFileName(String javaFileName) {
		this.javaFileName = javaFileName;
	}
	
	public int getNumberOfParameter() { 
		return numberOfParameter; 
	} 
	
	public void setNumberOfParameter(int numberOfParameter) { 
		this.numberOfParameter = numberOfParameter; 
	}

	@Override
	protected AstTransformationHandler handleKonfiguration() {
		return new ConstructorConfiguration(numberOfParameter, javaFileName); 
	}

}
