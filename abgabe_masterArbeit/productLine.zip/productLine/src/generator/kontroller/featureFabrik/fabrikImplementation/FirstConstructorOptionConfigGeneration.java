package generator.kontroller.featureFabrik.fabrikImplementation;

import generator.configurator.TestConstructorOptionConfiguration;
import generator.kontroller.featureFabrik.FeatureGenerator;
import utils.generator.handler.AstTransformationHandler;

/**
 * This component is a concrete feature generator that generate tests of constructors with one parameter 
 * for the CustomerVO class.
 * @author forest
 *
 */
public class FirstConstructorOptionConfigGeneration extends FeatureGenerator {

	private String clazzUnderTest;
	private String testClazz;

	public String getTestClazz() {
		return testClazz;
	}

	public void setTestClazz(String testClazz) {
		this.testClazz = testClazz;
	}

	public String getClazzUnderTest() {
		return clazzUnderTest;
	}

	public void setClazzUnderTest(String clazzUnderTest) {
		this.clazzUnderTest = clazzUnderTest;
	}
	
	@Override
	protected AstTransformationHandler handleKonfiguration() {
		return new TestConstructorOptionConfiguration(testClazz, clazzUnderTest).getCustomer1stOptionTestConfig();
	}

}
