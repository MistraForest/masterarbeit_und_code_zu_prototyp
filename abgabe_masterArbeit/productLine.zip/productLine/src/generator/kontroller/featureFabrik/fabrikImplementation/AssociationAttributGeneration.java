package generator.kontroller.featureFabrik.fabrikImplementation;

import generator.configurator.With3rdGenConfiguration;
import generator.kontroller.featureFabrik.FeatureGenerator;
import utils.generator.handler.AstTransformationHandler;

/**
 * This component is a concrete feature generator to generate the field for the 
 * association relationship.
 * @author forest
 *
 */
public class AssociationAttributGeneration extends FeatureGenerator {

	private String javaFileName;

	@Override
	protected AstTransformationHandler handleKonfiguration() {
		return new With3rdGenConfiguration(javaFileName).withCustomer3rdGenNewAttributConfig();
	}

	public String getJavaFileName() {
		return javaFileName;
	}

	public void setJavaFileName(String javaFileName) {
		this.javaFileName = javaFileName;
	}

}
