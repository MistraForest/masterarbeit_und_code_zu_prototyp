package generator.kontroller.featureFabrik.fabrikImplementation;

import generator.configurator.ThirdGenerationTestConfiguration;
import generator.kontroller.featureFabrik.FeatureGenerator;
import utils.generator.handler.AstTransformationHandler;

/**
 * This component is a concrete feature generator for test features in the third feature group "Uebung3"
 * @author forest
 *
 */
public class ChefthirdFeatureTestConfigGeneration extends FeatureGenerator {

	private String javaFileName;

	@Override
	protected AstTransformationHandler handleKonfiguration() {
		return new ThirdGenerationTestConfiguration(javaFileName).withChef3rdGenTestConfig();
	}

	public String getJavaFileName() {
		return javaFileName;
	}

	public void setJavaFileName(String javaFileName) {
		this.javaFileName = javaFileName;
	}

}
