package generator.kontroller.featureFabrik.fabrikImplementation;

import generator.configurator.BasicOptionConfiguration;
import generator.kontroller.featureFabrik.FeatureGenerator;
import utils.generator.handler.AstTransformationHandler;

/**
 * This component is a concrete feature generator that will generate the tests features for the CustomerVO class
 * in the feature group "Uebung1"
 * @author forest
 *
 */
public class BasicOptionConfigGeneration extends FeatureGenerator {

	private String javaFileName;

	public String getJavaFileName() {
		return javaFileName;
	}

	public void setJavaFileName(String javaFileName) {
		this.javaFileName = javaFileName;
	}

	@Override
	protected AstTransformationHandler handleKonfiguration() {
		return new BasicOptionConfiguration(javaFileName);
	}

}
