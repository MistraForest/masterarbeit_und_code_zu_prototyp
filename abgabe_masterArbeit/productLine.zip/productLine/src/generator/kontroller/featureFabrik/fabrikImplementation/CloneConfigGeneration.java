package generator.kontroller.featureFabrik.fabrikImplementation;

import constants.Constant;
import generator.configurator.CloneConfiguration;
import generator.kontroller.featureFabrik.FeatureGenerator;
import utils.generator.handler.AstTransformationHandler;

/**
 * This component is a concrete feature generator to generate the clone() method
 * @author forest
 *
 */
public class CloneConfigGeneration extends FeatureGenerator {

	private String javaFileName;

	@Override
	protected AstTransformationHandler handleKonfiguration() {
		return new CloneConfiguration(Constant.CLONE, javaFileName).getCloneVariantConfig();
	}

	public String getJavaFileName() {
		return javaFileName;
	}

	public void setJavaFileName(String javaFileName) {
		this.javaFileName = javaFileName;
	}

}
