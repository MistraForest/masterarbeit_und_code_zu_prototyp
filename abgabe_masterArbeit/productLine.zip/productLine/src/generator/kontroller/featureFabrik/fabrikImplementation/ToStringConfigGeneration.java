package generator.kontroller.featureFabrik.fabrikImplementation;

import generator.configurator.ToStringConfiguration;
import generator.kontroller.featureFabrik.FeatureGenerator;
import utils.generator.handler.AstTransformationHandler;

/**
 * This component is a concrete feature generator that generate the toString() method
 * @author forest
 *
 */
public class ToStringConfigGeneration extends FeatureGenerator {

	private int numberOfAttibut;
	private String javaFileName;

	@Override
	protected AstTransformationHandler handleKonfiguration() {
		return new ToStringConfiguration(numberOfAttibut, javaFileName);
	}


	public int getNumberOfAttibut() {
		return numberOfAttibut;
	}

	public void setNumberOfAttibut(int numberOfAttibut) {
		this.numberOfAttibut = numberOfAttibut;
	}

	public String getJavaFileName() {
		return javaFileName;
	}

	public void setJavaFileName(String javaFileName) {
		this.javaFileName = javaFileName;
	}

}
