package generator.kontroller.featureFabrik.fabrikImplementation;

import generator.configurator.With3rdGenConfiguration;
import generator.kontroller.featureFabrik.FeatureGenerator;
import utils.generator.handler.AstTransformationHandler;

/**
 * This component is a concrete feature generator that generate the code for
 * the class PizzaVO in the feature group "Uebung3"
 * @author forest
 *
 */
public class Pizza3rdFeatureConfigGeneration extends FeatureGenerator {

	private String javaFileName;

	@Override
	protected AstTransformationHandler handleKonfiguration() {
		return new With3rdGenConfiguration(javaFileName).withPizza3rdGenConfig();
	}

	public String getJavaFileName() {
		return javaFileName;
	}

	public void setJavaFileName(String javaFileName) {
		this.javaFileName = javaFileName;
	}

}
