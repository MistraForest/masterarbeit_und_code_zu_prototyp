package generator.kontroller.featureFabrik.fabrikImplementation;

import generator.configurator.ThirdGenerationTestConfiguration;
import generator.kontroller.featureFabrik.FeatureGenerator;
import utils.generator.handler.AstTransformationHandler;

/**
 * This component is a concrete feature generator that generate tests 
 * for the CustomerVO class in the feature group "Uebung3"
 * @author forest
 *
 */
public class CustomerThirdTestConfigGeneration extends FeatureGenerator {

	private String javaFileName;

	@Override
	protected AstTransformationHandler handleKonfiguration() {
		return new ThirdGenerationTestConfiguration(javaFileName).withCustomer3rdGenTestConfig();
	}

	public String getJavaFileName() {
		return javaFileName;
	}

	public void setJavaFileName(String javaFileName) {
		this.javaFileName = javaFileName;
	}

}
