package generator.kontroller.featureFabrik.fabrikImplementation;

import generator.configurator.NewAttributesConfiguration;
import generator.kontroller.featureFabrik.FeatureGenerator;
import utils.generator.handler.AstTransformationHandler;

/**
 * This component is a concrete feature generator that generate the new attributes into a given class.
 * The class constructor will be updated and the setters and getters will also be generated.
 * @author forest
 *
 */
public class NewAttributesConfigGeneration extends FeatureGenerator {

	private String javaFileName;
	String[] ConstructorPrameters;

	@Override
	protected AstTransformationHandler handleKonfiguration() {
		return new NewAttributesConfiguration(javaFileName).getNewAttributesVariantConfig(ConstructorPrameters);
	}

	public String getJavaFileName() {
		return javaFileName;
	}

	public void setJavaFileName(String javaFileName) {
		this.javaFileName = javaFileName;
	}

	public String[] getConstructorPrameters() {
		return ConstructorPrameters;
	}

	public void setConstructorPrameters(String[] constructorPrameters) {
		ConstructorPrameters = constructorPrameters;
	}


}
