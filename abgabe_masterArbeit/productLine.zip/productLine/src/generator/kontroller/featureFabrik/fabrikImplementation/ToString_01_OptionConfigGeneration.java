package generator.kontroller.featureFabrik.fabrikImplementation;

import generator.configurator.ToStringOptionConfiguration;
import generator.kontroller.featureFabrik.FeatureGenerator;
import utils.generator.handler.AstTransformationHandler;

/**
 * This component is a concrete feature generator that generate the test of the 
 * toString() method with one attribute in the PizzaVO class.
 * @author forest
 *
 */
public class ToString_01_OptionConfigGeneration extends FeatureGenerator {

	private String clazzUnderTest;
	private String testClazz;

	public String getTestClazz() {
		return testClazz;
	}

	public void setTestClazz(String testClazz) {
		this.testClazz = testClazz;
	}

	public String getClazzUnderTest() {
		return clazzUnderTest;
	}

	public void setClazzUnderTest(String clazzUnderTest) {
		this.clazzUnderTest = clazzUnderTest;
	}
	
	@Override
	protected AstTransformationHandler handleKonfiguration() {
		return new ToStringOptionConfiguration(testClazz, clazzUnderTest).toString_01_OptionTestConfig();
	}

}
