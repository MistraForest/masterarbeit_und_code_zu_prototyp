package generator.kontroller.featureFabrik.fabrikImplementation;

import constants.Constant;
import generator.configurator.EqualsConfiguration;
import generator.kontroller.featureFabrik.FeatureGenerator;
import utils.generator.handler.AstTransformationHandler;

/**
 * This component is a concrete feature generator that generate a Variant of the equals() method:
 * with implicit null check using the method instanceOf().
 * @author forest
 *
 */
public class EqualsImplicitNullCheckWithInstanceOfConfigGeneration extends FeatureGenerator {

	private String javaFileName;

	@Override
	protected AstTransformationHandler handleKonfiguration() {
		return new EqualsConfiguration(Constant.EQUALS_METH, javaFileName).getImplicitWithConfig();
	}

	public String getJavaFileName() {
		return javaFileName;
	}

	public void setJavaFileName(String javaFileName) {
		this.javaFileName = javaFileName;
	}

}
