package generator.kontroller.featureFabrik.fabrikImplementation;

import generator.configurator.With3rdGenConfiguration;
import generator.kontroller.featureFabrik.FeatureGenerator;
import utils.generator.handler.AstTransformationHandler;

/**
 * This component is a concrete feature generator for 
 * the third feature group "Uebung3" for the ChefVO class.
 * @author forest
 *
 */
public class Chef3rdFeatureConfigGeneration extends FeatureGenerator {

	private String javaFileName;

	@Override
	protected AstTransformationHandler handleKonfiguration() {
		return new With3rdGenConfiguration(javaFileName).withChef3rdGenConfig();
	}

	public String getJavaFileName() {
		return javaFileName;
	}

	public void setJavaFileName(String javaFileName) {
		this.javaFileName = javaFileName;
	}

}
