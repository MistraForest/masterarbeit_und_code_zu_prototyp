package generator.kontroller.featureFabrik.fabrikImplementation;

import constants.Constant;
import generator.configurator.HashCodeConfiguration;
import generator.kontroller.featureFabrik.FeatureGenerator;
import utils.generator.handler.AstTransformationHandler;

/**
 * This component is a concrete feature generator that generate the long variant of the hashCode() method 
 * @author forest
 *
 */
public class HashLongVariantConfigGeneration extends FeatureGenerator {

	private String javaFileName;

	@Override
	protected AstTransformationHandler handleKonfiguration() {
		return new HashCodeConfiguration(Constant.HASH_CODE, javaFileName).getLongVariantConfig();
	}

	public String getJavaFileName() {
		return javaFileName;
	}

	public void setJavaFileName(String javaFileName) {
		this.javaFileName = javaFileName;
	}

}
