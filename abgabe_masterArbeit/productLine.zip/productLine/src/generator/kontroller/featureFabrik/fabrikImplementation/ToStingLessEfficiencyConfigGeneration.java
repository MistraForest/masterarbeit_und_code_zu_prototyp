package generator.kontroller.featureFabrik.fabrikImplementation;

import generator.configurator.AssociationConfiguration;
import generator.kontroller.featureFabrik.FeatureGenerator;
import utils.generator.handler.AstTransformationHandler;

/**
 * This component is a concrete feature generator that generate the toString() method in the
 * association class OrderVO. The implementation will be done by using string instead of StringBuffer.
 * 
 * @author forest
 *
 */
public class ToStingLessEfficiencyConfigGeneration extends FeatureGenerator {

	private String javaFile;

	@Override
	protected AstTransformationHandler handleKonfiguration() {
		return new AssociationConfiguration(javaFile).getMethoManagementWithString();
	}

	public String getJavaFile() {
		return javaFile;
	}

	public void setJavaFile(String javaFile) {
		this.javaFile = javaFile;
	}

}
