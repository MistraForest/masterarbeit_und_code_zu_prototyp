package generator.kontroller.featureFabrik.fabrikImplementation;

import generator.configurator.TestBasicConfiguration;
import generator.kontroller.featureFabrik.FeatureGenerator;
import utils.generator.handler.AstTransformationHandler;

/**
 * This component is a concrete feature generator that will generate the tests features 
 * in the feature group "Uebung1"
 * @author forest
 *
 */
public class BasicTestConfigGeneration extends FeatureGenerator {

	private String javaFileName;
	
	public String getJavaFileName() {
		return javaFileName;
	}

	public void setJavaFileName(String javaFileName) {
		this.javaFileName = javaFileName;
	}

	@Override
	protected AstTransformationHandler handleKonfiguration() {
		return new TestBasicConfiguration(javaFileName);
	}

}
