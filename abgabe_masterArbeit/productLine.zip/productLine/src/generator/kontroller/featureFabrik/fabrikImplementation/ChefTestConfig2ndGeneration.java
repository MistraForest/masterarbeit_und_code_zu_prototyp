package generator.kontroller.featureFabrik.fabrikImplementation;

import generator.configurator.TestChefBasicVariantConfiguration;
import generator.kontroller.featureFabrik.FeatureGenerator;
import utils.generator.handler.AstTransformationHandler;

/**
 * This component is a concrete feature generator to generate tests 
 * for the ChefVO class in the second feature group "Uebung2"
 * @author forest
 *
 */
public class ChefTestConfig2ndGeneration extends FeatureGenerator {

	private String clazzUnderTest;
	private String testClazz;

	public String getTestClazz() {
		return testClazz;
	}

	public void setTestClazz(String testClazz) {
		this.testClazz = testClazz;
	}

	public String getClazzUnderTest() {
		return clazzUnderTest;
	}

	public void setClazzUnderTest(String clazzUnderTest) {
		this.clazzUnderTest = clazzUnderTest;
	}
	
	@Override
	protected AstTransformationHandler handleKonfiguration() {
		return new TestChefBasicVariantConfiguration(testClazz, clazzUnderTest);
	}

}
