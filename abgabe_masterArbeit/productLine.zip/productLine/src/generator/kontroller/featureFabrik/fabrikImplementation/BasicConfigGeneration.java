package generator.kontroller.featureFabrik.fabrikImplementation;

import generator.configurator.BasicConfiguration;
import generator.kontroller.featureFabrik.FeatureGenerator;
import utils.generator.handler.AstTransformationHandler;

/**
 * This component is a concrete feature generator to generate the first features in group "Uebung1"
 * for both class PizzaVO and ChefVO
 * @author forest
 *
 */
public class BasicConfigGeneration extends FeatureGenerator {

	private String javaFileName;

	public String getJavaFileName() {
		return javaFileName;
	}

	public void setJavaFileName(String javaFileName) {
		this.javaFileName = javaFileName;
	}

	@Override
	protected AstTransformationHandler handleKonfiguration() {
		return new BasicConfiguration(javaFileName);
	}

}
