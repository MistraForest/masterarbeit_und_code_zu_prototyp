package generator.kontroller.featureFabrik.fabrikImplementation;

import generator.configurator.WithoutSetterCheckConfiguration;
import generator.kontroller.featureFabrik.FeatureGenerator;
import utils.generator.handler.AstTransformationHandler;

/**
 * This component is a concrete feature generator that generate the alternative setter 
 * method without additional check condition on an attribute not to take negative values.
 * 
 * This variant is discourage to use in a production environment. 
 * @author forest
 *
 */
public class WithoutSetterCheckConfigGeneration extends FeatureGenerator {

	private String setter;
	private String javaFileName;
	
	@Override
	protected AstTransformationHandler handleKonfiguration() {
		return new WithoutSetterCheckConfiguration(setter, javaFileName);
	}

	public String getSetter() {
		return setter;
	}

	public void setSetter(String setter) {
		this.setter = setter;
	}

	public String getJavaFileName() {
		return javaFileName;
	}

	public void setJavaFileName(String javaFileName) {
		this.javaFileName = javaFileName;
	}

}
