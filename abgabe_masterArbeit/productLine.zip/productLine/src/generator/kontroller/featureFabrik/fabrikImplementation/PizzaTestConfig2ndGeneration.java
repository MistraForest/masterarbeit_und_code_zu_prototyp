package generator.kontroller.featureFabrik.fabrikImplementation;

import generator.configurator.TestBasicVariantConfiguration;
import generator.kontroller.featureFabrik.FeatureGenerator;
import utils.generator.handler.AstTransformationHandler;

/**
 * This component is a concrete feature generator that generate the tests for
 * the class PizzaVO in the feature group "Uebung2"
 * @author forest
 *
 */
public class PizzaTestConfig2ndGeneration extends FeatureGenerator {

	private String clazzUnderTest;
	private String testClazz;
	
	@Override
	protected AstTransformationHandler handleKonfiguration() {
		return new TestBasicVariantConfiguration(testClazz, clazzUnderTest);
	}

	public String getClazzUnderTest() {
		return clazzUnderTest;
	}

	public void setClazzUnderTest(String clazzUnderTest) {
		this.clazzUnderTest = clazzUnderTest;
	}

	public String getTestClazz() {
		return testClazz;
	}

	public void setTestClazz(String testClazz) {
		this.testClazz = testClazz;
	}

}
