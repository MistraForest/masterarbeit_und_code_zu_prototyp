package generator.kontroller.featureFabrik.fabrikImplementation;

import generator.configurator.AssociationConfiguration;
import generator.kontroller.featureFabrik.FeatureGenerator;
import utils.generator.handler.AstTransformationHandler;

/**
 * This component is a concrete feature generator to generate the test class of the
 * association relationship
 * @author forest
 *
 */
public class AssociationTestClazzGeneration extends FeatureGenerator {

	private String associationClazzFile;

	@Override
	protected AstTransformationHandler handleKonfiguration() {
		return new AssociationConfiguration(associationClazzFile).getAssociationTestGeneration();
	}

	public String getAssociationClazzFile() {
		return associationClazzFile;
	}

	public void setAssociationClazzFile(String associationClazzFile) {
		this.associationClazzFile = associationClazzFile;
	}

}
