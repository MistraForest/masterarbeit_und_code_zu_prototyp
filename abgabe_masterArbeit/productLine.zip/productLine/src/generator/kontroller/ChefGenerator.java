package generator.kontroller;

import java.io.File;

import generator.configurator.TestChefBasicVariantConfiguration;
import generator.kontroller.featureFabrik.fabrikImplementation.BasicConfigGeneration;
import generator.kontroller.featureFabrik.fabrikImplementation.BasicTestConfigGeneration;
import generator.kontroller.featureFabrik.fabrikImplementation.Chef3rdFeatureConfigGeneration;
import generator.kontroller.featureFabrik.fabrikImplementation.ChefTestConfig2ndGeneration;
import generator.kontroller.featureFabrik.fabrikImplementation.ChefthirdFeatureTestConfigGeneration;
import generator.kontroller.featureFabrik.fabrikImplementation.ConstructorConfigGeneration;
import generator.kontroller.featureFabrik.fabrikImplementation.EqualsImplicitNullCheckWithInstanceOfConfigGeneration;
import generator.kontroller.featureFabrik.fabrikImplementation.EqualsImplicitNullCheckWithoutInstanceOfConfigGeneration;
import generator.kontroller.featureFabrik.fabrikImplementation.EqualsNullCheckWithInstanceOfGeneration;
import generator.kontroller.featureFabrik.fabrikImplementation.EqualsNullCheckWithoutInstanceOfGeneration;
import generator.kontroller.featureFabrik.fabrikImplementation.FirstConstructorTestGeneration;
import generator.kontroller.featureFabrik.fabrikImplementation.HashLongVariantConfigGeneration;
import generator.kontroller.featureFabrik.fabrikImplementation.HashShortVariantConfigGeneration;
import generator.kontroller.featureFabrik.fabrikImplementation.SecondConstructorTestGeneration;
import generator.kontroller.featureFabrik.fabrikImplementation.ToString1stOptionConfigGeneration;
import generator.kontroller.featureFabrik.fabrikImplementation.ToStringConfigGeneration;
import generator.kontroller.featureFabrik.fabrikImplementation.ToStringTest2ndOptionConfigGeneration;
import utils.DirExplorerUtil;
import utils.FilterUtil.FileNameFilter;
import utils.generator.handler.AstTransformationHandler;
import utils.generator.handler.Filter;

/**
 * This class hold all the different feature creators for the class ChefVO
 * @author forest
 *
 */
public class ChefGenerator {

	private String javaFileName;
	private AstTransformationHandler handler;
	private Filter filter;
	
	private BasicConfigGeneration basicConfigGeneration;
	private BasicTestConfigGeneration basicTestConfigGeneration;
	private ConstructorConfigGeneration constructorConfigGeneration;
	private SecondConstructorTestGeneration secondConstructorTestGeneration;
	private FirstConstructorTestGeneration firstConstructorTestGeneration;
	private EqualsNullCheckWithInstanceOfGeneration equalsExplicitNullCheckWithInstanceOf;
	private ChefTestConfig2ndGeneration chefTestConfig2ndGeneration;
	private HashShortVariantConfigGeneration hashShortVariantConfigGeneration;
	private ToStringConfigGeneration toStringConfigGeneration;
	private EqualsNullCheckWithoutInstanceOfGeneration equalsExplicitNullCheckWithoutInstanceOf;
	private HashLongVariantConfigGeneration hashLongVariantConfigGeneration;
	private ToStringTest2ndOptionConfigGeneration toString2ndOptionConfigGeneration;
	private ToString1stOptionConfigGeneration toString1stOptionConfigGeneration;
	private EqualsImplicitNullCheckWithInstanceOfConfigGeneration implicitNullCheckWithInstanceOf;
	private EqualsImplicitNullCheckWithoutInstanceOfConfigGeneration implicitNullCheckWithoutInstanceOf;
	private Chef3rdFeatureConfigGeneration chef3rdConfigGeneration;
	private ChefthirdFeatureTestConfigGeneration chefthirdFeatureTestConfigGeneration;

	public ChefGenerator(String javaFileName) {
		this.javaFileName = javaFileName;
		this.filter = new FileNameFilter(javaFileName);
		
		this.basicConfigGeneration = new BasicConfigGeneration();
		this.basicTestConfigGeneration = new BasicTestConfigGeneration();
		this.setConstructorConfigGeneration(new ConstructorConfigGeneration(javaFileName));
		this.setSecondConstructorTest(new SecondConstructorTestGeneration());
		this.setFirstConstructorTestGeneration(new FirstConstructorTestGeneration());
		this.setEqualsExplicitNullCheckWithInstanceOf(new EqualsNullCheckWithInstanceOfGeneration());
		this.setChefTestConfig2ndGeneration(new ChefTestConfig2ndGeneration());
		this.setHashShortVariantConfigGeneration(new HashShortVariantConfigGeneration());
		this.setToStringConfigGeneration(new ToStringConfigGeneration());
		this.setEqualsExplicitNullCheckWithoutInstanceOf(new EqualsNullCheckWithoutInstanceOfGeneration());
		this.setHashLongVariantConfigGeneration(new HashLongVariantConfigGeneration());
		this.setToString2ndOptionConfigGeneration(new ToStringTest2ndOptionConfigGeneration());
		this.setToString1stOptionConfigGeneration(new ToString1stOptionConfigGeneration());
		this.setImplicitNullCheckWithInstanceOf(new EqualsImplicitNullCheckWithInstanceOfConfigGeneration());
		this.setImplicitNullCheckWithoutInstanceOf(new EqualsImplicitNullCheckWithoutInstanceOfConfigGeneration());
		this.setChef3rdConfigGeneration(new Chef3rdFeatureConfigGeneration());
		this.setChefthirdFeatureTestConfigGeneration(new ChefthirdFeatureTestConfigGeneration());
	}

	// Element of core asset to be reused in different variants
	public void basicVariantTestConfiguration(File projectDir, String clazzName) {
		this.handler = new TestChefBasicVariantConfiguration(javaFileName, clazzName);

		new DirExplorerUtil(filter, handler).explore(projectDir);
	}

	// Element of core asset to be reused in different variants
	public BasicConfigGeneration getBasicConfigGeneration() {
		return basicConfigGeneration;
	}

	public void setBasicConfigGeneration(BasicConfigGeneration basicConfigGeneration) {
		this.basicConfigGeneration = basicConfigGeneration;
	}

	public BasicTestConfigGeneration getBasicTestConfigGeneration() {
		return basicTestConfigGeneration;
	}

	public void setBasicTestConfigGeneration(BasicTestConfigGeneration basicTestConfigGeneration) {
		this.basicTestConfigGeneration = basicTestConfigGeneration;
	}

	public ConstructorConfigGeneration getConstructorConfigGeneration() {
		return constructorConfigGeneration;
	}

	public void setConstructorConfigGeneration(ConstructorConfigGeneration constructorConfigGeneration) {
		this.constructorConfigGeneration = constructorConfigGeneration;
	}

	public SecondConstructorTestGeneration getSecondConstructorTest() {
		return secondConstructorTestGeneration;
	}

	public void setSecondConstructorTest(SecondConstructorTestGeneration secondConstructorTest) {
		this.secondConstructorTestGeneration = secondConstructorTest;
	}
//
	public FirstConstructorTestGeneration getFirstConstructorTestGeneration() {
		return firstConstructorTestGeneration;
	}

	public void setFirstConstructorTestGeneration(FirstConstructorTestGeneration firstConstructorTestGeneration) {
		this.firstConstructorTestGeneration = firstConstructorTestGeneration;
	}

	public EqualsNullCheckWithInstanceOfGeneration getEqualsExplicitNullCheckWithInstanceOf() {
		return equalsExplicitNullCheckWithInstanceOf;
	}

	public void setEqualsExplicitNullCheckWithInstanceOf(EqualsNullCheckWithInstanceOfGeneration equalsExplicitNullCheckWithInstanceOf) {
		this.equalsExplicitNullCheckWithInstanceOf = equalsExplicitNullCheckWithInstanceOf;
	}

	public ChefTestConfig2ndGeneration getChefTestConfig2ndGeneration() {
		return chefTestConfig2ndGeneration;
	}

	public void setChefTestConfig2ndGeneration(ChefTestConfig2ndGeneration chefTestConfig2ndGeneration) {
		this.chefTestConfig2ndGeneration = chefTestConfig2ndGeneration;
	}

	public HashShortVariantConfigGeneration getHashShortVariantConfigGeneration() {
		return hashShortVariantConfigGeneration;
	}

	public void setHashShortVariantConfigGeneration(HashShortVariantConfigGeneration hashShortVariantConfigGeneration) {
		this.hashShortVariantConfigGeneration = hashShortVariantConfigGeneration;
	}

	public ToStringConfigGeneration getToStringConfigGeneration() {
		return toStringConfigGeneration;
	}

	public void setToStringConfigGeneration(ToStringConfigGeneration toStringConfigGeneration) {
		this.toStringConfigGeneration = toStringConfigGeneration;
	}


	public EqualsNullCheckWithoutInstanceOfGeneration getEqualsExplicitNullCheckWithoutInstanceOf() {
		return equalsExplicitNullCheckWithoutInstanceOf;
	}


	public void setEqualsExplicitNullCheckWithoutInstanceOf(EqualsNullCheckWithoutInstanceOfGeneration equalsExplicitNullCheckWithoutInstanceOf) {
		this.equalsExplicitNullCheckWithoutInstanceOf = equalsExplicitNullCheckWithoutInstanceOf;
	}


	public HashLongVariantConfigGeneration getHashLongVariantConfigGeneration() {
		return hashLongVariantConfigGeneration;
	}


	public void setHashLongVariantConfigGeneration(HashLongVariantConfigGeneration hashLongVariantConfigGeneration) {
		this.hashLongVariantConfigGeneration = hashLongVariantConfigGeneration;
	}


	public ToStringTest2ndOptionConfigGeneration getToString2ndOptionConfigGeneration() {
		return toString2ndOptionConfigGeneration;
	}


	public void setToString2ndOptionConfigGeneration(ToStringTest2ndOptionConfigGeneration toString2ndOptionConfigGeneration) {
		this.toString2ndOptionConfigGeneration = toString2ndOptionConfigGeneration;
	}


	public EqualsImplicitNullCheckWithInstanceOfConfigGeneration getImplicitNullCheckWithInstanceOf() {
		return implicitNullCheckWithInstanceOf;
	}


	public void setImplicitNullCheckWithInstanceOf(EqualsImplicitNullCheckWithInstanceOfConfigGeneration implicitNullCheckWithInstanceOf) {
		this.implicitNullCheckWithInstanceOf = implicitNullCheckWithInstanceOf;
	}


	public ToString1stOptionConfigGeneration getToString1stOptionConfigGeneration() {
		return toString1stOptionConfigGeneration;
	}


	public void setToString1stOptionConfigGeneration(ToString1stOptionConfigGeneration toString1stOptionConfigGeneration) {
		this.toString1stOptionConfigGeneration = toString1stOptionConfigGeneration;
	}


	public EqualsImplicitNullCheckWithoutInstanceOfConfigGeneration getImplicitNullCheckWithoutInstanceOf() {
		return implicitNullCheckWithoutInstanceOf;
	}


	public void setImplicitNullCheckWithoutInstanceOf(EqualsImplicitNullCheckWithoutInstanceOfConfigGeneration implicitNullCheckWithoutInstanceOf) {
		this.implicitNullCheckWithoutInstanceOf = implicitNullCheckWithoutInstanceOf;
	}


	public Chef3rdFeatureConfigGeneration getChef3rdConfigGeneration() {
		return chef3rdConfigGeneration;
	}


	public void setChef3rdConfigGeneration(Chef3rdFeatureConfigGeneration chef3rdConfigGeneration) {
		this.chef3rdConfigGeneration = chef3rdConfigGeneration;
	}


	public ChefthirdFeatureTestConfigGeneration getChefthirdFeatureTestConfigGeneration() {
		return chefthirdFeatureTestConfigGeneration;
	}


	public void setChefthirdFeatureTestConfigGeneration(ChefthirdFeatureTestConfigGeneration chefthirdFeatureTestConfig) {
		this.chefthirdFeatureTestConfigGeneration = chefthirdFeatureTestConfig;
	}


}
