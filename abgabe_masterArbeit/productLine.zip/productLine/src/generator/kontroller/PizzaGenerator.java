package generator.kontroller;

import java.io.File;

import generator.configurator.TestBasicVariantConfiguration;
import generator.kontroller.featureFabrik.fabrikImplementation.BasicConfigGeneration;
import generator.kontroller.featureFabrik.fabrikImplementation.BasicTestConfigGeneration;
import generator.kontroller.featureFabrik.fabrikImplementation.CloneConfigGeneration;
import generator.kontroller.featureFabrik.fabrikImplementation.ConstructorConfigGeneration;
import generator.kontroller.featureFabrik.fabrikImplementation.EqualsImplicitNullCheckWithInstanceOfConfigGeneration;
import generator.kontroller.featureFabrik.fabrikImplementation.EqualsImplicitNullCheckWithoutInstanceOfConfigGeneration;
import generator.kontroller.featureFabrik.fabrikImplementation.EqualsNullCheckWithInstanceOfGeneration;
import generator.kontroller.featureFabrik.fabrikImplementation.EqualsNullCheckWithoutInstanceOfGeneration;
import generator.kontroller.featureFabrik.fabrikImplementation.FirstPizzaConstructorConfigGeneration;
import generator.kontroller.featureFabrik.fabrikImplementation.HashLongVariantConfigGeneration;
import generator.kontroller.featureFabrik.fabrikImplementation.HashShortVariantConfigGeneration;
import generator.kontroller.featureFabrik.fabrikImplementation.Pizza3rdFeatureConfigGeneration;
import generator.kontroller.featureFabrik.fabrikImplementation.PizzaTestConfig2ndGeneration;
import generator.kontroller.featureFabrik.fabrikImplementation.PizzaThirdFeatureTestConfigGeneration;
import generator.kontroller.featureFabrik.fabrikImplementation.SecondPizzaConstructorOptionConfigGeneration;
import generator.kontroller.featureFabrik.fabrikImplementation.ToStringConfigGeneration;
import generator.kontroller.featureFabrik.fabrikImplementation.ToString_01_OptionConfigGeneration;
import generator.kontroller.featureFabrik.fabrikImplementation.ToString_02_OptionConfigGeneration;
import generator.kontroller.featureFabrik.fabrikImplementation.WithoutSetterCheckConfigGeneration;
import utils.DirExplorerUtil;
import utils.generator.handler.AstTransformationHandler;
import utils.generator.handler.Filter;

/**
 * This class hold all the different feature creators for the class PizzaVO
 * @author forest
 *
 */
public class PizzaGenerator {

	private String javaFileName;
	private AstTransformationHandler handler;
	private Filter filter;
	
	private BasicConfigGeneration basicConfigGeneration;
	private BasicTestConfigGeneration basicTestConfigGeneration;
	private ConstructorConfigGeneration constructorConfigGeneration;
	private SecondPizzaConstructorOptionConfigGeneration secondPizzaConstructorTestGeneration;
	private FirstPizzaConstructorConfigGeneration firstPizzaConstructorConfigGeneration;
	private WithoutSetterCheckConfigGeneration setterCheckConfigGeneration;
	private CloneConfigGeneration cloneConfigGeneration;
	private EqualsNullCheckWithInstanceOfGeneration equalsExplicitNullCheckWithInstanceOf;
	private EqualsNullCheckWithoutInstanceOfGeneration equalsExplicitNullCheckWithoutInstanceOf;
	private EqualsImplicitNullCheckWithInstanceOfConfigGeneration implicitNullCheckWithInstanceOf;
	private EqualsImplicitNullCheckWithoutInstanceOfConfigGeneration implicitNullCheckWithoutInstanceOf;
	private HashShortVariantConfigGeneration hashShortVariantConfigGeneration;
	private HashLongVariantConfigGeneration hashLongVariantConfigGeneration;
	private ToStringConfigGeneration toStringConfigGeneration;
	private ToString_02_OptionConfigGeneration toString_02_OptionConfigGeneration;
	private ToString_01_OptionConfigGeneration toString_01_OptionConfigGeneration;
	private PizzaTestConfig2ndGeneration testConfig2ndGeneration;
	private Pizza3rdFeatureConfigGeneration pizza3rdFeatureConfigGeneration;
	private PizzaThirdFeatureTestConfigGeneration pizzaThirdFeatureTestConfigGeneration;

	public PizzaGenerator(String javaFileName) {
		this.javaFileName = javaFileName;
//		this.filter = new FileNameFilter(javaFileName);
		
		this.basicConfigGeneration = new BasicConfigGeneration();
		this.setBasicTestConfigGeneration(new BasicTestConfigGeneration());
		this.constructorConfigGeneration = new ConstructorConfigGeneration(javaFileName);
		this.secondPizzaConstructorTestGeneration = new SecondPizzaConstructorOptionConfigGeneration();
		this.setFirstPizzaConstructorConfigGeneration(new FirstPizzaConstructorConfigGeneration());
		this.setSetterCheckConfigGeneration(new WithoutSetterCheckConfigGeneration());
		this.setCloneConfigGeneration(new CloneConfigGeneration());
		this.setEqualsExplicitNullCheckWithInstanceOf(new EqualsNullCheckWithInstanceOfGeneration());
		this.setEqualsExplicitNullCheckWithoutInstanceOf(new EqualsNullCheckWithoutInstanceOfGeneration());
		this.setImplicitNullCheckWithInstanceOf(new EqualsImplicitNullCheckWithInstanceOfConfigGeneration());
		this.setImplicitNullCheckWithoutInstanceOf(new EqualsImplicitNullCheckWithoutInstanceOfConfigGeneration());
		this.setHashShortVariantConfigGeneration(new HashShortVariantConfigGeneration());
		this.setHashLongVariantConfigGeneration(new HashLongVariantConfigGeneration());
		this.setToStringConfigGeneration(new ToStringConfigGeneration());
		this.setTestConfig2ndGeneration(new PizzaTestConfig2ndGeneration());
		this.setToString_02_OptionConfigGeneration(new ToString_02_OptionConfigGeneration());
		this.setToString_01_OptionConfigGeneration(new ToString_01_OptionConfigGeneration());
		this.setPizza3rdFeatureConfigGeneration(new Pizza3rdFeatureConfigGeneration());
		this.setPizzaThirdFeatureTestConfigGeneration(new PizzaThirdFeatureTestConfigGeneration());
	}

	// Element of core asset to be reused in different variants
	public void basicVariantTestConfiguration(File projectDir, String clazzUnderTest) {
		this.handler = new TestBasicVariantConfiguration(javaFileName, clazzUnderTest);

		new DirExplorerUtil(filter, handler).explore(projectDir);
	}

	public BasicConfigGeneration getBasicConfigGeneration() {
		return basicConfigGeneration;
	}

	public void setBasicConfigGeneration(BasicConfigGeneration basicConfigGeneration) {
		this.basicConfigGeneration = basicConfigGeneration;
	}

	public BasicTestConfigGeneration getBasicTestConfigGeneration() {
		return basicTestConfigGeneration;
	}

	public void setBasicTestConfigGeneration(BasicTestConfigGeneration basicTestConfigGeneration) {
		this.basicTestConfigGeneration = basicTestConfigGeneration;
	}

	public ConstructorConfigGeneration getConstructorConfigGeneration() {
		return constructorConfigGeneration;
	}

	public void setConstructorConfigGeneration(ConstructorConfigGeneration constructorConfigGeneration) {
		this.constructorConfigGeneration = constructorConfigGeneration;
	}

	public SecondPizzaConstructorOptionConfigGeneration getSecondPizzaConstructorTestGeneration() {
		return secondPizzaConstructorTestGeneration;
	}

	public void setSecondPizzaConstructorTestGeneration(SecondPizzaConstructorOptionConfigGeneration secondPizzaConstructorTestGeneration) {
		this.secondPizzaConstructorTestGeneration = secondPizzaConstructorTestGeneration;
	}

	public FirstPizzaConstructorConfigGeneration getFirstPizzaConstructorConfigGeneration() {
		return firstPizzaConstructorConfigGeneration;
	}

	public void setFirstPizzaConstructorConfigGeneration(FirstPizzaConstructorConfigGeneration firstPizzaConstructorConfigGeneration) {
		this.firstPizzaConstructorConfigGeneration = firstPizzaConstructorConfigGeneration;
	}

	public WithoutSetterCheckConfigGeneration getSetterCheckConfigGeneration() {
		return setterCheckConfigGeneration;
	}

	public void setSetterCheckConfigGeneration(WithoutSetterCheckConfigGeneration setterCheckConfigGeneration) {
		this.setterCheckConfigGeneration = setterCheckConfigGeneration;
	}

	public CloneConfigGeneration getCloneConfigGeneration() {
		return cloneConfigGeneration;
	}

	public void setCloneConfigGeneration(CloneConfigGeneration cloneConfigGeneration) {
		this.cloneConfigGeneration = cloneConfigGeneration;
	}

	public EqualsNullCheckWithInstanceOfGeneration getEqualsExplicitNullCheckWithInstanceOf() {
		return equalsExplicitNullCheckWithInstanceOf;
	}

	public void setEqualsExplicitNullCheckWithInstanceOf(EqualsNullCheckWithInstanceOfGeneration equalsExplicitNullCheckWithInstanceOf) {
		this.equalsExplicitNullCheckWithInstanceOf = equalsExplicitNullCheckWithInstanceOf;
	}

	public HashShortVariantConfigGeneration getHashShortVariantConfigGeneration() {
		return hashShortVariantConfigGeneration;
	}

	public void setHashShortVariantConfigGeneration(HashShortVariantConfigGeneration hashShortVariantConfigGeneration) {
		this.hashShortVariantConfigGeneration = hashShortVariantConfigGeneration;
	}

	public HashLongVariantConfigGeneration getHashLongVariantConfigGeneration() {
		return hashLongVariantConfigGeneration;
	}

	public void setHashLongVariantConfigGeneration(HashLongVariantConfigGeneration hashLongVariantConfigGeneration) {
		this.hashLongVariantConfigGeneration = hashLongVariantConfigGeneration;
	}

	public ToStringConfigGeneration getToStringConfigGeneration() {
		return toStringConfigGeneration;
	}

	public void setToStringConfigGeneration(ToStringConfigGeneration toStringConfigGeneration) {
		this.toStringConfigGeneration = toStringConfigGeneration;
	}

	public PizzaTestConfig2ndGeneration getTestConfig2ndGeneration() {
		return testConfig2ndGeneration;
	}

	public void setTestConfig2ndGeneration(PizzaTestConfig2ndGeneration testConfig2ndGeneration) {
		this.testConfig2ndGeneration = testConfig2ndGeneration;
	}

	public EqualsNullCheckWithoutInstanceOfGeneration getEqualsExplicitNullCheckWithoutInstanceOf() {
		return equalsExplicitNullCheckWithoutInstanceOf;
	}

	public void setEqualsExplicitNullCheckWithoutInstanceOf(EqualsNullCheckWithoutInstanceOfGeneration equalsExplicitNullCheckWithoutInstanceOf) {
		this.equalsExplicitNullCheckWithoutInstanceOf = equalsExplicitNullCheckWithoutInstanceOf;
	}

	public ToString_02_OptionConfigGeneration getToString_02_OptionConfigGeneration() {
		return toString_02_OptionConfigGeneration;
	}

	public void setToString_02_OptionConfigGeneration(ToString_02_OptionConfigGeneration toString02OptionConfigGeneration) {
		this.toString_02_OptionConfigGeneration = toString02OptionConfigGeneration;
	}

	public ToString_01_OptionConfigGeneration getToString_01_OptionConfigGeneration() {
		return toString_01_OptionConfigGeneration;
	}

	public void setToString_01_OptionConfigGeneration(ToString_01_OptionConfigGeneration toString_01_OptionConfigGeneration) {
		this.toString_01_OptionConfigGeneration = toString_01_OptionConfigGeneration;
	}

	public EqualsImplicitNullCheckWithoutInstanceOfConfigGeneration getImplicitNullCheckWithoutInstanceOf() {
		return implicitNullCheckWithoutInstanceOf;
	}

	public void setImplicitNullCheckWithoutInstanceOf(EqualsImplicitNullCheckWithoutInstanceOfConfigGeneration implicitNullCheckWithoutInstanceOf) {
		this.implicitNullCheckWithoutInstanceOf = implicitNullCheckWithoutInstanceOf;
	}

	public EqualsImplicitNullCheckWithInstanceOfConfigGeneration getImplicitNullCheckWithInstanceOf() {
		return implicitNullCheckWithInstanceOf;
	}

	public void setImplicitNullCheckWithInstanceOf(EqualsImplicitNullCheckWithInstanceOfConfigGeneration implicitNullCheckWithInstanceOf) {
		this.implicitNullCheckWithInstanceOf = implicitNullCheckWithInstanceOf;
	}

	public Pizza3rdFeatureConfigGeneration getPizza3rdFeatureConfigGeneration() {
		return pizza3rdFeatureConfigGeneration;
	}

	public void setPizza3rdFeatureConfigGeneration(Pizza3rdFeatureConfigGeneration pizza3rdFeatureConfigGeneration) {
		this.pizza3rdFeatureConfigGeneration = pizza3rdFeatureConfigGeneration;
	}

	public PizzaThirdFeatureTestConfigGeneration getPizzaThirdFeatureTestConfigGeneration() {
		return pizzaThirdFeatureTestConfigGeneration;
	}

	public void setPizzaThirdFeatureTestConfigGeneration(PizzaThirdFeatureTestConfigGeneration pizzaThirdFeatureTestConfigGeneration) {
		this.pizzaThirdFeatureTestConfigGeneration = pizzaThirdFeatureTestConfigGeneration;
	}

}
