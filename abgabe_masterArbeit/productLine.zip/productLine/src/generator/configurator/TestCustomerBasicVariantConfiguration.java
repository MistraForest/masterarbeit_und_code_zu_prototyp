package generator.configurator;

import java.io.File;
import java.io.FileNotFoundException;

import generator.astvisitor.CustomerBasicVariantTestASTVisitor;
import utils.generator.handler.AstTransformationHandler;

/**
 * The concrete configuration of the test class of CustomerVO based on {@TestBasicConfiguration}.
 * The visitor component which used the JavaParser library will visit the AST and look up the 
 * corresponding nodes
 * @author forest
 *
 */
public class TestCustomerBasicVariantConfiguration implements AstTransformationHandler {
	
	private String javaFileName;
	private String clazzName;
	

	public TestCustomerBasicVariantConfiguration(String javaFileName, String clazzName) {
		this.javaFileName = javaFileName;
		this.clazzName = clazzName;
	}


	@Override
	public void modifyAST(int level, String path, File file) {
		try {
			new CustomerBasicVariantTestASTVisitor(javaFileName, clazzName)  
				.visit(ASTParserService.parse(file), null);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}	}

}
