package generator.configurator;

import java.io.File;
import java.io.FileNotFoundException;

import generator.astvisitor.ConstructorVisitor;
import utils.generator.handler.AstTransformationHandler;

/**
 * The concrete configuration of the constructor feature.
 * The visitor component which used the JavaParser library will visit the AST and look up the 
 * corresponding nodes
 * @author forest
 *
 */
public class ConstructorConfiguration implements AstTransformationHandler{

	private int paramNumber;
	private String javaFileName;

	public ConstructorConfiguration(int paramNumber, String javaFileName) {
		this.paramNumber = paramNumber;
		this.javaFileName = javaFileName;
	}

	@Override
	public void modifyAST(int level, String path, File file) {
		
		try {
			new ConstructorVisitor(paramNumber, javaFileName)
				.visit(ASTParserService.parse(file), null);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}		
	}
}
