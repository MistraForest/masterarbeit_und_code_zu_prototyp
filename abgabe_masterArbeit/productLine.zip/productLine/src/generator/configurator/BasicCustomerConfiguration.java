package generator.configurator;

import java.io.File;
import java.io.FileNotFoundException;

import generator.astvisitor.BasicCustomerASTVisitor;
import utils.generator.handler.AstTransformationHandler;

/**
 * The concrete configuration of the feature selection in the first feature group "Uebung1"
 * The visitor component which used the JavaParser library will visit the AST and look up the 
 * corresponding nodes
 * @author forest
 *
 */
public class BasicCustomerConfiguration implements AstTransformationHandler {
	
	private BasicCustomerASTVisitor basicASTVisitor;
	
	public BasicCustomerConfiguration(String javaFileName) {
		this.basicASTVisitor = new BasicCustomerASTVisitor(javaFileName);
	}

	@Override
	public void modifyAST(int level, String path, File file) {
		try {
			basicASTVisitor.visit(ASTParserService.parse(file), null);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
	}

}
