package generator.configurator;

import java.io.File;
import java.io.FileNotFoundException;

import generator.astvisitor.Gui2ndASTVisitor;
import utils.generator.handler.AstTransformationHandler;

/**
 * The configuration of the GUI in the second feature group "Uebung2"
 * The visitor component which used the JavaParser library will visit the AST and look up the 
 * corresponding nodes
 * @author forest
 *
 */
public class GUI2ndConfiguration implements AstTransformationHandler {

	@Override
	public void modifyAST(int level, String path, File file) {
		
		try {
			new Gui2ndASTVisitor(file).visit(ASTParserService.parse(file), null);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}

	}

}
