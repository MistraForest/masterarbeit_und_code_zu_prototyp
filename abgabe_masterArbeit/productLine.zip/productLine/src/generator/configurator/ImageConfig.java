package generator.configurator;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;

import utils.DirCreatorUtil;
import utils.generator.handler.AstTransformationHandler;

/**
 * This class import the images necessary in the GUI application
 * @author forest
 *
 */
public class ImageConfig implements AstTransformationHandler {

	private String imagesDir;
	private String imagesType;
	
	public ImageConfig(String imagesDir, String imagesType) {
		this.imagesDir = imagesDir;
		this.imagesType = imagesType;
	}
	
	@Override
	public void modifyAST(int level, String path, File file) {
		
		filter(file, imagesDir);
	}
	
	private void filter(File file, String imagesDir) {

		DirCreatorUtil.createDir(imagesDir);
		
		if(file.getName().endsWith(imagesType)) {			
			try {
				insertToPath(file.getPath(), imagesDir+file.getName());
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	
	private void insertToPath(String source, String target) throws IOException {
        
            try {
                Files.copy(
                		Paths.get(source), 
                		Paths.get(target),
                        StandardCopyOption.REPLACE_EXISTING);
            } catch (IOException e) {
                e.printStackTrace();
            }
	}
}
