package generator.configurator;

import java.io.File;
import java.io.FileNotFoundException;

import generator.astvisitor.WithoutSetterCheckAstVisitor;
import utils.generator.handler.AstTransformationHandler;

/**
 * The concrete configuration of the setter method feature without additional check for the price attribute.
 * The visitor component which used the JavaParser library will visit the AST and look up the 
 * corresponding nodes.
 * 
 * @author forest
 *
 */
public class WithoutSetterCheckConfiguration implements AstTransformationHandler {
	
	private WithoutSetterCheckAstVisitor astVisitor;

	public WithoutSetterCheckConfiguration(String setter, String javaFileName ) {
		this.astVisitor = new WithoutSetterCheckAstVisitor(setter, javaFileName);
	}

	@Override
	public void modifyAST(int level, String path, File file) {
		try {
			this.astVisitor.visit(ASTParserService.parse(file), null);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
	}

}
