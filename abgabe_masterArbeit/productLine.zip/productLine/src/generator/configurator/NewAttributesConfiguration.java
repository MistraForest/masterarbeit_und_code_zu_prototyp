package generator.configurator;

import java.io.File;
import java.io.FileNotFoundException;

import generator.astvisitor.AttributesVariantVisitor;
import utils.generator.handler.AstTransformationHandler;

/**
 * The concrete configuration of the new fields in the second feature group "Uebung2"
 * The visitor component which used the JavaParser library will visit the AST and look up the 
 * corresponding nodes
 * @author forest
 *
 */
public class NewAttributesConfiguration {

	private String javaFileName;

	public NewAttributesConfiguration(String javaFileName) {
		this.javaFileName = javaFileName;
	}

	public NewAttributesVariantConfig getNewAttributesVariantConfig(String[] parameters) {
	
		return new NewAttributesVariantConfig(parameters);
	}

	public class NewAttributesVariantConfig implements AstTransformationHandler {
		String[] parameters;
		
		public NewAttributesVariantConfig(String[] parameters) {
			this.parameters = parameters;
		}

		@Override
		public void modifyAST(int level, String path, File file) {
			try {
				new AttributesVariantVisitor(javaFileName).getWithConstructorVariant(parameters).visit(ASTParserService.parse(file),
						null);
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			}

		}

	}

}
