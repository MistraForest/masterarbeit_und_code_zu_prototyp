package generator.configurator;

import java.io.File;
import java.io.FileNotFoundException;

import generator.astvisitor.AssociationASTVisitor;
import utils.generator.handler.AstTransformationHandler;

/**
 * This class hold the references of the concrete configuration regarding the association relationship.
 */
public class AssociationConfiguration{

	
	private String javaFile;
	
	public AssociationConfiguration(String javaFile) {
		this.javaFile = javaFile;
	}

	public class StringMethodManagementConfig implements AstTransformationHandler{
		@Override
		public void modifyAST(int level, String path, File file) {
			try {
				new AssociationASTVisitor(javaFile).getStringVariantWithLessEfficiency()  
				.visit(ASTParserService.parse(file), null);
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			}

		}
	}

	public class StringBufferMethodManagementConfig implements AstTransformationHandler {

		private String methodName;
		
		public StringBufferMethodManagementConfig(String methodName) {
			this.methodName = methodName;
		}

		@Override
		public void modifyAST(int level, String path, File file) {
			
			try {
				new AssociationASTVisitor(javaFile).getStringBufferVariantWithBetterEfficiency(methodName)  
				.visit(ASTParserService.parse(file), null);
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			}
		}
	}
	
	public class AssociationTestGenerationConfig implements AstTransformationHandler {

		@Override
		public void modifyAST(int level, String path, File file) {
			try {
				new AssociationASTVisitor(javaFile).getAssiociationTest()  
				.visit(ASTParserService.parse(file), null);
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			}
		}

	}

	
	public AstTransformationHandler getMethoManagementWithString() {
		return new  StringMethodManagementConfig();
	}

	public AstTransformationHandler getMethodManagementWithStringBuffer(String toStringWithStringBuffer) {
		
		return new StringBufferMethodManagementConfig(toStringWithStringBuffer);
	}

	public AstTransformationHandler getAssociationTestGeneration() {
		return new AssociationTestGenerationConfig();
	}
}
