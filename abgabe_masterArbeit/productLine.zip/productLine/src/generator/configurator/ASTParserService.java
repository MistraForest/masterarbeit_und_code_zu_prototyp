package generator.configurator;

import java.io.File;
import java.io.FileNotFoundException;

import com.github.javaparser.StaticJavaParser;
import com.github.javaparser.ast.CompilationUnit;

/**
 * This service use the JavaParser library to parse a compilation unit
 * @author forest
 *
 */
public class ASTParserService {
	/**
	 * The method transform a given java file to an compilation unit. The compilation unit is an AST
	 * representation of a class.	
	 * @param file: the given java file
	 * @return a compilation unit
	 * @throws FileNotFoundException : raised when the file is not found.
	 */
	public static CompilationUnit parse(File file) throws FileNotFoundException {
	
		return StaticJavaParser.parse(file);
	}

}
