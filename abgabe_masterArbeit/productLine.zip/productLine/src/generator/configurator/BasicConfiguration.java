package generator.configurator;

import java.io.File;
import java.io.FileNotFoundException;

import generator.astvisitor.BasicASTVisitor;
import utils.generator.handler.AstTransformationHandler;

/**
 *  This class hold the references of the concrete configuration regarding the first feature generation
 * @author forest
 *
 */
public class BasicConfiguration implements AstTransformationHandler{
	
	private BasicASTVisitor basicASTVisitor;

	public BasicConfiguration(String javaFileName) {
		this.basicASTVisitor = new BasicASTVisitor(javaFileName);
	}

	@Override
	public void modifyAST(int level, String path, File file) {

		try {
			basicASTVisitor.visit(ASTParserService.parse(file), null);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
	}
}
