package generator.configurator;

import java.io.File;
import java.io.FileNotFoundException;

import generator.astvisitor.BasicGUI_ASTVisitor;
import utils.generator.handler.AstTransformationHandler;

/**
 * The concrete configuration of the GUI form the first feature group "Uebung1"
 * The visitor component which used the JavaParser library will visit the AST and look up the 
 * corresponding nodes
 * @author forest
 *
 */
public class BasicGUIConfiguration implements AstTransformationHandler {

	@Override
	public void modifyAST(int level, String path, File file) {

		try {
			new BasicGUI_ASTVisitor(path, file).visit(ASTParserService.parse(file), null);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
	}
}
