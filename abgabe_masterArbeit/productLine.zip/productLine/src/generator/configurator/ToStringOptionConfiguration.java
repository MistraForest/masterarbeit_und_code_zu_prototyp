package generator.configurator;

import java.io.File;
import java.io.FileNotFoundException;

import generator.astvisitor.ToStringTestOptionVisitor;
import utils.generator.handler.AstTransformationHandler;

/**
 * The concrete configuration of the toString() test feature.
 * The visitor component which used the JavaParser library will visit the AST and look up the 
 * corresponding nodes
 * @author forest
 *
 */
public class ToStringOptionConfiguration {

	private String javaFileName;
	private String clazzName;
	
	public ToStringOptionConfiguration(String javaFileName, String clazzName) {
		this.javaFileName = javaFileName;
		this.clazzName = clazzName;
	}
	
	public class ToStringTest2ndOptionConfig implements AstTransformationHandler {

		@Override
		public void modifyAST(int level, String path, File file) {
			try {
				new ToStringTestOptionVisitor(javaFileName, clazzName).getToStringTest2ndOptionChefVisitor()
						.visit(ASTParserService.parse(file), null);
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			}

		}
	}
	
	public class ToString1stOptionTestConfig implements AstTransformationHandler {

		@Override
		public void modifyAST(int level, String path, File file) {
			try {
				new ToStringTestOptionVisitor(javaFileName, clazzName).getToString1stOptionChefVisitor()
						.visit(ASTParserService.parse(file), null);
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			}
		}

	}
	
	public class ToString03OptionTestConfig implements AstTransformationHandler {

		@Override
		public void modifyAST(int level, String path, File file) {
			try {
				new ToStringTestOptionVisitor(javaFileName, clazzName).getToString03OptionCustomerVisitor()
						.visit(ASTParserService.parse(file), null);
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			}
		}

	}
	
	public class ToString02OptionTestConfig implements AstTransformationHandler {

		@Override
		public void modifyAST(int level, String path, File file) {
			try {
				new ToStringTestOptionVisitor(javaFileName, clazzName).getToString02OptionCustomerVisitor()
						.visit(ASTParserService.parse(file), null);
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			}
		}

	}
	
	public class ToString01OptionTestConfig implements AstTransformationHandler {

		@Override
		public void modifyAST(int level, String path, File file) {
			try {
				new ToStringTestOptionVisitor(javaFileName, clazzName).getToString01OptionCustomerVisitor()
						.visit(ASTParserService.parse(file), null);
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			}
		}
	}

	public class ToString_02_OptionTestConfig implements AstTransformationHandler {

		@Override
		public void modifyAST(int level, String path, File file) {
			try {
				new ToStringTestOptionVisitor(javaFileName, clazzName).getToString_02_OptionCustomerVisitor()
						.visit(ASTParserService.parse(file), null);
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			}
		}
	}

	public class ToString_01_OptionTestConfig implements AstTransformationHandler {

		@Override
		public void modifyAST(int level, String path, File file) {
			try {
				new ToStringTestOptionVisitor(javaFileName, clazzName).getToString_01_OptionCustomerVisitor()
						.visit(ASTParserService.parse(file), null);
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			}
		}
	}
	
	public ToStringTest2ndOptionConfig toStringTest2ndOptionConfig() {
		return new ToStringTest2ndOptionConfig();
	}

	public ToString1stOptionTestConfig toString1stOptionTestConfig() {
		return new ToString1stOptionTestConfig();
	}

	public ToString03OptionTestConfig toString03OptionTestConfig() {
		return new ToString03OptionTestConfig();
	}

	public ToString02OptionTestConfig toString02OptionTestConfig() {
		return new ToString02OptionTestConfig();
	}

	public ToString01OptionTestConfig toString01OptionTestConfig() {
		return new ToString01OptionTestConfig();
	}

	public ToString_02_OptionTestConfig toString_02_OptionTestConfig() {
		return new ToString_02_OptionTestConfig();
	}

	public ToString_01_OptionTestConfig toString_01_OptionTestConfig() {
		return new ToString_01_OptionTestConfig();
	}

}
