package generator.configurator;

import java.io.File;
import java.io.FileNotFoundException;

import generator.astvisitor.HashVisitor;
import utils.generator.handler.AstTransformationHandler;

/**
 * The concrete configuration of the hashCode() variants.
 * The visitor component which used the JavaParser library will visit the AST and look up the 
 * corresponding nodes
 * @author forest
 *
 */
public class HashCodeConfiguration {

	private String methodMame;
	private String javaFileName;

	public HashCodeConfiguration(String methodMame, String javaFileName) {
		this.methodMame = methodMame;
		this.javaFileName = javaFileName;
	}

	private class LongVariantConfig implements AstTransformationHandler {

		@Override
		public void modifyAST(int level, String path, File file) {
			try {
				new HashVisitor(methodMame, javaFileName).withLongVariant().visit(ASTParserService.parse(file),
						null);
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			}
		}

	}

	public class ShortVariantConfig implements AstTransformationHandler {

		@Override
		public void modifyAST(int level, String path, File file) {
			try {
				new HashVisitor(methodMame, javaFileName).withShortVariant().visit(ASTParserService.parse(file),
						null);
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			}
		}

	}

	public LongVariantConfig getLongVariantConfig() {
		return new LongVariantConfig();
	}

	public ShortVariantConfig getShortVariantConfig() {
		return new ShortVariantConfig();
	}

}
