package generator.configurator;

import java.io.File;
import java.io.FileNotFoundException;

import generator.astvisitor.ThirdGenerationVisitor;
import utils.generator.handler.AstTransformationHandler;

/**
 * The concrete configuration of the third feature group.
 * The visitor component which used the JavaParser library will visit the AST and look up the 
 * corresponding nodes
 * @author forest
 *
 */
public class With3rdGenConfiguration {

	private String clazzName;

	public With3rdGenConfiguration(String clazzName) {
		this.clazzName = clazzName;
	}

	public class WithChef3rdGenConfig implements AstTransformationHandler {

		@Override
		public void modifyAST(int level, String path, File file) {
			try {
				new ThirdGenerationVisitor(clazzName).getChef3rdGenVisitor().visit(ASTParserService.parse(file),
						null);
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			}
		}
	}

	public class WithPizza3rdGenConfig implements AstTransformationHandler {

		@Override
		public void modifyAST(int level, String path, File file) {
			try {
				new ThirdGenerationVisitor(clazzName).getPizza3rdGenVisitor().visit(ASTParserService.parse(file),
						null);
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			}
		}
	}

	public class WithCustomer3rdGenConfig implements AstTransformationHandler {

		@Override
		public void modifyAST(int level, String path, File file) {
			try {
				new ThirdGenerationVisitor(clazzName).getCustomer3rdGenVisitor().visit(ASTParserService.parse(file),
						null);
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			}
		}
	}

	public WithChef3rdGenConfig withChef3rdGenConfig() {
		return new WithChef3rdGenConfig();
	}

	public WithPizza3rdGenConfig withPizza3rdGenConfig() {
		return new WithPizza3rdGenConfig();
	}

	public WithCustomer3rdGenConfig withCustomer3rdGenNewAttributConfig() {
		return new WithCustomer3rdGenConfig();
	}
	
}
