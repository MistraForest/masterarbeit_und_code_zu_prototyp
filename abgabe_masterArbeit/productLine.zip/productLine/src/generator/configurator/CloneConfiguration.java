package generator.configurator;

import java.io.File;
import java.io.FileNotFoundException;

import generator.astvisitor.CloneVisiteur;
import utils.generator.handler.AstTransformationHandler;

/**
 * The concrete configuration of the clone() method feature in the second feature group "Uebung2"
 * The visitor component which used the JavaParser library will visit the AST and look up the 
 * corresponding nodes
 * @author forest
 *
 */
public class CloneConfiguration {

	private String methodMame;
	private String javaFileName;

	public CloneConfiguration(String methodMame, String javaFileName) {
		this.methodMame = methodMame;
		this.javaFileName = javaFileName;
	}

	public CloneVariantConfig getCloneVariantConfig() {
		return new CloneVariantConfig();
	}

	public class CloneVariantConfig implements AstTransformationHandler {

		@Override
		public void modifyAST(int level, String path, File file) {
			try {
				new CloneVisiteur(methodMame, javaFileName).getClone().visit(ASTParserService.parse(file),
						null);
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			}
		}

	}

}
