package generator.configurator;

import java.io.File;
import java.io.FileNotFoundException;

import generator.astvisitor.ThirdGenerationTestVisitor;
import utils.generator.handler.AstTransformationHandler;

/**
 * The concrete configuration of the test classes in the third feature group "Uebung3".
 * The visitor component which used the JavaParser library will visit the AST and look up the 
 * corresponding nodes
 * @author forest
 *
 */
public class ThirdGenerationTestConfiguration {

	private String clazzName;

	public ThirdGenerationTestConfiguration(String javaFileName) {
		this.clazzName = javaFileName;
	}

	public class WithChef3rdGenTestConfig implements AstTransformationHandler {

		@Override
		public void modifyAST(int level, String path, File file) {
			try {
				new ThirdGenerationTestVisitor(clazzName).getChef3rdGenTestVisitor()
						.visit(ASTParserService.parse(file), null);
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			}
		}
	}

	public class WithPizza3rdGenTestConfig implements AstTransformationHandler {

		@Override
		public void modifyAST(int level, String path, File file) {
			try {
				new ThirdGenerationTestVisitor(clazzName).getPizza3rdGenTestVisitor()
						.visit(ASTParserService.parse(file), null);
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			}
		}

	}
	
	public class WithCustomer3rdGenTestConfig implements AstTransformationHandler {

		@Override
		public void modifyAST(int level, String path, File file) {
			try {
				new ThirdGenerationTestVisitor(clazzName).getCustomer3rdGenTestVisitor().visit(ASTParserService.parse(file), null);
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			}

		}

	}

	public WithChef3rdGenTestConfig withChef3rdGenTestConfig() {
		return new WithChef3rdGenTestConfig();
	}

	public WithPizza3rdGenTestConfig withPizza3rdGenTestConfig() {
		return new WithPizza3rdGenTestConfig();
	}

	public WithCustomer3rdGenTestConfig withCustomer3rdGenTestConfig() {
		return new WithCustomer3rdGenTestConfig();
	}

}
