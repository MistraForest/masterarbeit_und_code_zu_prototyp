package generator.configurator;

import java.io.File;
import java.io.FileNotFoundException;

import generator.astvisitor.BasicTestASTVisitor;
import utils.generator.handler.AstTransformationHandler;

/**
 * The concrete configuration of the test in the first feature generation for test classes. This class will
 * be systematically reused in nearly all test features.
 * The visitor component which used the JavaParser library will visit the AST and look up the 
 * corresponding nodes
 * @author forest
 *
 */
public class TestBasicConfiguration implements AstTransformationHandler {
	
	private String javaFileName;

	public TestBasicConfiguration(String javaFileName) {
		this.javaFileName = javaFileName;
	}

	@Override
	public void modifyAST(int level, String path, File file) {
		try {
			new BasicTestASTVisitor(javaFileName)  
				.visit(ASTParserService.parse(file), null);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}

	}

}
