package generator.configurator;

import java.io.File;
import java.io.FileNotFoundException;

import generator.astvisitor.ConstructorOptionTestVisitor;
import utils.generator.handler.AstTransformationHandler;

/**
 * The concrete configuration of the constructors test.
 * The visitor component which used the JavaParser library will visit the AST and look up the 
 * corresponding nodes
 * @author forest
 *
 */
public class TestConstructorOptionConfiguration {


	private String javaFileName;
	public String clazzName;

	public TestConstructorOptionConfiguration(String javaFileName, String clazzName) {
		this.javaFileName = javaFileName;
		this.clazzName = clazzName;
	}

	public class FirstOptionTestConfig implements AstTransformationHandler {

		@Override
		public void modifyAST(int level, String path, File file) {
			try {
				new ConstructorOptionTestVisitor(javaFileName, clazzName).get1stOptionTestVisitor()
						.visit(ASTParserService.parse(file), null);
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			}

		}

	}

	public class Customer1stOptionTestConfig implements AstTransformationHandler {

		@Override
		public void modifyAST(int level, String path, File file) {
			try {
				new ConstructorOptionTestVisitor(javaFileName, clazzName).getCustomer1stOptionTestVisitor()
						.visit(ASTParserService.parse(file), null);
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			}
		}

	}

	public class SecondOptionTestConfig implements AstTransformationHandler {

		@Override
		public void modifyAST(int level, String path, File file) {
			try {
				new ConstructorOptionTestVisitor(javaFileName, clazzName).get2ndOptionTestVisitor()
						.visit(ASTParserService.parse(file), null);
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			}
		}

	}

	public class SecondOptionPizzaConfig implements AstTransformationHandler {

		@Override
		public void modifyAST(int level, String path, File file) {
			try {
				new ConstructorOptionTestVisitor(javaFileName, clazzName).get2ndOptionPizzaVisitor()
						.visit(ASTParserService.parse(file), null);
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			}
		}

	}

	public class Customer2ndOptionTestConfig implements AstTransformationHandler {

		@Override
		public void modifyAST(int level, String path, File file) {
			try {
				new ConstructorOptionTestVisitor(javaFileName, clazzName).getCustomer2ndOptionTestVisitor()
						.visit(ASTParserService.parse(file), null);
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			}
		}

	}

	public class Customer03OptionTestConfig implements AstTransformationHandler {

		@Override
		public void modifyAST(int level, String path, File file) {
			try {
				new ConstructorOptionTestVisitor(javaFileName, clazzName).getCustomer03OptionTestVisitor()
						.visit(ASTParserService.parse(file), null);
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			}

		}

	}

	public class FirstOptionPizzaConfig implements AstTransformationHandler {

		@Override
		public void modifyAST(int level, String path, File file) {
			try {
				new ConstructorOptionTestVisitor(javaFileName, clazzName).get1stOptionPizzaVisitor()
						.visit(ASTParserService.parse(file), null);
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			}
		}

	}

	public SecondOptionTestConfig get2ndOptionTestConfig() {
		return new SecondOptionTestConfig();
	}

	public FirstOptionTestConfig get1stOptionTestConfig() {
		return new FirstOptionTestConfig();
	}

	public SecondOptionPizzaConfig get2ndOptionPizzaConfig() {
		return new SecondOptionPizzaConfig();
	}

	public FirstOptionPizzaConfig get1stOptionPizzaConfig() {
		return new FirstOptionPizzaConfig();
	}

	public Customer2ndOptionTestConfig getCustomer2ndOptionTestConfig() {
		return new Customer2ndOptionTestConfig();
	}

	public Customer1stOptionTestConfig getCustomer1stOptionTestConfig() {
		return new Customer1stOptionTestConfig();
	}

	public Customer03OptionTestConfig getCustomer03OptionTestConfig() {
		return new Customer03OptionTestConfig();
	}

}
