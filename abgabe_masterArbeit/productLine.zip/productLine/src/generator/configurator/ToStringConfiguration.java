package generator.configurator;

import java.io.File;
import java.io.FileNotFoundException;

import generator.astvisitor.ToStringVisitor;
import utils.generator.handler.AstTransformationHandler;

/**
 * The concrete configuration of the toString() feature.
 * The visitor component which used the JavaParser library will visit the AST and look up the 
 * corresponding nodes
 * @author forest
 *
 */
public class ToStringConfiguration implements AstTransformationHandler {

	private String javaFileName;
	private int attributNumber;

	public ToStringConfiguration(int attributNumber, String javaFileName) {
		this.javaFileName = javaFileName;
		this.attributNumber = attributNumber;
	}

	@Override
	public void modifyAST(int level, String path, File file) {
		try {
			new ToStringVisitor(attributNumber, javaFileName).visit(ASTParserService.parse(file), null);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
	}
}
