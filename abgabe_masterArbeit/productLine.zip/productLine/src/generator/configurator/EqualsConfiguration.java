package generator.configurator;

import java.io.File;
import java.io.FileNotFoundException;

import generator.astvisitor.EqualsVisitor;
import utils.generator.handler.AstTransformationHandler;

/**
 * The concrete configuration of the equals() method feature in the second feature group "Uebung2"
 * The visitor component which used the JavaParser library will visit the AST and look up the 
 * corresponding nodes
 * @author forest
 *
 */
public class EqualsConfiguration {

	private String methodMame;
	private String javaFileName;

	public EqualsConfiguration(String name, String javaFileName) {
		this.methodMame = name;
		this.javaFileName = javaFileName;
	}

	public class WithConfig implements AstTransformationHandler {

		@Override
		public void modifyAST(int level, String path, File file) {

			try {
				new EqualsVisitor(methodMame, javaFileName).getWithInstanceOf().visit(ASTParserService.parse(file), null);
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			}

		}

	}

	public class WithoutConfig implements AstTransformationHandler {

		@Override
		public void modifyAST(int level, String path, File file) {

			try {
				new EqualsVisitor(methodMame, javaFileName)
														.getWithoutInstanceOf()
														.visit(ASTParserService.parse(file), null);
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			}
		}

	}

	public class ExplicitWithConfig implements AstTransformationHandler {

		@Override
		public void modifyAST(int level, String path, File file) {
			try {
				new EqualsVisitor(methodMame, javaFileName).getExplicitWith().visit(ASTParserService.parse(file),
						null);
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			}

		}

	}

	public class ExplicitWithoutConfig implements AstTransformationHandler {

		@Override
		public void modifyAST(int level, String path, File file) {

			try {
				new EqualsVisitor(methodMame, javaFileName).getExplicitWithout().visit(ASTParserService.parse(file),
						null);
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			}

		}

	}

	public WithConfig getWithConfig() {
		return new WithConfig();
	}

	public WithoutConfig getWithoutConfig() {
		return new WithoutConfig();
	}

	public ExplicitWithConfig getImplicitWithConfig() {
		return new ExplicitWithConfig();
	}

	public ExplicitWithoutConfig getExplicitWithoutConfig() {
		return new ExplicitWithoutConfig();
	}

}
