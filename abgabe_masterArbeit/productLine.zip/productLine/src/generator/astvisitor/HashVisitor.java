package generator.astvisitor;

import com.github.javaparser.ast.CompilationUnit;
import com.github.javaparser.ast.PackageDeclaration;
import com.github.javaparser.ast.body.ClassOrInterfaceDeclaration;
import com.github.javaparser.ast.expr.Name;
import com.github.javaparser.ast.visitor.VoidVisitorAdapter;

import constants.Constant;
import utils.DirCreatorUtil;
import utils.TemplateModelWriter;
import utils.generator.handler.IGeneratorToTemplate;
import utils.HashCodeUtil;

/**
 * The generation of different variants of the hash method is handled in this class:
 * the long and the short variant 
 * @author forest
 *
 */
public class HashVisitor implements IGeneratorToTemplate{

	private String methodName;
	private String javaFileName;

	public HashVisitor(String name, String javaFileName) {
		this.methodName = name;
		this.javaFileName = javaFileName;
	}

	/**
	 * This class build and generate the "long" variant of the hash method
	 * @author forest
	 *
	 */
	public class WithLongVariant extends VoidVisitorAdapter<Object>  {

		@Override
		public void visit(ClassOrInterfaceDeclaration coid, Object arg) {
			super.visit(coid, arg);
			CompilationUnit cu = coid.findCompilationUnit().get();

			coid.getMembers().removeAll(coid.getMethodsByName(methodName));
			coid.addMember(HashCodeUtil.buildLongVariant(coid, methodName, javaFileName));

			String packageName = DirCreatorUtil.getPackageName(cu);
			packageName = packageName.replaceFirst("u1", "u2");			

			String directory = DirCreatorUtil.buildDir(cu);
			directory = directory.replaceFirst("u1", "u2");
			
			String identifier = directory.replace("/", ".");
			identifier = identifier.substring(0, identifier.lastIndexOf("."));

			cu.setPackageDeclaration(new PackageDeclaration().setName(new Name(identifier)));
			DirCreatorUtil.createDir(directory);
			
			getTemplate(cu, directory, javaFileName + Constant.JAVA);
		}
	}

	/**
	 * This class build and generate the "short" variant of the hash method
	 * @author forest
	 *
	 */
	public class WithShortVariant extends VoidVisitorAdapter<Object> {
		@Override
		public void visit(ClassOrInterfaceDeclaration coid, Object arg) {
			super.visit(coid, arg);
			CompilationUnit cu = coid.findCompilationUnit().get();

			coid.getMembers().removeAll(coid.getMethodsByName(methodName));
			coid.addMember(HashCodeUtil.buildShortVariant(coid, methodName, javaFileName));

			String packageName = DirCreatorUtil.getPackageName(cu);
			packageName = packageName.replaceFirst("u1", "u2");
			

			String directory = DirCreatorUtil.buildDir(cu);
			directory = directory.replaceFirst("u1", "u2");
			
			String identifier = directory.replace("/", ".");
			identifier = identifier.substring(0, identifier.lastIndexOf("."));

			cu.setPackageDeclaration(new PackageDeclaration().setName(new Name(identifier)));
			DirCreatorUtil.createDir(directory);
			
			getTemplate(cu, directory, javaFileName + Constant.JAVA);
		}
	}

	public WithLongVariant withLongVariant() {
		return new WithLongVariant();
	}

	public WithShortVariant withShortVariant() {
		return new WithShortVariant();
	}

	@Override
	public void getTemplate(CompilationUnit cu, String directory, String file) {
		TemplateModelWriter.getTemplateModel(cu).writeFileTo(directory, file);
	}

}
