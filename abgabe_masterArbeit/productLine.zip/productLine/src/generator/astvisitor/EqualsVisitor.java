package generator.astvisitor;

import com.github.javaparser.ast.CompilationUnit;
import com.github.javaparser.ast.PackageDeclaration;
import com.github.javaparser.ast.body.ClassOrInterfaceDeclaration;
import com.github.javaparser.ast.body.MethodDeclaration;
import com.github.javaparser.ast.expr.Name;
import com.github.javaparser.ast.visitor.VoidVisitorAdapter;

import constants.Constant;
import utils.DirCreatorUtil;
import utils.EqualsUtil;
import utils.TemplateModelWriter;
import utils.generator.handler.IGeneratorToTemplate;

/**
 * This class handle the different features concerning the equals() method by generating
 * different variants of the method
 * @author forest
 *
 */
public class EqualsVisitor implements IGeneratorToTemplate{

	private String name;
	private String javaFileName;

	public EqualsVisitor(String name, String javaFileName) {
		this.name = name;
		this.javaFileName = javaFileName;
	}

	/**
	 * The class handle the variant which implicitly use null check without
	 * using the instanceOf() method
	 * @author forest
	 *
	 */
	public class WithoutInstanceOf extends VoidVisitorAdapter<Object> {

		@Override
		public void visit(ClassOrInterfaceDeclaration coid, Object arg) {
			super.visit(coid, arg);
			CompilationUnit cu = coid.findCompilationUnit().get();
//
			coid.getMembers().removeAll(coid.getMethodsByName(name));
			coid
				.getMembers()
				.addLast(EqualsUtil.buildEqualsWithoutInstanceOf(coid, name, javaFileName));
			
			String packageName = DirCreatorUtil.getPackageName(cu);
			packageName = packageName.replaceFirst("u1", "u2");
			
			String directory = DirCreatorUtil.buildDir(cu);
			directory = directory.replaceFirst("u1", "u2");
			
			String identifier = directory.replace("/", ".");
			identifier = identifier.substring(0, identifier.lastIndexOf("."));

			cu.setPackageDeclaration(new PackageDeclaration().setName(new Name(identifier)));
			DirCreatorUtil.createDir(directory);
			
			getTemplate(cu, directory, javaFileName + Constant.JAVA);
		}
	}

	/**
	 * The class handle the variant which implicitly use null check by
	 * using the instanceOf() method
	 * @author forest
	 *
	 */
	public class WithInstanceOf extends VoidVisitorAdapter<Object> {

		@Override
		public void visit(ClassOrInterfaceDeclaration coid, Object arg) {
			super.visit(coid, arg);
			CompilationUnit cu = coid.findCompilationUnit().get();

			coid.getMembers().removeAll(coid.getMethodsByName(name));
			MethodDeclaration visitedMethode = EqualsUtil.buildEqualsWithInstanceOf(coid, name, javaFileName);
			coid
				.getMembers()
				.addLast(visitedMethode);

			String packageName = DirCreatorUtil.getPackageName(cu);
			packageName = packageName.replaceFirst("u1", "u2");
			

			String directory = DirCreatorUtil.buildDir(cu);
			directory = directory.replaceFirst("u1", "u2");
			
			String identifier = directory.replace("/", ".");
			identifier = identifier.substring(0, identifier.lastIndexOf("."));

			cu.setPackageDeclaration(new PackageDeclaration().setName(new Name(identifier)));
			DirCreatorUtil.createDir(directory);
			
			getTemplate(cu, directory, javaFileName + Constant.JAVA);
		}
	}

	/**
	 * The class handle the variant which explicitly use null check by
	 * using the instanceOf() method
	 * @author forest
	 *
	 */
	public class ExplicitWithInstanceOf extends VoidVisitorAdapter<Object> {

		@Override
		public void visit(ClassOrInterfaceDeclaration coid, Object arg) {
			super.visit(coid, arg);
			CompilationUnit cu = coid.findCompilationUnit().get();

			coid.getMembers().removeAll(coid.getMethodsByName(name));
			MethodDeclaration visitedMethode = EqualsUtil.explicitEqualsWithInstanceOf(coid, name, javaFileName);
			coid
				.getMembers()
				.addLast(visitedMethode);

			String packageName = DirCreatorUtil.getPackageName(cu);
			packageName = packageName.replaceFirst("u1", "u2");
//			System.out.println("Package: " +packageName);

			String directory = DirCreatorUtil.buildDir(cu);
			directory = directory.replaceFirst("u1", "u2");
			
			String identifier = directory.replace("/", ".");
			identifier = identifier.substring(0, identifier.lastIndexOf("."));

			cu.setPackageDeclaration(new PackageDeclaration().setName(new Name(identifier)));
			DirCreatorUtil.createDir(directory);
			
			getTemplate(cu, directory, javaFileName + Constant.JAVA);
		}
	}

	/**
	 * The class handle the variant which explicitly use null check without
	 * using the instanceOf() method
	 * @author forest
	 *
	 */
	public class ExplicitWithoutInstanceOf extends VoidVisitorAdapter<Object> {

		@Override
		public void visit(ClassOrInterfaceDeclaration coid, Object arg) {
			super.visit(coid, arg);
			CompilationUnit cu = coid.findCompilationUnit().get();

			coid.getMembers().removeAll(coid.getMethodsByName(name));
			MethodDeclaration visitedMethode = EqualsUtil.explicitEqualsWithoutInstanceOf(coid, name, javaFileName);
			coid.getMembers()
				.addLast(visitedMethode);

			String packageName = DirCreatorUtil.getPackageName(cu);
			packageName = packageName.replaceFirst("u1", "u2");			

			String directory = DirCreatorUtil.buildDir(cu);
			directory = directory.replaceFirst("u1", "u2");
			
			String identifier = directory.replace("/", ".");
			identifier = identifier.substring(0, identifier.lastIndexOf("."));

			cu.setPackageDeclaration(new PackageDeclaration().setName(new Name(identifier)));
			DirCreatorUtil.createDir(directory);
			
			getTemplate(cu, directory, javaFileName + Constant.JAVA);
		}
	}

	public ExplicitWithInstanceOf getExplicitWith() {
		return new ExplicitWithInstanceOf();
	}

	public ExplicitWithoutInstanceOf getExplicitWithout() {
		return new ExplicitWithoutInstanceOf();
	}

	public WithoutInstanceOf getWithoutInstanceOf() {
		return new WithoutInstanceOf();
	}

	public WithInstanceOf getWithInstanceOf() {
		return new WithInstanceOf();
	}

	@Override
	public void getTemplate(CompilationUnit cu, String directory, String file) {
		TemplateModelWriter.getTemplateModel(cu).writeFileTo(directory, file);
	}

}
