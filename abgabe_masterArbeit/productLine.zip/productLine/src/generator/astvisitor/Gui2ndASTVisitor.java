package generator.astvisitor;

import java.io.File;

import com.github.javaparser.ast.CompilationUnit;
import com.github.javaparser.ast.ImportDeclaration;
import com.github.javaparser.ast.PackageDeclaration;
import com.github.javaparser.ast.body.ClassOrInterfaceDeclaration;
import com.github.javaparser.ast.expr.Name;
import com.github.javaparser.ast.visitor.VoidVisitorAdapter;

import utils.DirCreatorUtil;
import utils.TemplateModelWriter;
import utils.FilterUtil.PatternFilter;
import utils.generator.handler.IGeneratorToTemplate;

/**
 * This class handle the generation of the GUI application of the the second feature group "Uebung2"
 * @author forest
 *
 */
public class Gui2ndASTVisitor extends VoidVisitorAdapter<Object> implements IGeneratorToTemplate{
	
	private File file;
	
	public Gui2ndASTVisitor(File file) {
		this.file = file;
	}

	@Override
	public void visit(ClassOrInterfaceDeclaration coid, Object arg) {
		super.visit(coid, arg);

		CompilationUnit cu = coid.findCompilationUnit().get();
		String packageName = DirCreatorUtil.getPackageName(cu);
		
		packageName = packageName.replaceFirst("u1", "u2");
		
		String directory = DirCreatorUtil.buildDir(cu);
		directory = directory.replaceFirst("u1", "u2");
		
		String identifier = directory.replace("/", ".");
		identifier = identifier.substring(0, identifier.lastIndexOf("."));

		cu.setPackageDeclaration(new PackageDeclaration().setName(new Name(identifier)));
//		
		DirCreatorUtil.createDir(directory);
		
		setImportFromGenerated(cu);
//		
//		TemplateModelWriter.getTemplateModel(cu).writeFileTo( directory, this.file.getName());
		getTemplate(cu, directory, this.file.getName());
	}

	public void setImportFromGenerated(CompilationUnit cu) {
		for (ImportDeclaration importDeclaration : cu.getImports()) {
			
			String importString = importDeclaration.getName().toString();
			String patternString_one = "u1";
			String patternString_two = "u2";
			
			if(PatternFilter.isSubstring(importString,patternString_one)) {
				importString = importString.replaceFirst(patternString_one, patternString_two);
				importDeclaration.setName(new Name(importString));
			}
		}
	}

	
	@Override
	public void getTemplate(CompilationUnit cu, String directory, String file) {
		TemplateModelWriter.getTemplateModel(cu).writeFileTo( directory, file);
	}
}
