package generator.astvisitor;

import com.github.javaparser.ast.CompilationUnit;
import com.github.javaparser.ast.PackageDeclaration;
import com.github.javaparser.ast.body.ClassOrInterfaceDeclaration;
import com.github.javaparser.ast.expr.Name;
import com.github.javaparser.ast.visitor.VoidVisitorAdapter;

import constants.Constant;
import utils.DirCreatorUtil;
import utils.TemplateModelWriter;
import utils.TestConfigUtil;
import utils.generator.handler.IGeneratorToTemplate;

/**
 * This class orchestrate the generation of the test features of the toString feature.
 * 
 * @author forest
 *
 */
public class ToStringTestOptionVisitor implements IGeneratorToTemplate{

	private String javaFileName;
	private String clazzName;

	public ToStringTestOptionVisitor(String javaFileName, String clazzName) {
		this.javaFileName = javaFileName;
		this.clazzName = clazzName;
	}

	/**
	 * The toString() method with two fields will be taken into account 
	 * in ChefVO class
	 * @author forest
	 *
	 */
	public class ToStringTest2ndOptionChefVisitor extends VoidVisitorAdapter<Object> {
		@Override
		public void visit(ClassOrInterfaceDeclaration coid, Object arg) {
			super.visit(coid, arg);
			CompilationUnit cu = coid.findCompilationUnit().get();

			TestConfigUtil.ChefUtil.toString2ndOption(coid, clazzName);

			String directory = DirCreatorUtil.buildDir(cu);// + DirCreatorUtil.U2;
			getTemplate(cu, directory, javaFileName + Constant.JAVA);
		}
	}

	/**
	 * The toString() method with one field will be taken into account 
	 * in ChefVO class
	 * @author forest
	 *
	 */
	public class ToString1stOptionChefVisitor extends VoidVisitorAdapter<Object> {
		@Override
		public void visit(ClassOrInterfaceDeclaration coid, Object arg) {
			super.visit(coid, arg);
			CompilationUnit cu = coid.findCompilationUnit().get();

			TestConfigUtil.ChefUtil.toString1stOption(coid, clazzName);

			String directory = DirCreatorUtil.buildDir(cu);// + DirCreatorUtil.U2;
			getTemplate(cu, directory, javaFileName + Constant.JAVA);
		}
	}

	/**
	 * The toString() method with three fields (without the id field) will be taken into account 
	 * in CustomerVO class
	 * @author forest
	 *
	 */
	public class ToString03OptionCustomerVisitor extends VoidVisitorAdapter<Object> {
		@Override
		public void visit(ClassOrInterfaceDeclaration coid, Object arg) {
			super.visit(coid, arg);
			CompilationUnit cu = coid.findCompilationUnit().get();

			TestConfigUtil.CustomerUtil.toString03Option(coid, clazzName);

//			String directory = DirCreatorUtil.buildDir(cu) + DirCreatorUtil.U2;
			
			String packageName = DirCreatorUtil.getPackageName(cu);
			packageName = packageName.replaceFirst("u1", "u2");
			

			String directory = DirCreatorUtil.buildDir(cu);
			directory = directory.replaceFirst("u1", "u2");
			
			String identifier = directory.replace("/", ".");
			identifier = identifier.substring(0, identifier.lastIndexOf("."));

			cu.setPackageDeclaration(new PackageDeclaration().setName(new Name(identifier)));
			DirCreatorUtil.createDir(directory);
			
			getTemplate(cu, directory, javaFileName + Constant.JAVA);
		}
	}
	
	/**
	 * The toString() method with two fields (without the id field) will be taken into account 
	 * in CustomerVO class
	 * @author forest
	 *
	 */
	public class ToString02OptionCustomerVisitor extends VoidVisitorAdapter<Object> {
		
		@Override
		public void visit(ClassOrInterfaceDeclaration coid, Object arg) {
			super.visit(coid, arg);
			CompilationUnit cu = coid.findCompilationUnit().get();

			TestConfigUtil.CustomerUtil.toString02Option(coid, clazzName);

//			String directory = DirCreatorUtil.buildDir(cu) + DirCreatorUtil.U2;
			
			String packageName = DirCreatorUtil.getPackageName(cu);
			packageName = packageName.replaceFirst("u1", "u2");
			

			String directory = DirCreatorUtil.buildDir(cu);
			directory = directory.replaceFirst("u1", "u2");
			
			String identifier = directory.replace("/", ".");
			identifier = identifier.substring(0, identifier.lastIndexOf("."));

			cu.setPackageDeclaration(new PackageDeclaration().setName(new Name(identifier)));
			DirCreatorUtil.createDir(directory);
			
			getTemplate(cu, directory, javaFileName + Constant.JAVA);
		}
	}

	/**
	 * The toString() method with one fields (without the id field) will be taken into account 
	 * in CustomerVO class
	 * @author forest
	 *
	 */
	public class ToString01OptionCustomerVisitor extends VoidVisitorAdapter<Object> {
		
		@Override
		public void visit(ClassOrInterfaceDeclaration coid, Object arg) {
			super.visit(coid, arg);
			CompilationUnit cu = coid.findCompilationUnit().get();

			TestConfigUtil.CustomerUtil.toString01Option(coid, clazzName);

//			String directory = DirCreatorUtil.buildDir(cu) + DirCreatorUtil.U2;
//			
			String packageName = DirCreatorUtil.getPackageName(cu);
			packageName = packageName.replaceFirst("u1", "u2");
			

			String directory = DirCreatorUtil.buildDir(cu);
			directory = directory.replaceFirst("u1", "u2");
			
			String identifier = directory.replace("/", ".");
			identifier = identifier.substring(0, identifier.lastIndexOf("."));

			cu.setPackageDeclaration(new PackageDeclaration().setName(new Name(identifier)));
			DirCreatorUtil.createDir(directory);
			
			getTemplate(cu, directory, javaFileName + Constant.JAVA);
		}
	}

	/**
	 * The toString() test method with two fields will be taken into account 
	 * in PizzaVO class
	 * @author forest
	 *
	 */
	public class ToString_02_OptionPizzaVisitor extends VoidVisitorAdapter<Object> {

		@Override
		public void visit(ClassOrInterfaceDeclaration coid, Object arg) {
			super.visit(coid, arg);
			CompilationUnit cu = coid.findCompilationUnit().get();

			TestConfigUtil.PizzaUtil.toString_02_Option(coid, clazzName);


			String packageName = DirCreatorUtil.getPackageName(cu);
			packageName = packageName.replaceFirst("u1", "u2");
			

			String directory = DirCreatorUtil.buildDir(cu);
			directory = directory.replaceFirst("u1", "u2");
			
			String identifier = directory.replace("/", ".");
			identifier = identifier.substring(0, identifier.lastIndexOf("."));

			cu.setPackageDeclaration(new PackageDeclaration().setName(new Name(identifier)));
			DirCreatorUtil.createDir(directory);
			
			getTemplate(cu, directory, javaFileName + Constant.JAVA);
		}
	}

	/**
	 * The toString() test method with one field will be taken into account in the 
	 * PizzaVO class
	 * @author forest
	 *
	 */
	public class ToString_01_OptionPizzaVisitor extends VoidVisitorAdapter<Object> {

		@Override
		public void visit(ClassOrInterfaceDeclaration coid, Object arg) {
			super.visit(coid, arg);
			CompilationUnit cu = coid.findCompilationUnit().get();

			TestConfigUtil.PizzaUtil.toString_01_Option(coid, clazzName);

			String directory = DirCreatorUtil.buildDir(cu);// + DirCreatorUtil.U2;
			getTemplate(cu, directory, javaFileName + Constant.JAVA);
		}
	}

	public ToStringTest2ndOptionChefVisitor getToStringTest2ndOptionChefVisitor() {
		return new ToStringTest2ndOptionChefVisitor();
	}

	public ToString1stOptionChefVisitor getToString1stOptionChefVisitor() {
		return new ToString1stOptionChefVisitor();
	}

	public ToString03OptionCustomerVisitor getToString03OptionCustomerVisitor() {
		return new ToString03OptionCustomerVisitor();
	}

	public ToString02OptionCustomerVisitor getToString02OptionCustomerVisitor() {
		return new ToString02OptionCustomerVisitor();
	}

	public ToString01OptionCustomerVisitor getToString01OptionCustomerVisitor() {
		return new ToString01OptionCustomerVisitor();
	}

	public ToString_02_OptionPizzaVisitor getToString_02_OptionCustomerVisitor() {
		return new ToString_02_OptionPizzaVisitor();
	}

	public ToString_01_OptionPizzaVisitor getToString_01_OptionCustomerVisitor() {
		return new ToString_01_OptionPizzaVisitor();
	}

	@Override
	public void getTemplate(CompilationUnit cu, String directory, String file) {
		TemplateModelWriter.getTemplateModel(cu).writeFileTo(directory, file);		
	}

}
