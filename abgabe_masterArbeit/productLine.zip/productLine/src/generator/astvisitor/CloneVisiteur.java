package generator.astvisitor;

import com.github.javaparser.ast.CompilationUnit;
import com.github.javaparser.ast.PackageDeclaration;
import com.github.javaparser.ast.body.ClassOrInterfaceDeclaration;
import com.github.javaparser.ast.expr.Name;
import com.github.javaparser.ast.visitor.VoidVisitorAdapter;

import constants.Constant;
import utils.CloneUtil;
import utils.DirCreatorUtil;
import utils.TemplateModelWriter;
import utils.generator.handler.IGeneratorToTemplate;

/**
 * This class build and generate the clone method 
 * @author forest
 *
 */
public class CloneVisiteur implements IGeneratorToTemplate{

	private String name;
	private String javaFileName;

	public CloneVisiteur(String name, String javaFileName) {
		this.name = name;
		this.javaFileName = javaFileName;
	}

	public Clonee getClone() {
		return new Clonee();
	}

	public class Clonee extends VoidVisitorAdapter<Object> {
		@Override
		public void visit(ClassOrInterfaceDeclaration coid, Object arg) {
			super.visit(coid, arg);
			CompilationUnit cu = coid.findCompilationUnit().get();

			coid.getMembers().removeAll(coid.getMethodsByName(name));
			coid.addMember(CloneUtil.buildCloneMethod(coid, name, javaFileName));

			String packageName = DirCreatorUtil.getPackageName(cu);
			packageName = packageName.replaceFirst("u1", "u2");
			

			String directory = DirCreatorUtil.buildDir(cu);
			directory = directory.replaceFirst("u1", "u2");
			
			String identifier = directory.replace("/", ".");
			identifier = identifier.substring(0, identifier.lastIndexOf("."));

			cu.setPackageDeclaration(new PackageDeclaration().setName(new Name(identifier)));
			DirCreatorUtil.createDir(directory);
			
			getTemplate(cu, directory, javaFileName + Constant.JAVA);
		}
	}

	@Override
	public void getTemplate(CompilationUnit cu, String directory, String file) {
		TemplateModelWriter.getTemplateModel(cu).writeFileTo(directory, file);
	}

}
