package generator.astvisitor;

import java.io.File;

import com.github.javaparser.ast.CompilationUnit;
import com.github.javaparser.ast.ImportDeclaration;
import com.github.javaparser.ast.PackageDeclaration;
import com.github.javaparser.ast.body.ClassOrInterfaceDeclaration;
import com.github.javaparser.ast.expr.Name;
import com.github.javaparser.ast.visitor.VoidVisitorAdapter;

import utils.DirCreatorUtil;
import utils.TemplateModelWriter;
import utils.FilterUtil.PatternFilter;
import utils.generator.handler.IGeneratorToTemplate;

/**
 * This class is used to transform the GUI classes of the Pizza-Pronto application.
 * The transformation concern most the package and the import statements.
 * @author forest
 *
 */
public class BasicGUI_ASTVisitor extends VoidVisitorAdapter<Object> implements IGeneratorToTemplate{

	private String root = "generated/";
	private String path;
	private File file;
	
	public BasicGUI_ASTVisitor(String path, File file) {
		this.path = path;
		this.file = file;
	}
	
	@Override
	public void visit(ClassOrInterfaceDeclaration coid, Object arg) {
		super.visit(coid, arg);

		CompilationUnit cu = coid.findCompilationUnit().get();
		String packageName = DirCreatorUtil.getPackageName(cu);
		packageName = packageName.replaceFirst("pizzaProntoGUI", "pizzaProntoGUI.u1");

		String directory = DirCreatorUtil.buildDir(cu);
		directory = directory.replaceFirst("pizzaProntoGUI", "pizzaProntoGUI/u1");
		
		String rootWithoutSlash = this.root.replace("/", ".");
		String identifier = rootWithoutSlash + packageName;
		
		cu.setPackageDeclaration(new PackageDeclaration().setName(new Name(identifier)));
		
		DirCreatorUtil.createDir(root + directory);
		
		setImportFromGeneratedRoot(cu, rootWithoutSlash);

		getTemplate(cu, this.root + directory, this.file.getName());
	}

	public void setImportFromGeneratedRoot(CompilationUnit cu, String rootWithoutSlash) {
		for (ImportDeclaration importDeclaration : cu.getImports()) {
			
			String importString = importDeclaration.getName().toString();
			String patternString_one = ".pizzaPronto";
			String patternString_two = ".pizzaProntoGUI";
			
			if(PatternFilter.isSubstring(importString,patternString_one)) {
				importString = importString.replaceFirst("de.thb", rootWithoutSlash+"de.thb");
				
				if(PatternFilter.isSubstring(importString,patternString_two))
					importString = importString.replaceFirst(patternString_two, patternString_two+".u1");
				else 
					importString = importString.replaceFirst(patternString_one, patternString_one+".u1");
				
				importDeclaration.setName(new Name(importString));
			}
				
		}
	}

	@Override
	public void getTemplate(CompilationUnit cu, String directory, String file) {
		TemplateModelWriter.getTemplateModel(cu).writeFileTo(directory, file);
	}

	
}
