package generator.astvisitor;

import com.github.javaparser.ast.CompilationUnit;
import com.github.javaparser.ast.ImportDeclaration;
import com.github.javaparser.ast.PackageDeclaration;
import com.github.javaparser.ast.body.ClassOrInterfaceDeclaration;
import com.github.javaparser.ast.expr.Name;
import com.github.javaparser.ast.visitor.VoidVisitorAdapter;

import constants.Constant;
import utils.DirCreatorUtil;
import utils.TemplateModelWriter;
import utils.TestConfigUtil;
import utils.FilterUtil.PatternFilter;
import utils.generator.handler.IGeneratorToTemplate;

/**
 * This class handle the test class of the first feature generation of the "ChefVO" class.
 * All the others up coming test features generation will be based on this class.
 * @author forest
 *
 */
public class ChefBasicVariantTestASTVisitor extends VoidVisitorAdapter<Object> implements IGeneratorToTemplate{

	private String javaFileName;
	private String clazzName;

	public ChefBasicVariantTestASTVisitor(String javaFileName, String clazzName) {
		this.javaFileName = javaFileName;
		this.clazzName = clazzName;
	}
	
	@Override
	public void visit(ClassOrInterfaceDeclaration coid, Object arg) {
		super.visit(coid, arg);
		CompilationUnit cu = coid.findCompilationUnit().get();

		TestConfigUtil.ChefUtil.addTestAttributes(coid, clazzName);
		TestConfigUtil.ChefUtil.fillMethodInitEach(coid, clazzName);
		TestConfigUtil.ChefUtil.addMethodEqualsNull(coid, clazzName);
		TestConfigUtil.ChefUtil.addEquals2EqualObjects(coid, clazzName);
		TestConfigUtil.ChefUtil.addEquals2IdenticalObjects(coid, clazzName);
		TestConfigUtil.ChefUtil.addEquals3EqualObjects(coid, clazzName);
		TestConfigUtil.ChefUtil.addEqualsDifferentObjects(coid, clazzName);
		TestConfigUtil.ChefUtil.addEqualsDifferentObjectsDifferentClasses(coid, clazzName);
		TestConfigUtil.ChefUtil.addEqualsDefaultConstructors(coid, clazzName);
		TestConfigUtil.ChefUtil.addEqualsIniAndDefaultConstructors(coid, clazzName);
		TestConfigUtil.ChefUtil.addEqualsOtherNoLastname(coid, clazzName);
		TestConfigUtil.ChefUtil.addEquals2IdenticalObjectsNoColor(coid, clazzName);
		TestConfigUtil.ChefUtil.addEqualsThisNoLastname(coid, clazzName);
		TestConfigUtil.ChefUtil.addEqualsOtherNoFirstname(coid, clazzName);
		TestConfigUtil.ChefUtil.addEqualsThisNoFirstname(coid, clazzName);
		TestConfigUtil.ChefUtil.addEqualsOtherNoColor(coid, clazzName);
		TestConfigUtil.ChefUtil.addEqualsThisNoColor(coid, clazzName);
		TestConfigUtil.ChefUtil.addHashCodeTest(coid, clazzName);
		TestConfigUtil.ChefUtil.addToStringTest(coid, clazzName);

		String packageName = DirCreatorUtil.getPackageName(cu);
		packageName = packageName.replaceFirst("u1", "u2");
		
//		System.out.println("Package:\t"+ packageName);

		String directory = DirCreatorUtil.buildDir(cu);
		directory = directory.replaceFirst("u1", "u2");
		
		String identifier = directory.replace("/", ".");
		identifier = identifier.substring(0, identifier.lastIndexOf("."));

		cu.setPackageDeclaration(new PackageDeclaration().setName(new Name(identifier)));
		DirCreatorUtil.createDir(directory);
		
		setImportFromGenerated(cu);
		
//		TemplateModelWriter.getTemplateModel(cu).writeFileTo(directory, javaFileName + Constant.JAVA);
		getTemplate(cu, directory, javaFileName + Constant.JAVA);
	}
	
	public void setImportFromGenerated(CompilationUnit cu) {
		for (ImportDeclaration importDeclaration : cu.getImports()) {
			
			String importString = importDeclaration.getName().toString();
			String patternString_one = "u1";
			String patternString_two = "u2";
			
			if(PatternFilter.isSubstring(importString,patternString_one)) {
				importString = importString.replaceFirst(patternString_one, patternString_two);
				importDeclaration.setName(new Name(importString));
			}
		}
	}

	@Override
	public void getTemplate(CompilationUnit cu, String directory, String file) {
		TemplateModelWriter.getTemplateModel(cu).writeFileTo(directory, javaFileName + Constant.JAVA);
	}
}
