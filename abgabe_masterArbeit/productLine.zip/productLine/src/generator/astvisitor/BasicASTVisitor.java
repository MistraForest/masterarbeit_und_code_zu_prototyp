package generator.astvisitor;

import com.github.javaparser.ast.CompilationUnit;
import com.github.javaparser.ast.PackageDeclaration;
import com.github.javaparser.ast.body.ClassOrInterfaceDeclaration;
import com.github.javaparser.ast.expr.Name;
import com.github.javaparser.ast.visitor.VoidVisitorAdapter;

import utils.DirCreatorUtil;
import utils.TemplateModelWriter;
import utils.generator.handler.IGeneratorToTemplate;

/**
 * This class is called when the first generation of an feature group occurs.
 * The visit() method of VoidVisitorAdapter is used to modify the AST of an class as needed
 * @author forest
 *
 */
public class BasicASTVisitor extends VoidVisitorAdapter<Object> implements IGeneratorToTemplate {

	private String root = "generated/";
	private String javaFileName;

	public BasicASTVisitor(String javaFileName) {
		this.javaFileName = javaFileName;
	}

	@Override
	public void visit(ClassOrInterfaceDeclaration coid, Object arg) {
		super.visit(coid, arg);
		CompilationUnit cu = coid.findCompilationUnit().get();

		String packageName = DirCreatorUtil.getPackageName(cu).concat("."+DirCreatorUtil.U1.replace("/", ""));
		
		String directory = DirCreatorUtil.buildDir(cu) + DirCreatorUtil.U1;
		cu.setPackageDeclaration(new PackageDeclaration().setName(new Name(this.root.replace("/", ".") + packageName)));

		DirCreatorUtil.createDir(root + directory);
		
		getTemplate(cu, this.root + directory, this.javaFileName + ".java");
		
	}

	@Override
	public void getTemplate(CompilationUnit cu, String dir, String file) {
		
		TemplateModelWriter.getTemplateModel(cu).writeFileTo(dir, file);
	}

}
