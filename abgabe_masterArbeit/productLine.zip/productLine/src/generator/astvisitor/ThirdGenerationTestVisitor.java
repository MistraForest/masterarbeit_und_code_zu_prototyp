package generator.astvisitor;

import com.github.javaparser.ast.CompilationUnit;
import com.github.javaparser.ast.ImportDeclaration;
import com.github.javaparser.ast.PackageDeclaration;
import com.github.javaparser.ast.body.ClassOrInterfaceDeclaration;
import com.github.javaparser.ast.expr.Name;
import com.github.javaparser.ast.visitor.VoidVisitorAdapter;

import constants.Constant;
import utils.DirCreatorUtil;
import utils.TemplateModelWriter;
import utils.TestConfigUtil;
import utils.FilterUtil.PatternFilter;
import utils.generator.handler.IGeneratorToTemplate;

/**
 * This orchestrate the build and generation of the test classes of three feature groups
 * 
 * @author forest
 *
 */
public class ThirdGenerationTestVisitor implements IGeneratorToTemplate{

	private String clazzName;

	public ThirdGenerationTestVisitor(String clazzName) {
		this.clazzName = clazzName;
	}

	/**
	 * This class prepare the test class of the ChefVO class in the third feature generation.
	 * The import statements and the package will be taking in account.
	 * @author forest
	 *
	 */
	public class Chef3rdGenTestVisitor extends VoidVisitorAdapter<Object> {

		@Override
		public void visit(ClassOrInterfaceDeclaration coid, Object arg) {
			super.visit(coid, arg);

			CompilationUnit cu = coid.findCompilationUnit().get();

//			String directory = DirCreatorUtil.buildDir(cu) + DirCreatorUtil.U3;
			
			String packageName = DirCreatorUtil.getPackageName(cu);
			packageName = packageName.replaceFirst("u2", "u3");
			

			String directory = DirCreatorUtil.buildDir(cu);
			directory = directory.replaceFirst("u2", "u3");
			
			String identifier = directory.replace("/", ".");
			identifier = identifier.substring(0, identifier.lastIndexOf("."));

			cu.setPackageDeclaration(new PackageDeclaration().setName(new Name(identifier)));
			DirCreatorUtil.createDir(directory);
			
			setImportFromGenerated(cu);
			
			getTemplate(cu, directory, clazzName + Constant.JAVA);
		}
	}

	/**
	 * This class prepare the test class of the PizzVO class in the third feature generation.
	 * The import statements and the package will be taking in account.
	 * @author forest
	 *
	 */
	public class Pizza3rdGenTestVisitor extends VoidVisitorAdapter<Object> {
		@Override
		public void visit(ClassOrInterfaceDeclaration coid, Object arg) {
			super.visit(coid, arg);

			CompilationUnit cu = coid.findCompilationUnit().get();

//			String directory = DirCreatorUtil.buildDir(cu) + DirCreatorUtil.U3;
			
			String packageName = DirCreatorUtil.getPackageName(cu);
			packageName = packageName.replaceFirst("u2", "u3");
			

			String directory = DirCreatorUtil.buildDir(cu);
			directory = directory.replaceFirst("u2", "u3");
			
			String identifier = directory.replace("/", ".");
			identifier = identifier.substring(0, identifier.lastIndexOf("."));

			cu.setPackageDeclaration(new PackageDeclaration().setName(new Name(identifier)));
			DirCreatorUtil.createDir(directory);
			
			setImportFromGenerated(cu);
			
			getTemplate(cu, directory, clazzName + Constant.JAVA);
		}
	}

	/**
	 * This class prepare the test class of the CustomerVO class in the third feature generation.
	 * The import statements and the package will be taking in account.
	 * @author forest
	 *
	 */
	public class Customer3rdGenTestVisitor extends VoidVisitorAdapter<Object> {
		@Override
		public void visit(ClassOrInterfaceDeclaration coid, Object arg) {
			super.visit(coid, arg);

			CompilationUnit cu = coid.findCompilationUnit().get();
			
//			String directory = DirCreatorUtil.buildDir(cu) + DirCreatorUtil.U3;
			TestConfigUtil.CustomerUtil.test7Attributes(coid, clazzName);
			TestConfigUtil.CustomerUtil.testMethodHasOrder(coid, clazzName);
			TestConfigUtil.CustomerUtil.updateToStringTest(coid, clazzName);
			TestConfigUtil.CustomerUtil.testSetOrder(coid, clazzName);
						
			String packageName = DirCreatorUtil.getPackageName(cu);
			packageName = packageName.replaceFirst("u2", "u3");
			

			String directory = DirCreatorUtil.buildDir(cu);
			directory = directory.replaceFirst("u2", "u3");
			
			String identifier = directory.replace("/", ".");
			identifier = identifier.substring(0, identifier.lastIndexOf("."));

			cu.setPackageDeclaration(new PackageDeclaration().setName(new Name(identifier)));
			DirCreatorUtil.createDir(directory);
			
			setImportFromGenerated(cu);
			
			getTemplate(cu, directory, clazzName + Constant.JAVA);
		}
	}

	public Chef3rdGenTestVisitor getChef3rdGenTestVisitor() {
		return new Chef3rdGenTestVisitor();
	}

	public Pizza3rdGenTestVisitor getPizza3rdGenTestVisitor() {
		return new Pizza3rdGenTestVisitor();
	}

	public Customer3rdGenTestVisitor getCustomer3rdGenTestVisitor() {
		return new Customer3rdGenTestVisitor();
	}
	
	public void setImportFromGenerated(CompilationUnit cu) {
		for (ImportDeclaration importDeclaration : cu.getImports()) {
			
			String importString = importDeclaration.getName().toString();
			String patternString_one = "u2";
			String patternString_two = "u3";
			
			if(PatternFilter.isSubstring(importString,patternString_one)) {
				importString = importString.replaceFirst(patternString_one, patternString_two);
				importDeclaration.setName(new Name(importString));
			}
		}
	}

	@Override
	public void getTemplate(CompilationUnit cu, String directory, String file) {
		TemplateModelWriter.getTemplateModel(cu).writeFileTo(directory, file);
	}
}
