package generator.astvisitor;

import java.util.List;

import com.github.javaparser.ast.CompilationUnit;
import com.github.javaparser.ast.ImportDeclaration;
import com.github.javaparser.ast.PackageDeclaration;
import com.github.javaparser.ast.body.ClassOrInterfaceDeclaration;
import com.github.javaparser.ast.body.MethodDeclaration;
import com.github.javaparser.ast.expr.Name;
import com.github.javaparser.ast.visitor.VoidVisitorAdapter;

import utils.AssociationUtil;
import utils.DirCreatorUtil;
import utils.TemplateModelWriter;
import utils.FilterUtil.PatternFilter;
import utils.generator.handler.IGeneratorToTemplate;

/**
 * The AssociationASTVisitor class is used to transform the AST of the association class of the Pizza-Pronto application.
 * The VoidVisitorAdapter of the JavaParser library will be used.
 * @author forest
 *
 */
public class AssociationASTVisitor implements IGeneratorToTemplate{

	public class AssiociationTestVisitor extends VoidVisitorAdapter<Object>  {

		@Override
		public void visit(ClassOrInterfaceDeclaration coid, Object arg) {
			super.visit(coid, arg);
			CompilationUnit cu = coid.findCompilationUnit().get();

			String packageName = DirCreatorUtil.getPackageName(cu)+ "."+DirCreatorUtil.U3.replace("/", "");
			String directory = DirCreatorUtil.buildDir(cu) + DirCreatorUtil.U3;

			cu.setPackageDeclaration(new PackageDeclaration().setName(new Name(root.replace("/", ".") + packageName)));

			DirCreatorUtil.createDir(root + directory);

			setImportFromGenerated(cu, "pizzaPronto", ".u3");
			
			getTemplate(cu, root + directory, javaFile + ".java");
			
		}

	}

	private String root = "generated/";
	private String javaFile;
	
	public AssociationASTVisitor(String javaFile) {
		this.javaFile = javaFile;
	}

	public class LessEfficiencyVariantWithString extends VoidVisitorAdapter<Object>  {

		@Override
		public void visit(ClassOrInterfaceDeclaration coid, Object arg) {
			super.visit(coid, arg);
			CompilationUnit cu = coid.findCompilationUnit().get();

			String packageName = DirCreatorUtil.getPackageName(cu);
			String directory = DirCreatorUtil.buildDir(cu) + DirCreatorUtil.U3;

			cu.setPackageDeclaration(new PackageDeclaration().setName(new Name(root.replace("/", ".") + packageName)));

			DirCreatorUtil.createDir(root + directory);

			setImportFromGenerated(cu);
			
			getTemplate(cu, root + directory, javaFile + ".java");
			
		}
	}

	public class BetterEfficiencyVariantWithStringBuffer extends VoidVisitorAdapter<Object>  {
		
		private String methodName;
		
		public BetterEfficiencyVariantWithStringBuffer(String methodName) {
			this.methodName = methodName;
		}

		@Override
		public void visit(ClassOrInterfaceDeclaration coid, Object arg) {
			super.visit(coid, arg);
			CompilationUnit cu = coid.findCompilationUnit().get();

			coid.getMembers().removeAll(getMethodsByName(coid, methodName));
			coid.addMember(AssociationUtil.toStringVariantWithBuffer(coid, methodName));
			
			String packageName = DirCreatorUtil.getPackageName(cu);
			String directory = DirCreatorUtil.buildDir(cu) + DirCreatorUtil.U3;

			cu.setPackageDeclaration(new PackageDeclaration().setName(new Name(root.replace("/", ".") + packageName)));

			DirCreatorUtil.createDir(root + directory);

			setImportFromGenerated(cu);
			
			getTemplate(cu, root + directory, javaFile + ".java");
		}

		private List<MethodDeclaration> getMethodsByName(ClassOrInterfaceDeclaration coid, String methodName) {
			return coid.getMethodsByName(methodName);
		}
	}

	public LessEfficiencyVariantWithString getStringVariantWithLessEfficiency() {
		
		return new LessEfficiencyVariantWithString();
	}

	public BetterEfficiencyVariantWithStringBuffer getStringBufferVariantWithBetterEfficiency(String methodName) {
		return new BetterEfficiencyVariantWithStringBuffer(methodName);
	}
	
	private void setImportFromGenerated(CompilationUnit cu) {
		for (ImportDeclaration importDeclaration : cu.getImports()) {
			
			String importString = importDeclaration.getName().toString();
			String patternString_one = ".u2";
			String patternString_two = ".u3";
			
			if(PatternFilter.isSubstring(importString,patternString_one)) {
				importString = importString.replaceFirst(patternString_one, patternString_two);
				importDeclaration.setName(new Name(importString));
				
			}
		}
	}
	
	private void setImportFromGenerated(CompilationUnit cu, String patternString_one, String patternString_two) {
		for (ImportDeclaration importDeclaration : cu.getImports()) {
			
			String importString = importDeclaration.getName().toString();
			importString = "generated.".concat(importString);
			
			if(PatternFilter.isSubstring(importString,"."+patternString_one)) {
				importString = importString.replaceFirst("."+patternString_one, "."+patternString_one+patternString_two);
				importDeclaration.setName(new Name(importString));
				
			}
		}
	}

	public AssiociationTestVisitor getAssiociationTest() {
		return new AssiociationTestVisitor();
	}

	@Override
	public void getTemplate(CompilationUnit cu, String directory, String file) {
		TemplateModelWriter.getTemplateModel(cu).writeFileTo(directory, file);
	}

}
