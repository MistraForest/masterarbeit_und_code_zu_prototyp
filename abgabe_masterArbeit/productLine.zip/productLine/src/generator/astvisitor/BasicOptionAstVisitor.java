package generator.astvisitor;

import com.github.javaparser.ast.CompilationUnit;
import com.github.javaparser.ast.ImportDeclaration;
import com.github.javaparser.ast.PackageDeclaration;
import com.github.javaparser.ast.body.ClassOrInterfaceDeclaration;
import com.github.javaparser.ast.expr.Name;
import com.github.javaparser.ast.visitor.VoidVisitorAdapter;

import constants.Constant;
import utils.DirCreatorUtil;
import utils.TemplateModelWriter;
import utils.FilterUtil.PatternFilter;
import utils.generator.handler.IGeneratorToTemplate;

/**
 * The class is used to set up the test class of the first feature generation
 * @author forest
 *
 */
public class BasicOptionAstVisitor extends VoidVisitorAdapter<Object> implements IGeneratorToTemplate {

	private String root = "generated/";
	private String javaFileName;
	
	public BasicOptionAstVisitor(String javaFileName) {
		this.javaFileName = javaFileName;
	}

	@Override
	public void visit(ClassOrInterfaceDeclaration coid, Object arg) {
		super.visit(coid, arg);
		CompilationUnit cu = coid.findCompilationUnit().get();

		String methodName = "testIniConstructor3Param";
		removeMethod(coid, methodName);

		String packageName = DirCreatorUtil.getPackageName(cu).concat("."+DirCreatorUtil.U1.replace("/", ""));

		String directory = DirCreatorUtil.buildDir(cu)+DirCreatorUtil.U1;

		String rootWithoutSlash = root.replace("/", ".");
		String identifier = rootWithoutSlash + packageName;
		
		cu.setPackageDeclaration(new PackageDeclaration()
				.setName(new Name(identifier)));

		// create fresh one
		DirCreatorUtil.createDir(root + directory);
		setImportFromGeneratedRoot(cu, rootWithoutSlash);
		TemplateModelWriter.getTemplateModel(cu).writeFileTo(root + directory, javaFileName + Constant.JAVA);
	}
	
	@Override
	public void getTemplate(CompilationUnit cu, String directory, String file) {
		TemplateModelWriter.getTemplateModel(cu).writeFileTo(directory, file);
	}

	
	private void removeMethod(ClassOrInterfaceDeclaration coid, String name) {
		coid.getMembers().removeAll(coid.getMethodsByName(name));
		
	}
	
	/**
	 * This method handle the import issue, so that the correct related classes are imported
	 * @param cu - the given compilation unit
	 * @param rootWithoutSlash - the path of the related classes
	 */
	public void setImportFromGeneratedRoot(CompilationUnit cu, String rootWithoutSlash) {
		for (ImportDeclaration importDeclaration : cu.getImports()) {
			
			String importString = importDeclaration.getName().toString();
			String patternString_one = ".pizzaPronto";
			String patternString_two = ".u1";
			
			if(PatternFilter.isSubstring(importString,patternString_one)) {
				importString = importString.replaceFirst("de.thb", rootWithoutSlash+"de.thb");
			
				importString = importString.replaceFirst(patternString_one, patternString_one+patternString_two);
				 				
				importDeclaration.setName(new Name(importString));
			}
				
		}
	}
}
