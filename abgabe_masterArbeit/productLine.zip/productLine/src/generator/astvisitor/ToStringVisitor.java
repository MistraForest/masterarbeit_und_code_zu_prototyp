package generator.astvisitor;

import java.time.Period;
import java.util.Properties;

import com.github.javaparser.ast.CompilationUnit;
import com.github.javaparser.ast.ImportDeclaration;
import com.github.javaparser.ast.Modifier;
import com.github.javaparser.ast.Node;
import com.github.javaparser.ast.NodeList;
import com.github.javaparser.ast.PackageDeclaration;
import com.github.javaparser.ast.body.ClassOrInterfaceDeclaration;
import com.github.javaparser.ast.body.MethodDeclaration;
import com.github.javaparser.ast.body.VariableDeclarator;
import com.github.javaparser.ast.expr.AssignExpr;
import com.github.javaparser.ast.expr.AssignExpr.Operator;
import com.github.javaparser.ast.expr.BinaryExpr;
import com.github.javaparser.ast.expr.CastExpr;
import com.github.javaparser.ast.expr.Expression;
import com.github.javaparser.ast.expr.FieldAccessExpr;
import com.github.javaparser.ast.expr.IntegerLiteralExpr;
import com.github.javaparser.ast.expr.MethodCallExpr;
import com.github.javaparser.ast.expr.Name;
import com.github.javaparser.ast.expr.NameExpr;
import com.github.javaparser.ast.expr.NullLiteralExpr;
import com.github.javaparser.ast.expr.ThisExpr;
import com.github.javaparser.ast.expr.VariableDeclarationExpr;
import com.github.javaparser.ast.stmt.BlockStmt;
import com.github.javaparser.ast.stmt.ExpressionStmt;
import com.github.javaparser.ast.stmt.IfStmt;
import com.github.javaparser.ast.stmt.ReturnStmt;
import com.github.javaparser.ast.stmt.Statement;
import com.github.javaparser.ast.type.ClassOrInterfaceType;
import com.github.javaparser.ast.type.Type;
import com.github.javaparser.ast.visitor.VoidVisitorAdapter;

import constants.Constant;
import utils.DirCreatorUtil;
import utils.TemplateModelWriter;
import utils.PropertiesUtil;
import utils.ToStringUtil;
import utils.FilterUtil.PatternFilter;
import utils.exceptions.InvalidAttributeNumberException;
import utils.generator.handler.IGeneratorToTemplate;

/**
 * This class act like a model that will be use to build and 
 * generate the toString() method for all classes
 * @author forest
 *
 */
public class ToStringVisitor extends VoidVisitorAdapter<Object> implements IGeneratorToTemplate{
	
	static Properties prop = PropertiesUtil.readPropertiesFile("resources/general.properties");

	private static final String SET_DATE_OF_BIRTH 	= prop.getProperty("set_dob");
	private static final String DOB_TO_STRING 		= prop.getProperty("dob_to_string");
	private static final String _18 				= prop.getProperty("value_18");
	private static final String GET_YEARS 			= Constant.GET_YEARS;
	private static final String BETWEEN 			= Constant.BETWEEN;
	private static final String NOW 				= Constant.NOW;
	private static final String TODAY 				= prop.getProperty("var_today");
	private static final String LOCAL_DATE 			= Constant.LOCAL_DATE;
	private static final String _1 					= prop.getProperty("value_minus_1");
	private static final String DATE_OF_BIRTH 		= prop.getProperty("date_of_birth");
	private static final String PERIOD 				= Constant.PERIOD;
	private static final String AGE 				= prop.getProperty("var_lower_age");
	private static final String AGE_IDENFIFIER 		= prop.getProperty("var_upper_age");
	private static final String ALTER 				= prop.getProperty("var_alter");
	private static final String SHORT 				= Constant.SHORT;
	private static final String CUSTOMER_VO 		= prop.getProperty("type_customer");
	private static final String TO_STRING 			= Constant.TO_STRING;
	private static final String type 				= Constant.STRING;
	private static final String CALCULATE_AGE 		= prop.getProperty("calculate_age");
	
	private String javaFileName;
	private int attributNumber;
	
	public ToStringVisitor(int attributNumber, String javaFileName) {
		this.javaFileName = javaFileName;
		this.attributNumber = attributNumber;
	}

	@Override
	public void visit(ClassOrInterfaceDeclaration coid, Object arg) {
		super.visit(coid, arg);
		
		CompilationUnit cu = coid.findCompilationUnit().get();
		cu.removeComment();
			
		MethodDeclaration methodDeclaration1 = null;
		if (javaFileName.equals(CUSTOMER_VO)) {
			insertCalculateMethod(coid);
			insertCheckAgeStatments(coid, SET_DATE_OF_BIRTH);
		
			methodDeclaration1 = coid.getMethodsByName(CALCULATE_AGE).get(0);
			methodDeclaration1.tryAddImportToParentCompilationUnit(Period.class);
		}

		StringBuffer buffer = new StringBuffer();
		try {
			buffer = ToStringUtil.toStringBody(coid, attributNumber, javaFileName, TO_STRING);

		} catch (InvalidAttributeNumberException e) {
			e.printStackTrace();
		}
		
		// create a method
		NodeList<Modifier> modifiers = new NodeList<>();

		MethodDeclaration method = new MethodDeclaration();
		modifiers.add(Modifier.publicModifier());
		method.setModifiers(modifiers);

		method.setType(type);

		method.setName(TO_STRING);
		method.addMarkerAnnotation(Constant.overrideClazz);
		
//		buffer = insertToTostring(coid, methodDeclaration2, DOB_TO_STRING, buffer, DATE_OF_BIRTH);
		buffer = insertToTostring(coid, methodDeclaration1, CALCULATE_AGE, buffer, AGE_IDENFIFIER);
		

		method
			.getBody()
			.get()
			.getStatements()
			.add(new ReturnStmt(new NameExpr(buffer.toString())));

		ToStringUtil.removeOldMethod(coid, TO_STRING);
		coid.getMembers().add(method);

		String packageName = DirCreatorUtil.getPackageName(cu);
		packageName = packageName.replaceFirst("u1", "u2");
		
		String directory = DirCreatorUtil.buildDir(cu);
		directory = directory.replaceFirst("u1", "u2");
		
		String identifier = directory.replace("/", ".");
		identifier = identifier.substring(0, identifier.lastIndexOf("."));

		cu.setPackageDeclaration(new PackageDeclaration().setName(new Name(identifier)));
		DirCreatorUtil.createDir(directory);

		setImportFromGenerated(cu);
		getTemplate(cu, directory, javaFileName + Constant.JAVA);
	}

	 /**
	  * Insert a method in toString()
	  * 
	  * @param coid - The ClassOrInterfaceDeclaration the method belong to
	  * @param methodDeclaration - the method declaration
	  * @param methodName - the method to be added
	  * @param buffer - a StringBuffer to build the toString method
	  * @param identifier - the identifier to use when formating the toString method
	  * @return buffer with to result
	  */
	private StringBuffer insertToTostring(ClassOrInterfaceDeclaration coid, 
			MethodDeclaration methodDeclaration, 
			String methodName,
			StringBuffer buffer, String identifier) {
		
		if (coid.getMethodsByName(methodName).contains(methodDeclaration)) {
			buffer.replace(buffer.length()-2, buffer.length()-1, Constant.COMMA)
					.append(Constant.PLUS)
					.append(Constant.DOUBLE_QUOTE)
					.append(identifier).append(Constant.EQUAL_AND_QUOTE);
			
			buffer.append(Constant.PLUS)
					.append(new MethodCallExpr(new ThisExpr(), methodName))
					.append(Constant.PLUS).append(Constant.DOUBLE_QUOTE)
					.append(Constant.SQUARED_BRACKET_CLOSE).append(Constant.DOUBLE_QUOTE);
		}
		return buffer;
	}

	/**
	 * 
	 * @param coid - The ClassOrInterfaceDeclaration the method belong to
	 * @param name - The method name
	 */
	private void insertCheckAgeStatments(ClassOrInterfaceDeclaration coid, String name) {
		MethodDeclaration setter = coid.getMethodsByName(name).stream().findFirst().get();
		Node ifStmt = getIfStmt();
		setter.getBody().get().getStatements().remove(ifStmt );
		setter.getBody().get()
							.getStatements()
							.add(getIfStmt());
		
	}

	private IfStmt getIfStmt() {
		return new IfStmt()
					.setCondition(
							new BinaryExpr(
									new MethodCallExpr(new ThisExpr(), CALCULATE_AGE), 
									new IntegerLiteralExpr(_18), 
									com.github.javaparser.ast.expr.BinaryExpr.Operator.LESS))
					.setThenStmt(
							new ExpressionStmt(
									new AssignExpr(
											new FieldAccessExpr(new ThisExpr(), DATE_OF_BIRTH), 
											new NullLiteralExpr(), 
											Operator.ASSIGN)));
	}

	/**
	 * Insert new method calculateAge() to the {@link generated.de.thb.dim.pizzaPronto.Customer}
	 * @param coid - the represented ClassOrInterfaceDeclaration
	 */
	private void insertCalculateMethod(ClassOrInterfaceDeclaration coid) {
		
		NodeList<Modifier> visibities = new NodeList<>();
		Type type = new ClassOrInterfaceType().setName(SHORT);
		visibities.add(Modifier.publicModifier());
		MethodDeclaration methodDeclaration = new MethodDeclaration(visibities, type, CALCULATE_AGE);
		
		NodeList<Statement> methodStatements = new NodeList<>();

		String variableNameAlter = ALTER;
		VariableDeclarator alterDecl = new VariableDeclarator(
												new ClassOrInterfaceType().setName(SHORT),
												variableNameAlter, 
												new IntegerLiteralExpr(_1));

		String variableNameAge = AGE;
		String nameMethod_Period = PERIOD;
		String fieldName = DATE_OF_BIRTH;
		VariableDeclarator ageDecl = new VariableDeclarator(
												new ClassOrInterfaceType().setName(nameMethod_Period), 
												variableNameAge);

		String nameLocalDate = LOCAL_DATE;
		String variableNameToday = TODAY;
		AssignExpr todayDecl = new AssignExpr(
												new VariableDeclarationExpr(
														new VariableDeclarator(
																new ClassOrInterfaceType().setName(nameLocalDate), 
																variableNameToday)),
												new MethodCallExpr(new NameExpr(nameLocalDate), NOW), 
												Operator.ASSIGN);

		NodeList<Statement> ifBody = new NodeList<>();
		ifBody.add(new ExpressionStmt(new VariableDeclarationExpr(ageDecl)));

		NodeList<Expression> args = new NodeList<>();
		args.add(new NameExpr(fieldName));
		args.add(new NameExpr(variableNameToday));
	
		Expression ageValue = new MethodCallExpr(new NameExpr(nameMethod_Period), BETWEEN, args);
		Statement ifNode1 = new ExpressionStmt(
												new AssignExpr(
														new NameExpr(variableNameAge), 
														ageValue, 
														Operator.ASSIGN));

		Statement ifNode2 = new ExpressionStmt(
												new AssignExpr(
														new NameExpr(variableNameAlter),
														new CastExpr(
																new ClassOrInterfaceType().setName(SHORT),
																new MethodCallExpr(new NameExpr(variableNameAge), GET_YEARS)),
														Operator.ASSIGN));

		ifBody.add(ifNode1);
		ifBody.add(ifNode2);

		BlockStmt thenStmt = new BlockStmt(ifBody);

		IfStmt ifStmt = new IfStmt()
									.setCondition(new BinaryExpr(
											new NameExpr(fieldName), 
											new NullLiteralExpr(), 
											com.github.javaparser.ast.expr.BinaryExpr.Operator.NOT_EQUALS))
									.setThenStmt(thenStmt);

		Statement returnStmt = new ReturnStmt(new NameExpr(variableNameAlter));

		methodStatements.add(new ExpressionStmt(new VariableDeclarationExpr(alterDecl)));
		methodStatements.add(new ExpressionStmt(new VariableDeclarationExpr(ageDecl)));
		methodStatements.add(new ExpressionStmt(todayDecl));
		methodStatements.add(ifStmt);
		methodStatements.add(returnStmt);

		methodDeclaration.setBody(new BlockStmt(methodStatements));

		coid.getMembers().removeAll(coid.getMethodsByName(CALCULATE_AGE));
		coid.getMembers().addLast(methodDeclaration);
	}

	private void setImportFromGenerated(CompilationUnit cu) {
		for (ImportDeclaration importDeclaration : cu.getImports()) {
			
			String importString = importDeclaration.getName().toString();
			String patternString_one = "u1";
			String patternString_two = "u2";
			
			if(PatternFilter.isSubstring(importString,patternString_one)) {
				importString = importString.replaceFirst(patternString_one, patternString_two);
				importDeclaration.setName(new Name(importString));
			}
		}
	}

	
	
	@Override
	public void getTemplate(CompilationUnit cu, String directory, String file) {
		TemplateModelWriter.getTemplateModel(cu).writeFileTo(directory, file);
	}
}
