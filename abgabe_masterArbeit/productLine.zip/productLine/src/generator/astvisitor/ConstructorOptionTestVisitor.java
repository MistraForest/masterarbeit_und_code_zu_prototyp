package generator.astvisitor;

import com.github.javaparser.ast.CompilationUnit;
import com.github.javaparser.ast.body.ClassOrInterfaceDeclaration;
import com.github.javaparser.ast.visitor.VoidVisitorAdapter;

import constants.Constant;
import utils.DirCreatorUtil;
import utils.TemplateModelWriter;
import utils.TestConfigUtil;
import utils.generator.handler.IGeneratorToTemplate;

/**
 * This class build and generate the test feature of constructors.
 * @author forest
 *
 */
public class ConstructorOptionTestVisitor implements IGeneratorToTemplate{

	private String javaFileName;
	private String clazzName;

	public ConstructorOptionTestVisitor(String javaFileName, String clazzName) {
		this.javaFileName = javaFileName;
		this.clazzName = clazzName;
	}

	public class ChefFirstOptionTestVisitor extends VoidVisitorAdapter<Object> {
		@Override
		public void visit(ClassOrInterfaceDeclaration coid, Object arg) {
			super.visit(coid, arg);
			CompilationUnit cu = coid.findCompilationUnit().get();

			TestConfigUtil.ChefUtil.addFirstOptionMethod(coid, clazzName);

			String directory = DirCreatorUtil.buildDir(cu);
			getTemplate(cu, directory, javaFileName + Constant.JAVA);
		}
	}
	

	public class Customer1stOptionTestVisitor extends VoidVisitorAdapter<Object> {
		@Override
		public void visit(ClassOrInterfaceDeclaration coid, Object arg) {
			super.visit(coid, arg);
			CompilationUnit cu = coid.findCompilationUnit().get();

			TestConfigUtil.CustomerUtil.addFirstOptionMethod(coid, clazzName);

			String directory = DirCreatorUtil.buildDir(cu);
			getTemplate(cu, directory, javaFileName + Constant.JAVA);
		}
	}


	public class ChefSecondOptionTestVisitor extends VoidVisitorAdapter<Object> {

		@Override
		public void visit(ClassOrInterfaceDeclaration coid, Object arg) {
			super.visit(coid, arg);
			CompilationUnit cu = coid.findCompilationUnit().get();

			TestConfigUtil.ChefUtil.addSecondOptionMethod(coid, clazzName);

			String directory = DirCreatorUtil.buildDir(cu);
			getTemplate(cu, directory, javaFileName + Constant.JAVA);
		}
	}
	

	public class Customer2ndOptionTestVisitor extends VoidVisitorAdapter<Object> {
		@Override
		public void visit(ClassOrInterfaceDeclaration coid, Object arg) {
			super.visit(coid, arg);
			CompilationUnit cu = coid.findCompilationUnit().get();

			TestConfigUtil.CustomerUtil.addSecondOptionMethod(coid, clazzName);

			String directory = DirCreatorUtil.buildDir(cu);
			getTemplate(cu, directory, javaFileName + Constant.JAVA);
		}
	}
	

	public class Customer03OptionTestVisitor extends VoidVisitorAdapter<Object> {
		@Override
		public void visit(ClassOrInterfaceDeclaration coid, Object arg) {
			super.visit(coid, arg);
			CompilationUnit cu = coid.findCompilationUnit().get();

			TestConfigUtil.CustomerUtil.addThirdOptionMethod(coid, clazzName);

			String directory = DirCreatorUtil.buildDir(cu);
			getTemplate(cu, directory, javaFileName + Constant.JAVA);
		}
	}



	public class SecondOptionPizzaVisitor extends VoidVisitorAdapter<Object> {
		@Override
		public void visit(ClassOrInterfaceDeclaration coid, Object arg) {
			super.visit(coid, arg);
			CompilationUnit cu = coid.findCompilationUnit().get();

			TestConfigUtil.PizzaUtil.add2ndOptionPizzaMethod(coid, clazzName);

			String directory = DirCreatorUtil.buildDir(cu);
			getTemplate(cu, directory, javaFileName + Constant.JAVA);
		}
	}

	public class FirstOptionPizzaVisitor extends VoidVisitorAdapter<Object> {
		@Override
		public void visit(ClassOrInterfaceDeclaration coid, Object arg) {
			super.visit(coid, arg);
			CompilationUnit cu = coid.findCompilationUnit().get();

			TestConfigUtil.PizzaUtil.add1stOptionPizzaMethod(coid, clazzName);

			String directory = DirCreatorUtil.buildDir(cu);
			getTemplate(cu, directory, javaFileName + Constant.JAVA);
		}
	}

	public ChefSecondOptionTestVisitor get2ndOptionTestVisitor() {
		return new ChefSecondOptionTestVisitor();
	}

	public ChefFirstOptionTestVisitor get1stOptionTestVisitor() {
		return new ChefFirstOptionTestVisitor();
	}

	public SecondOptionPizzaVisitor get2ndOptionPizzaVisitor() {
		return new SecondOptionPizzaVisitor();
	}

	public FirstOptionPizzaVisitor get1stOptionPizzaVisitor() {
		return new FirstOptionPizzaVisitor();
	}

	public Customer2ndOptionTestVisitor getCustomer2ndOptionTestVisitor() {
		return new Customer2ndOptionTestVisitor();
	}

	public Customer1stOptionTestVisitor getCustomer1stOptionTestVisitor() {
		return new Customer1stOptionTestVisitor();
	}

	public Customer03OptionTestVisitor getCustomer03OptionTestVisitor() {
		return new Customer03OptionTestVisitor();
	}

	@Override
	public void getTemplate(CompilationUnit cu, String directory, String file) {
		TemplateModelWriter.getTemplateModel(cu).writeFileTo(directory, file);
	}

}
