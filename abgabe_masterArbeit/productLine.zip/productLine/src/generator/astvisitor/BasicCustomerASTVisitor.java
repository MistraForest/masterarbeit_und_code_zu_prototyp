package generator.astvisitor;

import java.util.List;
import java.util.stream.Collectors;

import com.github.javaparser.ast.CompilationUnit;
import com.github.javaparser.ast.ImportDeclaration;
import com.github.javaparser.ast.PackageDeclaration;
import com.github.javaparser.ast.body.ClassOrInterfaceDeclaration;
import com.github.javaparser.ast.body.ConstructorDeclaration;
import com.github.javaparser.ast.expr.Name;
import com.github.javaparser.ast.visitor.VoidVisitorAdapter;

import constants.Constant;
import utils.DirCreatorUtil;
import utils.TemplateModelWriter;
import utils.FilterUtil.PatternFilter;
import utils.generator.handler.IGeneratorToTemplate;

/**
 * This class is used for the first feature generation for the "customer" class of the
 * Pizza-Pronto application.
 * 
 * @author forest
 *
 */
public class BasicCustomerASTVisitor extends VoidVisitorAdapter<Object> implements IGeneratorToTemplate {
	private String root = "generated/";
	private String javaFileName;
	
	public BasicCustomerASTVisitor(String javaFileName) {
		this.javaFileName = javaFileName;
	}

	@Override
	public void visit(ClassOrInterfaceDeclaration coid, Object arg) {
		super.visit(coid, arg);
		CompilationUnit cu = coid.findCompilationUnit().get();

		removeConstructorByParamNumber(3, coid);

		String packageName = DirCreatorUtil.getPackageName(cu).concat("."+DirCreatorUtil.U1.replace("/", ""));

		String directory = DirCreatorUtil.buildDir(cu)+DirCreatorUtil.U1;

		String rootWithoutSlash = root.replace("/", ".");
		String identifier = rootWithoutSlash + packageName;
		
		cu.setPackageDeclaration(new PackageDeclaration()
				.setName(new Name(identifier)));

		// create fresh one
		DirCreatorUtil.createDir(root + directory);

		setImportFromGeneratedRoot(cu, rootWithoutSlash);
		
		getTemplate(cu, root + directory, javaFileName + Constant.JAVA);
	}
	
	@Override
	public void getTemplate(CompilationUnit cu, String directory, String file) {
		TemplateModelWriter.getTemplateModel(cu).writeFileTo(directory, file);
	}
	
	private void removeConstructorByParamNumber(int paramNumber, ClassOrInterfaceDeclaration coid) {
		ConstructorDeclaration constructorDeclaration = getConstructorByParamNumber(coid, paramNumber);
		coid.remove(constructorDeclaration);
	}
	
	private ConstructorDeclaration getConstructorByParamNumber(ClassOrInterfaceDeclaration coid, int paramNumber) {
		List<ConstructorDeclaration> constructors = coid.getConstructors().stream()
				.filter(f -> f.getParameters().size() == paramNumber).collect(Collectors.toList());
		ConstructorDeclaration constructorDeclaration = constructors.get(0);
		return constructorDeclaration;
	}
	
	private void setImportFromGeneratedRoot(CompilationUnit cu, String rootWithoutSlash) {
		for (ImportDeclaration importDeclaration : cu.getImports()) {
			
			String importString = importDeclaration.getName().toString();
			String patternString_one = ".pizzaPronto";
			String patternString_two = ".u1";
			
			if(PatternFilter.isSubstring(importString,patternString_one)) {
				importString = importString.replaceFirst("de.thb", rootWithoutSlash+"de.thb");
			
				importString = importString.replaceFirst(patternString_one, patternString_one+patternString_two);
				 				
				importDeclaration.setName(new Name(importString));
			}
				
		}
	}

}
