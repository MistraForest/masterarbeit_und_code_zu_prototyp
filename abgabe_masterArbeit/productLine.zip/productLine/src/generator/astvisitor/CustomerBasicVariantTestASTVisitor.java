package generator.astvisitor;

import com.github.javaparser.ast.CompilationUnit;
import com.github.javaparser.ast.ImportDeclaration;
import com.github.javaparser.ast.PackageDeclaration;
import com.github.javaparser.ast.body.ClassOrInterfaceDeclaration;
import com.github.javaparser.ast.expr.Name;
import com.github.javaparser.ast.visitor.VoidVisitorAdapter;

import constants.Constant;
import utils.DirCreatorUtil;
import utils.TemplateModelWriter;
import utils.TestConfigUtil;
import utils.FilterUtil.PatternFilter;
import utils.generator.handler.IGeneratorToTemplate;

/**
 * This class generate the test class of the "CustomerVO". The others test features
 * will be based on this class.
 * @author forest
 *
 */
public class CustomerBasicVariantTestASTVisitor extends VoidVisitorAdapter<Object> implements IGeneratorToTemplate{

	private String javaFileName;
	private String clazzName;

	public CustomerBasicVariantTestASTVisitor(String javaFileName, String clazzName) {
		this.javaFileName = javaFileName;
		this.clazzName = clazzName;
	}
	
	@Override
	public void visit(ClassOrInterfaceDeclaration coid, Object arg) {
		super.visit(coid, arg);
		CompilationUnit cu = coid.findCompilationUnit().get();

		TestConfigUtil.CustomerUtil.addTestAttributes(coid, clazzName);
		TestConfigUtil.CustomerUtil.addInitOnce(coid, clazzName);
		TestConfigUtil.CustomerUtil.fillMethodInitEach(coid, clazzName);
		TestConfigUtil.CustomerUtil.test6Attributes(coid, clazzName);
		TestConfigUtil.CustomerUtil.testShortCalculateAge(coid, clazzName);
		TestConfigUtil.CustomerUtil.testCustomerVOnoAttributeAge(coid, clazzName);
		TestConfigUtil.CustomerUtil.testIdStart0(coid, clazzName);
		TestConfigUtil.CustomerUtil.testIdofObjectNoChange(coid, clazzName);
		TestConfigUtil.CustomerUtil.testIdsIncreasing(coid, clazzName);
		TestConfigUtil.CustomerUtil.dobToStringPrivate(coid, clazzName);
		TestConfigUtil.CustomerUtil.calculateAgeDoBNull(coid, clazzName);
		TestConfigUtil.CustomerUtil.calculateDoBFor16Years(coid, clazzName);
		TestConfigUtil.CustomerUtil.calculateDoBFor18Years(coid, clazzName);
		TestConfigUtil.CustomerUtil.calculateDoBFor17Years(coid, clazzName);
		TestConfigUtil.CustomerUtil.calculateDoBFor60Years(coid, clazzName);
		TestConfigUtil.CustomerUtil.addMethodEqualsNull(coid, clazzName);
		TestConfigUtil.CustomerUtil.addEqualsDefaultConstructors(coid, clazzName);
		TestConfigUtil.CustomerUtil.addEqualsIniAndDefaultConstructors(coid, clazzName);
		TestConfigUtil.CustomerUtil.addEquals2EqualObjects(coid, clazzName);
		TestConfigUtil.CustomerUtil.addEquals2IdenticalObjects(coid, clazzName);
		TestConfigUtil.CustomerUtil.addEquals3EqualObjects(coid, clazzName);
		TestConfigUtil.CustomerUtil.addEqualsOtherNoLastname(coid, clazzName);
		TestConfigUtil.CustomerUtil.addEqualsThisNoLastname(coid, clazzName);
		TestConfigUtil.CustomerUtil.addEqualsOtherNoFirstname(coid, clazzName);
		TestConfigUtil.CustomerUtil.addEqualsThisNoFirstname(coid, clazzName);
		TestConfigUtil.CustomerUtil.addEqualsOtherNoDob(coid, clazzName);
		TestConfigUtil.CustomerUtil.addEqualsThisNoDob(coid, clazzName);
		TestConfigUtil.CustomerUtil.addEqualsDifferentObjects(coid, clazzName);
		TestConfigUtil.CustomerUtil.addEqualsDifferentObjectsDifferentClasses(coid, clazzName);
		TestConfigUtil.CustomerUtil.addHashCodeTest(coid, clazzName);
		TestConfigUtil.CustomerUtil.addToStringTest(coid, clazzName);
		TestConfigUtil.CustomerUtil.testNoSettersForIds(coid, clazzName);
		TestConfigUtil.CustomerUtil.testStaticGetterForNextId(coid, clazzName);
		TestConfigUtil.CustomerUtil.getIdTest(coid, clazzName);
		TestConfigUtil.CustomerUtil.setDateOfBirthCorrectDate(coid, clazzName);
		TestConfigUtil.CustomerUtil.setDateOfBirthAgeTooYoung(coid, clazzName);
		TestConfigUtil.CustomerUtil.setDateOfBirthAge60(coid, clazzName);
		TestConfigUtil.CustomerUtil.setDateOfBirthLeapYear(coid, clazzName);

		
//		String directory = DirCreatorUtil.buildDir(cu)+DirCreatorUtil.U2;
		String packageName = DirCreatorUtil.getPackageName(cu);
		packageName = packageName.replaceFirst("u1", "u2");
		

		String directory = DirCreatorUtil.buildDir(cu);
		directory = directory.replaceFirst("u1", "u2");
		
		String identifier = directory.replace("/", ".");
		identifier = identifier.substring(0, identifier.lastIndexOf("."));

		cu.setPackageDeclaration(new PackageDeclaration().setName(new Name(identifier)));
		DirCreatorUtil.createDir(directory);
		
		setImportFromGenerated(cu);
		
//		TemplateModelWriter.getTemplateModel(cu).writeFileTo(directory, javaFileName + Constant.JAVA);
		getTemplate(cu, directory, javaFileName + Constant.JAVA);
	}
	
	public void setImportFromGenerated(CompilationUnit cu) {
		for (ImportDeclaration importDeclaration : cu.getImports()) {
			
			String importString = importDeclaration.getName().toString();
			String patternString_one = ".u1";
			String patternString_two = ".u2";
			
			if(PatternFilter.isSubstring(importString,patternString_one)) {
				importString = importString.replaceFirst(patternString_one,patternString_two);
				importDeclaration.setName(new Name(importString));
			}
		}
	}

	@Override
	public void getTemplate(CompilationUnit cu, String directory, String file) {
		TemplateModelWriter.getTemplateModel(cu).writeFileTo(directory, file);
	}

}
