package generator.astvisitor;

import java.util.List;
import java.util.stream.Collectors;

import com.github.javaparser.ast.CompilationUnit;
import com.github.javaparser.ast.Modifier;
import com.github.javaparser.ast.NodeList;
import com.github.javaparser.ast.PackageDeclaration;
import com.github.javaparser.ast.body.ClassOrInterfaceDeclaration;
import com.github.javaparser.ast.body.ConstructorDeclaration;
import com.github.javaparser.ast.body.FieldDeclaration;
import com.github.javaparser.ast.body.VariableDeclarator;
import com.github.javaparser.ast.expr.AssignExpr;
import com.github.javaparser.ast.expr.AssignExpr.Operator;
import com.github.javaparser.ast.expr.Expression;
import com.github.javaparser.ast.expr.IntegerLiteralExpr;
import com.github.javaparser.ast.expr.Name;
import com.github.javaparser.ast.expr.NameExpr;
import com.github.javaparser.ast.expr.UnaryExpr;
import com.github.javaparser.ast.stmt.ExpressionStmt;
import com.github.javaparser.ast.stmt.Statement;
import com.github.javaparser.ast.type.ClassOrInterfaceType;
import com.github.javaparser.ast.visitor.VoidVisitorAdapter;

import constants.Constant;
import utils.DirCreatorUtil;
import utils.TemplateModelWriter;
import utils.generator.handler.IGeneratorToTemplate;

/**
 * This class will modify a given java class by generating new fields in it.
 * @author forest
 *
 */
public class AttributesVariantVisitor implements IGeneratorToTemplate{

	private String javaFileName;

	public AttributesVariantVisitor(String javaFileName) {
		this.javaFileName = javaFileName;
	}

	public class ConstructorWithNewAttributes extends VoidVisitorAdapter<Object> {
	
		private static final String _0 = "0";
		private static final String ID = "id";
		private static final String NEXT_ID = "nextId";
		private String[] parameters;

		public ConstructorWithNewAttributes(String[] parameters) {
			this.parameters = parameters;
		}

		@Override
		public void visit(ClassOrInterfaceDeclaration coid, Object arg) {
			super.visit(coid, arg);
			CompilationUnit cu = coid.findCompilationUnit().get();
//			
			List<FieldDeclaration> fields = coid.getFields();
			NodeList<Modifier> modifiers = new NodeList<>();
			modifiers.add(Modifier.privateModifier());
			modifiers.add(Modifier.staticModifier());		
			Expression initializer = new IntegerLiteralExpr(_0);
			
			VariableDeclarator variable1 = new VariableDeclarator(new ClassOrInterfaceType().setName(Constant.INT_SIMPLE_NAME), NEXT_ID, initializer);	
			VariableDeclarator variable2 = new VariableDeclarator(new ClassOrInterfaceType().setName(Constant.INT_SIMPLE_NAME), ID);
			
			FieldDeclaration fieldDecl1 = new FieldDeclaration(modifiers, variable1);
			
			modifiers = new NodeList<>();
			modifiers.add(Modifier.privateModifier());
			FieldDeclaration fieldDecl2 = new FieldDeclaration(modifiers, variable2);
			
			fields.stream()
				.filter(
						f->f.getVariable(0).getNameAsString().equals(fieldDecl1.getVariable(0).getNameAsString()) || 
						f.getVariable(0).getNameAsString().equals(fieldDecl2.getVariable(0).getNameAsString())
						)
				.forEach(f->{
					coid.getMember(0).remove();
				});
			coid.getMembers().addFirst(fieldDecl2);
			coid.getMembers().addFirst(fieldDecl1);
			
			coid.getMembers().removeAll(coid.getMethodsByName(fieldDecl1.createGetter().getNameAsString()));
			coid.getMembers().removeAll(coid.getMethodsByName(fieldDecl2.createGetter().getNameAsString()));

			fieldDecl1.createGetter();
			fieldDecl2.createGetter();
			
			ConstructorDeclaration constDecl = coid.getConstructorByParameterTypes(parameters).get();
			Statement node1 = new ExpressionStmt(new AssignExpr(new NameExpr(ID), new NameExpr(NEXT_ID), Operator.ASSIGN));
			Statement node2 = new ExpressionStmt(new UnaryExpr(new NameExpr(NEXT_ID), com.github.javaparser.ast.expr.UnaryExpr.Operator.POSTFIX_INCREMENT));		
			
			NodeList<Statement> statements = constDecl.getBody().getStatements();

			List<Statement> list1 = statements.stream()
					.filter(f->f.asExpressionStmt().getExpression().isUnaryExpr())
					.collect(Collectors.toList());
			
			List<Statement> list2  = statements.stream()
						.filter(f->f.asExpressionStmt().getExpression().isAssignExpr())
						.collect(Collectors.toList());
			
			// Remove extra nodes due to multiple instance creation in the main
			statements.removeAll(list1);
			statements.removeAll(list2);
			
			statements.addFirst(node2);
			statements.addFirst(node1);

			String packageName = DirCreatorUtil.getPackageName(cu);
			packageName = packageName.replaceFirst("u1", "u2");
			

			String directory = DirCreatorUtil.buildDir(cu);
			directory = directory.replaceFirst("u1", "u2");
			
			String identifier = directory.replace("/", ".");
			identifier = identifier.substring(0, identifier.lastIndexOf("."));

			cu.setPackageDeclaration(new PackageDeclaration().setName(new Name(identifier)));
			DirCreatorUtil.createDir(directory);
			
//			TemplateModelWriter.getTemplateModel(cu).writeFileTo(directory, javaFileName + Constant.JAVA);
			getTemplate(cu, directory, javaFileName + Constant.JAVA);
		}
 
	}

	public ConstructorWithNewAttributes getWithConstructorVariant(String[] parameters) {
		return new ConstructorWithNewAttributes(parameters);
	}

	@Override
	public void getTemplate(CompilationUnit cu, String directory, String file) {
		TemplateModelWriter.getTemplateModel(cu).writeFileTo(directory, file);
	}

}
