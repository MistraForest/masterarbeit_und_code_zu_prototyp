package generator.astvisitor;

import com.github.javaparser.ast.CompilationUnit;
import com.github.javaparser.ast.PackageDeclaration;
import com.github.javaparser.ast.body.ClassOrInterfaceDeclaration;
import com.github.javaparser.ast.expr.Name;
import com.github.javaparser.ast.visitor.VoidVisitorAdapter;

import constants.Constant;
import utils.DirCreatorUtil;
import utils.TemplateModelWriter;
import utils.TestConfigUtil;
import utils.generator.handler.IGeneratorToTemplate;

/**
 * This orchestrate the build and generation of the classes of third feature groups "Uebung3"
 * @author forest
 *
 */
public class ThirdGenerationVisitor implements IGeneratorToTemplate{

	private String clazzName;

	public ThirdGenerationVisitor(String clazzName) {
		this.clazzName = clazzName;
	}

	/**
	 * This class generate the ChefVO class in the third feature generation.
	 * The import statements and the package will be taking in account.
	 * @author forest
	 *
	 */
	public class Chef3rdGenVisitor extends VoidVisitorAdapter<Object> {

		@Override
		public void visit(ClassOrInterfaceDeclaration coid, Object arg) {
			super.visit(coid, arg);

			CompilationUnit cu = coid.findCompilationUnit().get();

//			TestConfigUtil.PizzaUtil.add1stOptionPizzaMethod(coid, clazzName);

//			String directory = DirCreatorUtil.buildDir(cu) + DirCreatorUtil.U3;
			
			String packageName = DirCreatorUtil.getPackageName(cu);
			packageName = packageName.replaceFirst("u2", "u3");
			

			String directory = DirCreatorUtil.buildDir(cu);
			directory = directory.replaceFirst("u2", "u3");
			
			String identifier = directory.replace("/", ".");
			identifier = identifier.substring(0, identifier.lastIndexOf("."));

			cu.setPackageDeclaration(new PackageDeclaration().setName(new Name(identifier)));
			DirCreatorUtil.createDir(directory);
			
			getTemplate(cu, directory, clazzName + Constant.JAVA);
		}
	}

	/**
	 * This class generate the PizzVO class in the third feature generation.
	 * The import statements and the package will be taking in account.
	 * @author forest
	 *
	 */
	public class Pizza3rdGenVisitor extends VoidVisitorAdapter<Object> {

		@Override
		public void visit(ClassOrInterfaceDeclaration coid, Object arg) {
			super.visit(coid, arg);

			CompilationUnit cu = coid.findCompilationUnit().get();

//			String directory = DirCreatorUtil.buildDir(cu) + DirCreatorUtil.U3;
			
			String packageName = DirCreatorUtil.getPackageName(cu);
			packageName = packageName.replaceFirst("u2", "u3");
			

			String directory = DirCreatorUtil.buildDir(cu);
			directory = directory.replaceFirst("u2", "u3");
			
			String identifier = directory.replace("/", ".");
			identifier = identifier.substring(0, identifier.lastIndexOf("."));

			cu.setPackageDeclaration(new PackageDeclaration().setName(new Name(identifier)));
			DirCreatorUtil.createDir(directory);
			
			getTemplate(cu, directory, clazzName + Constant.JAVA);
		}
	}

	/**
	 * This class prepare the class of the CustomerVO class in the third feature generation.
	 * New fields and methods regarding the association class "OrderVO" will be added
	 * @author forest
	 *
	 */
	public class Customer3rdGenVisitor extends VoidVisitorAdapter<Object> {

		@Override
		public void visit(ClassOrInterfaceDeclaration coid, Object arg) {
			super.visit(coid, arg);

			CompilationUnit cu = coid.findCompilationUnit().get();

			TestConfigUtil.CustomerUtil.addFieldFromOrderType(coid);
			TestConfigUtil.CustomerUtil.addMethodHasOrder(coid);

//			String directory = DirCreatorUtil.buildDir(cu) + DirCreatorUtil.U3;
			
			String packageName = DirCreatorUtil.getPackageName(cu);
			packageName = packageName.replaceFirst("u2", "u3");
			

			String directory = DirCreatorUtil.buildDir(cu);
			directory = directory.replaceFirst("u2", "u3");
			
			String identifier = directory.replace("/", ".");
			identifier = identifier.substring(0, identifier.lastIndexOf("."));

			cu.setPackageDeclaration(new PackageDeclaration().setName(new Name(identifier)));
			DirCreatorUtil.createDir(directory);
			
			getTemplate(cu, directory, clazzName + Constant.JAVA);
		}
	}

	public Chef3rdGenVisitor getChef3rdGenVisitor() {
		return new Chef3rdGenVisitor();
	}

	public Pizza3rdGenVisitor getPizza3rdGenVisitor() {
		return new Pizza3rdGenVisitor();
	}

	public Customer3rdGenVisitor getCustomer3rdGenVisitor() {
		return new Customer3rdGenVisitor();
	}

	@Override
	public void getTemplate(CompilationUnit cu, String directory, String file) {
		TemplateModelWriter.getTemplateModel(cu).writeFileTo(directory, file);
	}
}
