package generator.astvisitor;

import com.github.javaparser.ast.CompilationUnit;
import com.github.javaparser.ast.body.ClassOrInterfaceDeclaration;
import com.github.javaparser.ast.visitor.VoidVisitorAdapter;

import utils.ConstructorUtil;
import utils.DirCreatorUtil;
import utils.TemplateModelWriter;
import utils.exceptions.InvalidParameterNumber;
import utils.generator.handler.IGeneratorToTemplate;

/**
 * This class is used to transform the model for a constructor to a feature.
 * The existing constructors are used as the basis of the transformation.
 * @author forest
 *
 */
public class ConstructorVisitor extends VoidVisitorAdapter<Object> implements IGeneratorToTemplate{

	private int paramNumber;
	private String javaFileName;

	public ConstructorVisitor(int paramNumber, String javaFileName) {
		this.paramNumber = paramNumber;
		this.javaFileName = javaFileName;
	}

	@Override
	public void visit(ClassOrInterfaceDeclaration coid, Object arg) {
		super.visit(coid, arg);

		CompilationUnit cu = coid.findCompilationUnit().get();
		try {
			ConstructorUtil.addNewConstructor(paramNumber, coid);
		} catch (InvalidParameterNumber e1) {
			e1.printStackTrace();
		}
		
		String directory = DirCreatorUtil.buildDir(cu);
		DirCreatorUtil.createDir(directory);

		getTemplate(cu, directory, javaFileName + ".java");
	}

	@Override
	public void getTemplate(CompilationUnit cu, String directory, String file) {
		TemplateModelWriter.getTemplateModel(cu).writeFileTo(directory, file);
	}
}
