package generator.astvisitor;

import java.util.List;

import com.github.javaparser.ast.CompilationUnit;
import com.github.javaparser.ast.body.ClassOrInterfaceDeclaration;
import com.github.javaparser.ast.body.MethodDeclaration;
import com.github.javaparser.ast.expr.NameExpr;
import com.github.javaparser.ast.visitor.VoidVisitorAdapter;

import constants.Constant;
import utils.DirCreatorUtil;
import utils.TemplateModelWriter;
import utils.generator.handler.IGeneratorToTemplate;

/**
 * This class handle the setter method variant in the PizzaVO class without the additional check
 * for prices not to be negative. An additional warning comment message will be be generated.
 * 
 * Furthermore the test variant should not be generated since this variant is discouraged 
 * to be used in a production environment.
 * @author forest
 *
 */
public class WithoutSetterCheckAstVisitor extends VoidVisitorAdapter<Object> implements IGeneratorToTemplate {

	private String javaFileName;
	private String setter;

	public WithoutSetterCheckAstVisitor(String setter, String javaFileName) {
		this.setter = setter;
		this.javaFileName = javaFileName;
	}

	@Override
	public void visit(ClassOrInterfaceDeclaration coid, Object arg) {
		super.visit(coid, arg);
		CompilationUnit cu = coid.findCompilationUnit().get();
		cu.removeComment();
		modifySetter(setter, coid);

		String directory = DirCreatorUtil.buildDir(cu);
		DirCreatorUtil.createDir(directory);

		getTemplate(cu, directory, javaFileName + Constant.JAVA);
	}
	
	@Override
	public void getTemplate(CompilationUnit cu, String directory, String file) {
		TemplateModelWriter.getTemplateModel(cu).writeFileTo(directory, file);
	}

	private void modifySetter(String setter, ClassOrInterfaceDeclaration coid) {
		List<MethodDeclaration> methodsByName = coid.getMethodsByName(setter);
		if (methodsByName.isEmpty()) {
			return;
		}
		MethodDeclaration method = methodsByName.get(0);

		// Set warning comment not to used this variant in the production environment
		method.setBlockComment("This method is not implemented as designed. "
				+ "\n\tPlease add additional check to improve it. ");
		
		method.getBody().get()
						.getStatements()
						.getFirst().get()
						.asExpressionStmt()
						.getExpression()
						.asAssignExpr()
						.setValue(
								new NameExpr(
										method.getParameters()
										.getFirst()
										.get()
										.getNameAsString()
										)
								);
	}
}
