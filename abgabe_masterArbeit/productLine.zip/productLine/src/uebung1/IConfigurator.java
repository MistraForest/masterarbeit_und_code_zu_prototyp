package uebung1;


/**
 * This interface should be implemented in concrete features.
 * After a configuration selection the processSelectedConfig() method 
 * will handle the process to generate the correct code
 * @author forest
 *
 */
public interface IConfigurator {
	/**
	 * The method will be use to handle the generation process after a valid configuration is selected
	 */
	void processSelectedConfig();
}
