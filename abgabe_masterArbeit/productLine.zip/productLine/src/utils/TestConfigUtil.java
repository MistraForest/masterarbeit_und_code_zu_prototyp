package utils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.stream.Stream;

import org.junit.jupiter.api.BeforeAll;

import com.github.javaparser.ast.ImportDeclaration;
import com.github.javaparser.ast.Modifier;
import com.github.javaparser.ast.Modifier.Keyword;
import com.github.javaparser.ast.NodeList;
import com.github.javaparser.ast.body.BodyDeclaration;
import com.github.javaparser.ast.body.ClassOrInterfaceDeclaration;
import com.github.javaparser.ast.body.FieldDeclaration;
import com.github.javaparser.ast.body.MethodDeclaration;
import com.github.javaparser.ast.body.Parameter;
import com.github.javaparser.ast.body.VariableDeclarator;
import com.github.javaparser.ast.expr.AnnotationExpr;
import com.github.javaparser.ast.expr.ArrayCreationExpr;
import com.github.javaparser.ast.expr.ArrayInitializerExpr;
import com.github.javaparser.ast.expr.AssignExpr;
import com.github.javaparser.ast.expr.AssignExpr.Operator;
import com.github.javaparser.ast.expr.BinaryExpr;
import com.github.javaparser.ast.expr.BooleanLiteralExpr;
import com.github.javaparser.ast.expr.ConditionalExpr;
import com.github.javaparser.ast.expr.EnclosedExpr;
import com.github.javaparser.ast.expr.Expression;
import com.github.javaparser.ast.expr.FieldAccessExpr;
import com.github.javaparser.ast.expr.IntegerLiteralExpr;
import com.github.javaparser.ast.expr.MarkerAnnotationExpr;
import com.github.javaparser.ast.expr.MethodCallExpr;
import com.github.javaparser.ast.expr.NameExpr;
import com.github.javaparser.ast.expr.NullLiteralExpr;
import com.github.javaparser.ast.expr.ObjectCreationExpr;
import com.github.javaparser.ast.expr.StringLiteralExpr;
import com.github.javaparser.ast.expr.ThisExpr;
import com.github.javaparser.ast.expr.UnaryExpr;
import com.github.javaparser.ast.expr.VariableDeclarationExpr;
import com.github.javaparser.ast.stmt.BlockStmt;
import com.github.javaparser.ast.stmt.CatchClause;
import com.github.javaparser.ast.stmt.ExpressionStmt;
import com.github.javaparser.ast.stmt.ForEachStmt;
import com.github.javaparser.ast.stmt.ForStmt;
import com.github.javaparser.ast.stmt.IfStmt;
import com.github.javaparser.ast.stmt.ReturnStmt;
import com.github.javaparser.ast.stmt.Statement;
import com.github.javaparser.ast.stmt.ThrowStmt;
import com.github.javaparser.ast.stmt.TryStmt;
import com.github.javaparser.ast.type.ClassOrInterfaceType;
import com.github.javaparser.ast.type.Type;

import constants.Constant;

/**
 * An element of the core asset for test features divided in three four sections:
 * a general one and three specific others according to the three main feature groups
 * @author forest
 *
 */
public class TestConfigUtil {

	private static final String INITIALIZATION_CONSTRUCTOR_WITH_2_PARAMETERS = "Initialization constructor with 2 parameters";
	private static final String INITIALIZATION_CONSTRUCTOR_WITH_1_PARAMETERS = "Initialization constructor with 1 parameters";
	private static final String TEST_INI_CONSTRUCTOR02_PARAM = "testIniConstructor_02_Param";
	private static final String TEST_INI_CONSTRUCTOR01_PARAM = "testIniConstructor_01_Param";

	private static final String AT_DISPLAY_NAME = "DisplayName";
	private static final String AT_TEST = "Test";

	private static final String EQUALS_IS_TESTED_WITH_NULL = "equals is tested with null";
	private static final String EQUALS_NULL = "equalsNull";
	public static final String INITIALIZATION_CONSTRUCTOR_WITH_3_PARAMETERS = "Initialization constructor with 3 parameters without date of birth";
	public static final String TEST_INI_CONSTRUCTOR03_PARAM = "testIniConstructor_03_ParamNoDateOfBirth";

	/**
	 * Contains core asset elements to be reused in the development of the PizzaVO feature line 
	 * @author forest
	 *
	 */
	public static class PizzaUtil {

		static Properties prop = PropertiesUtil.readPropertiesFile("resources/pizza-tests.properties");

		public static List<FieldDeclaration> addTestAttributes(ClassOrInterfaceDeclaration coid, String clazzName) {
			String[] fields = new String[] { prop.getProperty("fieldName1"), prop.getProperty("fieldName2"),
					prop.getProperty("fieldName3"), prop.getProperty("fieldName4") };
			return TestConfigUtil.addTestAttributes(coid, clazzName, fields);
		}

		public static void add1stOptionPizzaMethod(ClassOrInterfaceDeclaration coid, String clazzName) {

			MethodDeclaration method = buildSignature(coid, AT_TEST, AT_DISPLAY_NAME,
					INITIALIZATION_CONSTRUCTOR_WITH_1_PARAMETERS, TEST_INI_CONSTRUCTOR01_PARAM);

			Statement stmt1 = getStmt(Constant.STRING, prop.getProperty("name"), prop.getProperty("name_value_bbb"));

			NodeList<Expression> arguments = new NodeList<>();
			arguments.add(new NameExpr(prop.getProperty("name")));

			ObjectCreationExpr target = new ObjectCreationExpr().setType(new ClassOrInterfaceType().setName(clazzName))
					.setArguments(arguments);

			Statement stmt2 = getStmt(clazzName, prop.getProperty("fieldName1"), target);

			Statement stmt3 = assertEqualsStmt(prop.getProperty("name"),
					getMethdExpr(prop.getProperty("fieldName1"), prop.getProperty("get_name")));

			method.getBody().get().addStatement(stmt1).addStatement(stmt2).addStatement(stmt3);
		}

		public static void add2ndOptionPizzaMethod(ClassOrInterfaceDeclaration coid, String clazzName) {

			MethodDeclaration node = buildSignature(coid, AT_TEST, AT_DISPLAY_NAME,
					INITIALIZATION_CONSTRUCTOR_WITH_2_PARAMETERS, TEST_INI_CONSTRUCTOR02_PARAM);

			Statement expr1 = getStmt(Constant.STRING, prop.getProperty("name"), prop.getProperty("name_value_bbb"));

			NodeList<Expression> args1 = addArgs(new StringLiteralExpr(prop.getProperty("tomato")),
					new StringLiteralExpr(prop.getProperty("kaese")),
					new StringLiteralExpr(prop.getProperty("basilikum")));

			Statement expr2 = getStmt(Constant.STRING_ARRAYS_CLASS, prop.getProperty("ingredients"),
					getArrayInitialization(args1));

			NodeList<Expression> arguments = new NodeList<>();
			arguments.add(new NameExpr(prop.getProperty("name")));
			arguments.add(new NameExpr(prop.getProperty("ingredients")));
			ObjectCreationExpr target = new ObjectCreationExpr().setType(new ClassOrInterfaceType().setName(clazzName))
					.setArguments(arguments);

			Statement expr4 = getStmt(clazzName, prop.getProperty("fieldName1"), target);

			Statement expr5 = assertEqualsStmt(prop.getProperty("name"),
					getMethdExpr(prop.getProperty("fieldName1"), prop.getProperty("get_name")));// fieldName1, GET_NAME
//					
			Statement expr6 = assertEqualsStmt(prop.getProperty("ingredients"),
					getMethdExpr(prop.getProperty("fieldName1"), prop.getProperty("get_ingredients"))); // fieldName1,
																										// GET_PRICE

			node.getBody().get().addStatement(expr1).addStatement(expr2).addStatement(expr4).addStatement(expr5)
					.addStatement(expr6);
		}

		public static void fillMethodInitEach(ClassOrInterfaceDeclaration coid, String javaFileName) {

			String methName = "initEach";

			MethodDeclaration method = getMethodByName(coid, methName);

			Expression target1 = new NameExpr(prop.getProperty("fieldName1"));

			NodeList<Expression> args1 = addArgs(new StringLiteralExpr(prop.getProperty("tomato")),
					new StringLiteralExpr(prop.getProperty("kaese")),
					new StringLiteralExpr(prop.getProperty("basilikum")));

			NodeList<Expression> arguments1 = addArgs(new StringLiteralExpr(prop.getProperty("marghrita")),
					getArrayCreation(Constant.STRING, args1), prop.getProperty("float_value_8_dot_0"));

			Expression value1 = objectCreation(javaFileName, arguments1);

			Expression target2 = new NameExpr(prop.getProperty("fieldName2"));
			NodeList<Expression> args2 = addArgs(new StringLiteralExpr(prop.getProperty("tomato")),
					new StringLiteralExpr(prop.getProperty("kaese")),
					new StringLiteralExpr(prop.getProperty("thunFisch")));

			NodeList<Expression> arguments2 = addArgs(new StringLiteralExpr(prop.getProperty("tonno")),
					getArrayCreation(Constant.STRING, args2), prop.getProperty("value"));
			Expression value2 = objectCreation(javaFileName, arguments2);

			Expression target3 = new NameExpr(prop.getProperty("fieldName3"));

			NodeList<Expression> arguments3 = addArgs(
					new NameExpr(getMethdExpr(prop.getProperty("fieldName1"), prop.getProperty("get_name")).toString()),
					new NameExpr(getMethdExpr(prop.getProperty("fieldName1"), prop.getProperty("get_ingredients"))
							.toString()),
					new NameExpr(
							getMethdExpr(prop.getProperty("fieldName1"), prop.getProperty("get_price")).toString()));

			Expression value3 = objectCreation(javaFileName, arguments3);

			Expression target4 = new NameExpr(prop.getProperty("fieldName3"));
			NodeList<Expression> arguments4 = addArgs(
					new NameExpr(getMethdExpr(prop.getProperty("fieldName1"), prop.getProperty("get_name")).toString()),
					new NameExpr(getMethdExpr(prop.getProperty("fieldName1"), prop.getProperty("get_ingredients"))
							.toString()),
					new NameExpr(
							getMethdExpr(prop.getProperty("fieldName1"), prop.getProperty("get_price")).toString()));

			Expression value4 = objectCreation(javaFileName, arguments4);

			method.getBody().get().getStatements().add(getStmt(target1, value1));
			method.getBody().get().getStatements().add(getStmt(target2, value2));
			method.getBody().get().getStatements().add(getStmt(target3, value3));
			method.getBody().get().getStatements().add(getStmt(target4, value4));
		}

		public static void addMethodCloneTest(ClassOrInterfaceDeclaration coid, String clazzName) {

			String pizzaClone = "pizzaClone";
			String displyValue = "Clone is tested with equals, i.e. the equals tests should be correct.";
			String callClone = "clone";
			String methodName = "cloneTest";

			MethodDeclaration method = buildSignature(coid, AT_TEST, AT_DISPLAY_NAME, displyValue, methodName);

			Statement stmt1 = new ExpressionStmt(
					new VariableDeclarationExpr(getVar(new ClassOrInterfaceType().setName(clazzName), pizzaClone)));

			Statement stmt2 = getStmt(pizzaClone, getMethdExpr(prop.getProperty("fieldName1"), callClone));

			BinaryExpr condition = getBinaryExpr(prop.getProperty("fieldName1"), pizzaClone,
					com.github.javaparser.ast.expr.BinaryExpr.Operator.NOT_EQUALS);
			Statement stmt3 = new ExpressionStmt(callAssert(Constant.ASSERT_TRUE, condition));

			NodeList<Expression> args = new NodeList<>();
			args.addFirst(new NameExpr(pizzaClone));
			MethodCallExpr condition3 = getMethodCallExpr(new NameExpr(prop.getProperty("fieldName1")),
					Constant.EQUALS_METH, args);
			Statement stmt4 = new ExpressionStmt(callAssert(Constant.ASSERT_TRUE, condition3));

			method.getBody().get().addStatement(stmt1);
			method.getBody().get().addStatement(stmt2);
			method.getBody().get().addStatement(stmt3);
			method.getBody().get().addStatement(stmt4);

		}

		public static void addMethodEqualsNull(ClassOrInterfaceDeclaration coid, String clazzName) {

			TestConfigUtil.addMethodEqualsNull(coid, clazzName, prop.getProperty("fieldName2"));
		}

		public static void addEquals2EqualObjects(ClassOrInterfaceDeclaration coid, String clazzName) {
			TestConfigUtil.addEquals2EqualObjects(coid, clazzName, prop.getProperty("fieldName3"),
					prop.getProperty("fieldName2"));

		}

		public static void addEquals2IdenticalObjects(ClassOrInterfaceDeclaration coid, String clazzName) {
			TestConfigUtil.addEquals2IdenticalObjects(coid, clazzName, prop.getProperty("fieldName3"));
		}

		public static void addEquals3EqualObjects(ClassOrInterfaceDeclaration coid, String clazzName) {
			TestConfigUtil.addEquals3EqualObjects(coid, clazzName, prop.getProperty("fieldName2"),
					prop.getProperty("fieldName3"), prop.getProperty("fieldName4"));
		}

		public static void addEqualsDifferentObjects(ClassOrInterfaceDeclaration coid, String clazzName) {

			TestConfigUtil.addEqualsDifferentObjects(coid, clazzName, prop.getProperty("set_name"),
					prop.getProperty("fieldName4"), prop.getProperty("fieldName1"));
		}

		public static void addEqualsDifferentObjectsDifferentClasses(ClassOrInterfaceDeclaration coid,
				String clazzName) {

			TestConfigUtil.addEqualsDifferentObjectsDifferentClasses(coid, clazzName, prop.getProperty("fieldName4"));
		}

		public static void addEqualsDefaultConstructors(ClassOrInterfaceDeclaration coid, String clazzName) {
			String displayValue = "equals is tested with 2 objects created by default constructor.";
			String methodName = "equalsDefaultConstructors";

			List<String> varPool = new ArrayList<String>();
			varPool.add(prop.getProperty("default_var1"));
			varPool.add(prop.getProperty("default_var2"));

			MethodDeclaration method = buildSignature(coid, AT_TEST, AT_DISPLAY_NAME, displayValue, methodName);

			Expression target = new NameExpr(prop.getProperty("default_var1"));
			Expression value = new ObjectCreationExpr().setType(clazzName);

			VariableDeclarationExpr declaratorExpr = getVarDeclarationExpr(clazzName, varPool);

			Statement stmt1 = new ExpressionStmt(declaratorExpr);
			Statement stmt2 = getAssignExpr(target, value);
			Statement stmt3 = getAssignExpr(new NameExpr(prop.getProperty("default_var2")), value);
			Statement stmt4 = new ExpressionStmt(
					callAssert(Constant.ASSERT_TRUE, getMethodCallExpr(new NameExpr(prop.getProperty("default_var1")),
							Constant.EQUALS_METH, new NodeList<>(new NameExpr(prop.getProperty("default_var2"))))));

			method.getBody().get().addStatement(stmt1);
			method.getBody().get().addStatement(stmt2);
			method.getBody().get().addStatement(stmt3);
			method.getBody().get().addStatement(stmt4);
		}

		public static void addEqualsIniAndDefaultConstructors(ClassOrInterfaceDeclaration coid, String clazzName) {
			String displayValue = "equals is tested with other object created by initalizing construct and this object created by default construct and.";
			String methodName = "equalsIniAndDefaultConstructors";

			List<String> varPool = new ArrayList<String>();
			varPool.add(prop.getProperty("ini_var"));
			varPool.add(prop.getProperty("default_var2"));

			MethodDeclaration method = buildSignature(coid, AT_TEST, AT_DISPLAY_NAME, displayValue, methodName);

			Expression value = new ObjectCreationExpr().setType(clazzName);

			NodeList<Expression> args1 = addArgs(new StringLiteralExpr(prop.getProperty("tomato")),
					new StringLiteralExpr(prop.getProperty("kaese")),
					new StringLiteralExpr(prop.getProperty("basilikum")));
			NodeList<Expression> arguments1 = addArgs(new StringLiteralExpr(prop.getProperty("marghrita")),
					getArrayCreation(Constant.STRING, args1), prop.getProperty("float_value_8_dot_0"));

			VariableDeclarationExpr declaratorExpr = getVarDeclarationExpr(clazzName, varPool);

			Statement stmt1 = new ExpressionStmt(declaratorExpr);
			Statement stmt2 = getAssignExpr(new NameExpr(prop.getProperty("ini_var")),
					objectCreation(clazzName, arguments1));
			Statement stmt3 = getAssignExpr(new NameExpr(prop.getProperty("default_var2")), value);
			Statement stmt4 = new ExpressionStmt(
					callAssert(Constant.ASSERT_FALSE, getMethodCallExpr(new NameExpr(prop.getProperty("ini_var")),
							Constant.EQUALS_METH, new NodeList<>(new NameExpr(prop.getProperty("default_var2"))))));

			method.getBody().get().addStatement(stmt1);
			method.getBody().get().addStatement(stmt2);
			method.getBody().get().addStatement(stmt3);
			method.getBody().get().addStatement(stmt4);

		}

		public static void addEqualsOtherNameNull(ClassOrInterfaceDeclaration coid, String clazzName) {

			String displayValue = "equals is tested with this name and other other name is null.";
			String methodName = "equalsOtherNameNull";

			List<String> varPool = new ArrayList<String>();
			varPool.add(prop.getProperty("default_var1"));
			varPool.add(prop.getProperty("other_var"));

			MethodDeclaration method = buildSignature(coid, AT_TEST, AT_DISPLAY_NAME, displayValue, methodName);

			NodeList<Expression> args1 = addArgs(new StringLiteralExpr(prop.getProperty("tomato")),
					new StringLiteralExpr(prop.getProperty("kaese")),
					new StringLiteralExpr(prop.getProperty("basilikum")));
			NodeList<Expression> arguments1 = addArgs(new StringLiteralExpr(prop.getProperty("marghrita")),
					getArrayCreation(Constant.STRING, args1), prop.getProperty("float_value_8_dot_0"));

			VariableDeclarationExpr declaratorExpr = getVarDeclarationExpr(clazzName, varPool);

			Statement stmt1 = new ExpressionStmt(declaratorExpr);
			Statement stmt2 = getAssignExpr(new NameExpr(prop.getProperty("ini_var")),
					objectCreation(clazzName, arguments1));
			arguments1 = addArgs(new NullLiteralExpr(), getArrayCreation(Constant.STRING, args1),
					prop.getProperty("float_value_8_dot_0"));
			Statement stmt3 = getAssignExpr(new NameExpr(prop.getProperty("other_var")),
					objectCreation(clazzName, arguments1));
			Statement stmt4 = new ExpressionStmt(
					callAssert(Constant.ASSERT_FALSE, getMethodCallExpr(new NameExpr(prop.getProperty("ini_var")),
							Constant.EQUALS_METH, new NodeList<>(new NameExpr(prop.getProperty("other_var"))))));

			method.getBody().get().addStatement(stmt1);
			method.getBody().get().addStatement(stmt2);
			method.getBody().get().addStatement(stmt3);
			method.getBody().get().addStatement(stmt4);

		}

		public static void addEqualsThisNameNull(ClassOrInterfaceDeclaration coid, String clazzName) {

			String displayValue = "equals is tested with this name is null and other  name.";
			String methodName = "equalsThisNameNull";

			String failMessage = "equals is tested with this name is null and other not. Should not throw a NullPointerException";
			String callFail = "fail";

			List<String> varPool = new ArrayList<String>();
			varPool.add(prop.getProperty("ini_var"));
			varPool.add(prop.getProperty("other_var"));

			MethodDeclaration method = buildSignature(coid, AT_TEST, AT_DISPLAY_NAME, displayValue, methodName);

			NodeList<Expression> args1 = addArgs(new StringLiteralExpr(prop.getProperty("tomato")),
					new StringLiteralExpr(prop.getProperty("kaese")),
					new StringLiteralExpr(prop.getProperty("basilikum")));
			NodeList<Expression> arguments1 = addArgs(new NullLiteralExpr(), getArrayCreation(Constant.STRING, args1),
					prop.getProperty("float_value_8_dot_0"));

			VariableDeclarationExpr declaratorExpr = getVarDeclarationExpr(clazzName, varPool);

			Statement stmt1 = new ExpressionStmt(declaratorExpr);
			Statement stmt2 = getAssignExpr(new NameExpr(prop.getProperty("ini_var")),
					objectCreation(clazzName, arguments1));
			arguments1 = addArgs(new StringLiteralExpr(prop.getProperty("marghrita")),
					getArrayCreation(Constant.STRING, args1), prop.getProperty("float_value_8_dot_0"));
			Statement stmt3 = getAssignExpr(new NameExpr(prop.getProperty("other_var")),
					objectCreation(clazzName, arguments1));

			NodeList<Statement> statements = new NodeList<>();

			MethodCallExpr condition = getMethodCallExpr(new NameExpr(prop.getProperty("ini_var")),
					Constant.EQUALS_METH, new NodeList<>(new NameExpr(prop.getProperty("other_var"))));
			statements.add(new ExpressionStmt(callAssert(Constant.ASSERT_FALSE, condition)));
			BlockStmt tryBlock = new BlockStmt().setStatements(statements);

			NodeList<CatchClause> catchClauses = new NodeList<>();
			Parameter parameter = new Parameter(new ClassOrInterfaceType().setName(Constant.NULL_POINTER_EXCEPTION),
					Constant.EXCEPTION_VAR);

			BlockStmt body = new BlockStmt()
					.addStatement(new MethodCallExpr(callFail, new StringLiteralExpr(failMessage)));
			CatchClause catchClauseNode = new CatchClause(parameter, body);
			catchClauses.add(catchClauseNode);

			Statement stmt4 = new TryStmt().setTryBlock(tryBlock).setCatchClauses(catchClauses);

			method.getBody().get().addStatement(stmt1);
			method.getBody().get().addStatement(stmt2);
			method.getBody().get().addStatement(stmt3);
			method.getBody().get().addStatement(stmt4);

		}

		public static void addEqualsOtherPrice0(ClassOrInterfaceDeclaration coid, String clazzName) {

			String displayValue = "equals is tested with this price and other price is 0.";
			String methodName = "equalsOtherPrice0";

			List<String> varPool = new ArrayList<String>();
			varPool.add(prop.getProperty("ini_var"));
			varPool.add(prop.getProperty("other_var"));

			MethodDeclaration method = buildSignature(coid, AT_TEST, AT_DISPLAY_NAME, displayValue, methodName);

			NodeList<Expression> args1 = addArgs(new StringLiteralExpr(prop.getProperty("tomato")),
					new StringLiteralExpr(prop.getProperty("kaese")),
					new StringLiteralExpr(prop.getProperty("basilikum")));
			NodeList<Expression> arguments1 = addArgs(new StringLiteralExpr(prop.getProperty("marghrita")),
					getArrayCreation(Constant.STRING, args1), prop.getProperty("float_value_8_dot_0"));

			VariableDeclarationExpr declaratorExpr = getVarDeclarationExpr(clazzName, varPool);

			Statement stmt1 = new ExpressionStmt(declaratorExpr);
			Statement stmt2 = getAssignExpr(new NameExpr(prop.getProperty("ini_var")),
					objectCreation(clazzName, arguments1));

			arguments1 = addArgs(new StringLiteralExpr(prop.getProperty("marghrita")),
					getArrayCreation(Constant.STRING, args1), prop.getProperty("float_value_dot_0"));
			Statement stmt3 = getAssignExpr(new NameExpr(prop.getProperty("other_var")),
					objectCreation(clazzName, arguments1));

			Statement stmt4 = new ExpressionStmt(
					callAssert(Constant.ASSERT_FALSE, getMethodCallExpr(new NameExpr(prop.getProperty("ini_var")),
							Constant.EQUALS_METH, new NodeList<>(new NameExpr(prop.getProperty("other_var"))))));

			method.getBody().get().addStatement(stmt1);
			method.getBody().get().addStatement(stmt2);
			method.getBody().get().addStatement(stmt3);
			method.getBody().get().addStatement(stmt4);

		}

		public static void addEualsThisPrice0(ClassOrInterfaceDeclaration coid, String clazzName) {

			String displayValue = "equals is tested with this price is  and other price.";
			String methodName = "equalsThisPrice0";

			List<String> varPool = new ArrayList<String>();
			varPool.add(prop.getProperty("ini_var"));
			varPool.add(prop.getProperty("other_var"));

			MethodDeclaration method = buildSignature(coid, AT_TEST, AT_DISPLAY_NAME, displayValue, methodName);

			NodeList<Expression> args1 = addArgs(new StringLiteralExpr(prop.getProperty("tomato")),
					new StringLiteralExpr(prop.getProperty("kaese")),
					new StringLiteralExpr(prop.getProperty("basilikum")));
			NodeList<Expression> arguments1 = addArgs(new StringLiteralExpr(prop.getProperty("marghrita")),
					getArrayCreation(Constant.STRING, args1), prop.getProperty("float_value_dot_0"));

			VariableDeclarationExpr declaratorExpr = getVarDeclarationExpr(clazzName, varPool);

			Statement stmt1 = new ExpressionStmt(declaratorExpr);
			Statement stmt2 = getAssignExpr(new NameExpr(prop.getProperty("ini_var")),
					objectCreation(clazzName, arguments1));

			arguments1 = addArgs(new StringLiteralExpr(prop.getProperty("marghrita")),
					getArrayCreation(Constant.STRING, args1), prop.getProperty("float_value_8_dot_0"));
			Statement stmt3 = getAssignExpr(new NameExpr(prop.getProperty("other_var")),
					objectCreation(clazzName, arguments1));

			Statement stmt4 = new ExpressionStmt(
					callAssert(Constant.ASSERT_FALSE, getMethodCallExpr(new NameExpr(prop.getProperty("ini_var")),
							Constant.EQUALS_METH, new NodeList<>(new NameExpr(prop.getProperty("other_var"))))));

			method.getBody().get().addStatement(stmt1);
			method.getBody().get().addStatement(stmt2);
			method.getBody().get().addStatement(stmt3);
			method.getBody().get().addStatement(stmt4);

		}

		public static void addTestPizzaVOEqualsHashCode(ClassOrInterfaceDeclaration coid, String clazzName) {

			String methodName = "testPizzaVOEqualsHashCode";
			TestConfigUtil.addEqualsHashCode(coid, clazzName, methodName, prop.getProperty("fieldName2"),
					prop.getProperty("fieldName3"));
		}

		public static void addToStringTest(ClassOrInterfaceDeclaration coid, String clazzName) {
			toStringTest(coid, clazzName);
		}

		public static void toString_02_Option(ClassOrInterfaceDeclaration coid, String clazzName) {
			
			coid.getMembers().remove(getMethodByName(coid, "toStringTest"));
			
			String methodName = "toStringTest";
			String message = "Doesn't contains ";
			String displayValue = "Test toString: Contains two attributes";
			
			Statement stmt0 = initializeVar(Constant.FLOAT, prop.getProperty("price"), prop.getProperty("float_value_13_dot_95"));

			Statement stmt1 = initializeVar(Constant.STRING, prop.getProperty("name"), prop.getProperty("name_value_bbb"));

			MethodDeclaration method = buildSignature(coid, AT_TEST, AT_DISPLAY_NAME, displayValue, methodName);

//			Statement stmt2 = initializeArray();
			
			Statement stmt3 = createIntance(clazzName);

			Statement stmt4 = setName();
			Statement stmt6 = setPrice();

//			Statement stmt5 = setIngredients();

			Statement stmt7 = initializeLocalVarWihToStringCall(); //
			Statement stmt8 = assertContains(message+" "+prop.getProperty("name"), prop.getProperty("name"));
			Statement stmt = priceAssertion(message);

//			Statement stmt9 = iterateArray(message);
			
			method.getBody().get().addStatement(stmt0);
			method.getBody().get().addStatement(stmt1);
//			method.getBody().get().addStatement(stmt2);
			method.getBody().get().addStatement(stmt3);
			method.getBody().get().addStatement(stmt4);
//			method.getBody().get().addStatement(stmt5);
			method.getBody().get().addStatement(stmt6);
			method.getBody().get().addStatement(stmt7);
			method.getBody().get().addStatement(stmt8);
//			method.getBody().get().addStatement(stmt9);
			method.getBody().get().addStatement(stmt);
		}

		public static void toString_01_Option(ClassOrInterfaceDeclaration coid, String clazzName) {

			coid.getMembers().remove(getMethodByName(coid, "toStringTest"));
			
			String methodName = "toStringTest";
			String message = "Doesn't contains ";
			String displayValue = "Test toString: Contains one attribute";
			
			Statement stmt1 = initializeVar(Constant.STRING, prop.getProperty("name"), prop.getProperty("name_value_bbb"));

			MethodDeclaration method = buildSignature(coid, AT_TEST, AT_DISPLAY_NAME, displayValue, methodName);

			Statement stmt4 = setName();
			Statement stmt7 = initializeLocalVarWihToStringCall();
			Statement stmt8 = assertContains(message+" "+prop.getProperty("name"), prop.getProperty("name"));

			method.getBody().get().addStatement(stmt1);
			method.getBody().get().addStatement(stmt4);
			method.getBody().get().addStatement(stmt7);
			method.getBody().get().addStatement(stmt8);	
		}

		private static void toStringTest(ClassOrInterfaceDeclaration coid, 
				String clazzName) {

			String methodName = "toStringTest";
			String message = "Doesn't contains ";
			String displayValue = "Test toString: Contains all attributes";
			
			Statement stmt0 = initializeVar(Constant.FLOAT, prop.getProperty("price"), prop.getProperty("float_value_13_dot_95"));
			Statement stmt1 = initializeVar(Constant.STRING, prop.getProperty("name"), prop.getProperty("name_value_bbb"));

			MethodDeclaration method = buildSignature(coid, AT_TEST, AT_DISPLAY_NAME, displayValue, methodName);


			Statement stmt2 = initializeArray();
			
			Statement stmt3 = createIntance(clazzName);

			Statement stmt4 = setName();

			Statement stmt5 = setIngredients();

			Statement stmt6 = setPrice();

			Statement stmt7 = initializeLocalVarWihToStringCall(); //

			Statement stmt8 = assertContains(message+" "+prop.getProperty("name"), prop.getProperty("name"));
			
			Statement stmt9 = iterateArray(message);

			Statement stmt = priceAssertion(message);

			method.getBody().get().addStatement(stmt0);
			method.getBody().get().addStatement(stmt1);
			method.getBody().get().addStatement(stmt2);
			method.getBody().get().addStatement(stmt3);
			method.getBody().get().addStatement(stmt4);
			method.getBody().get().addStatement(stmt5);
			method.getBody().get().addStatement(stmt6);
			method.getBody().get().addStatement(stmt7);
			method.getBody().get().addStatement(stmt8);
			method.getBody().get().addStatement(stmt9);
			method.getBody().get().addStatement(stmt);
		}

		private static Statement priceAssertion(String message) {
			Expression condition = getMethodCallExpr(
					new NameExpr(prop.getProperty("actual_string")), 
					Constant.CONTAINS,
					new NodeList<>(
							getMethodCallExpr(
									new NameExpr(Constant.STRING), 
									Constant.VALUE_OF,
									new NodeList<>(new NameExpr(prop.getProperty("price"))))));

			Statement stmt = 
					new ExpressionStmt(
							callAssert(
									Constant.ASSERT_TRUE, 
									condition,
									new StringLiteralExpr(message + prop.getProperty("price") + " : "), 
									new NameExpr(prop.getProperty("price"))));
			return stmt;
		}

		private static Statement iterateArray(String message) {
			
			VariableDeclarationExpr variable = new VariableDeclarationExpr(
					new ClassOrInterfaceType().setName(Constant.STRING), prop.getProperty("for_var_name"));
			
			Expression iterable = new NameExpr(prop.getProperty("ingredients"));

			BlockStmt body = new BlockStmt(
					new NodeList<>(
							assertContains(message+" "+prop.getProperty("ingredients"), prop.getProperty("for_var_name"))));

			Statement stmt9 = new ForEachStmt(variable, iterable, body);
			return stmt9;
		}

		private static ExpressionStmt assertContains(String message, String attribute) {
			return new ExpressionStmt(
					callAssert(
							Constant.ASSERT_TRUE,
							getMethodCallExpr(
									new NameExpr(prop.getProperty("actual_string")), 
									Constant.CONTAINS, 
									new NodeList<>(new NameExpr(attribute))),
							new StringLiteralExpr(message +" : "),
							new NameExpr(attribute)));
		}

		private static Statement initializeLocalVarWihToStringCall() {
			
			VariableDeclarator v = new VariableDeclarator().setName(prop.getProperty("actual_string")).setType(Constant.STRING)
					.setInitializer(getMethdExpr(prop.getProperty("local_var"), Constant.TO_STRING));
			
			Statement stmt7 = new ExpressionStmt(new VariableDeclarationExpr(v));
			return stmt7;
		}

		private static Statement setPrice() {
			
			Statement stmt6 = new ExpressionStmt(
					getMethodCallExpr(
							new NameExpr(prop.getProperty("local_var")), 
							prop.getProperty("set_price"),
							new NodeList<>(new NameExpr(prop.getProperty("price")))));
			return stmt6;
		}

		private static Statement setIngredients() {
			
			Statement stmt5 = new ExpressionStmt(
					getMethodCallExpr(
							new NameExpr(prop.getProperty("local_var")), 
							prop.getProperty("set_ingredients"),
							new NodeList<>(new NameExpr(prop.getProperty("ingredients")))));
			return stmt5;
		}

		private static Statement setName() {
			
			Statement stmt4 = new ExpressionStmt(
					getMethodCallExpr(
							new NameExpr(prop.getProperty("local_var")), 
							prop.getProperty("set_name"),
							new NodeList<>(new NameExpr(prop.getProperty("name")))));
			return stmt4;
		}

		private static Statement createIntance(String clazzName) {
			
			VariableDeclarator varDcl3 = 
						new VariableDeclarator()
						.setType(clazzName)
						.setName(prop.getProperty("local_var"));
			
			Expression value3 = objectCreation(clazzName, new NodeList<>());

			
			Statement stmt3 = getAssignExpr(new VariableDeclarationExpr(varDcl3), value3);
			return stmt3;
		}

		private static Statement initializeArray() {
			
			VariableDeclarator varDcl =
								new VariableDeclarator()
								.setType(Constant.STRING_ARRAYS_CLASS)
								.setName(prop.getProperty("ingredients"));
			
			Expression value = new ArrayInitializerExpr(
					addArgs(
							prop.getProperty("tomato"), 
							prop.getProperty("kaese"),
							prop.getProperty("basilikum"), 
							prop.getProperty("pfeffer")));
			
			return getAssignExpr(new VariableDeclarationExpr(varDcl), value);
		}

		private static ExpressionStmt initializeVar(String type, String name, String initialize) {
			return getAssignExpr(
					new VariableDeclarationExpr(new ClassOrInterfaceType().setName(type), name),
					new NameExpr(initialize));
		}
		
		public static void addToStringIgredientsNull(ClassOrInterfaceDeclaration coid, String clazzName) {

			String methodName = "toStringIgredientsNull";
			String displayValue = "Test toString with this ingredients is null";
			String valueName = "BBB";
			String fieldNameIngredients = "ingredients";
			String fieldNamePrice = "price";

			String localVar = "pizza";

			MethodDeclaration method = buildSignature(coid, AT_TEST, AT_DISPLAY_NAME, displayValue, methodName);
			Map<String, Expression> varMap = new HashMap<>();

			varMap.put(prop.getProperty("name"), new StringLiteralExpr(valueName));

			Statement stmt0 = getAssignExpr(
					new VariableDeclarationExpr(new ClassOrInterfaceType().setName(Constant.FLOAT), fieldNamePrice),
					new NameExpr(prop.getProperty("float_value_13_dot_95")));
			Statement stmt1 = new ExpressionStmt(getVarDeclarationExpr(clazzName, Constant.STRING, varMap));

			VariableDeclarator varDcl = new VariableDeclarator().setType(Constant.STRING_ARRAYS_CLASS)
					.setName(fieldNameIngredients);
			Statement stmt2 = getAssignExpr(new VariableDeclarationExpr(varDcl), new NullLiteralExpr());

			VariableDeclarator varDcl3 = new VariableDeclarator().setType(clazzName).setName(localVar);
			Expression value3 = objectCreation(clazzName, new NodeList<>());
			Statement stmt3 = getAssignExpr(new VariableDeclarationExpr(varDcl3), value3);

			Statement stmt4 = new ExpressionStmt(getMethodCallExpr(new NameExpr(localVar), prop.getProperty("set_name"),
					new NodeList<>(new NameExpr(prop.getProperty("name")))));
			Statement stmt5 = new ExpressionStmt(getMethodCallExpr(new NameExpr(localVar), prop.getProperty("set_name"),
					new NodeList<>(new NameExpr(fieldNameIngredients))));
			Statement stmt6 = new ExpressionStmt(getMethodCallExpr(new NameExpr(localVar), prop.getProperty("set_name"),
					new NodeList<>(new NameExpr(fieldNamePrice))));

			String localVar2 = "actualString";
			String supplier = "Doesn't contains ";

			Statement syso = new ExpressionStmt(getMethodCallExpr(new FieldAccessExpr(new NameExpr("System"), "out"),
					"println", new NodeList<>(new NameExpr(fieldNamePrice))));

			VariableDeclarator v = new VariableDeclarator().setName(localVar2).setType(Constant.STRING)
					.setInitializer(getMethdExpr(localVar, Constant.TO_STRING));
			Statement stmt7 = new ExpressionStmt(new VariableDeclarationExpr(v)); //

			Statement stmt8 = new ExpressionStmt(callAssert(Constant.ASSERT_TRUE,
					getMethodCallExpr(new NameExpr(localVar2), Constant.CONTAINS,
							new NodeList<>(new NameExpr(prop.getProperty("name")))),
					new StringLiteralExpr(supplier + fieldNameIngredients + ": "),
					new NameExpr(prop.getProperty("name"))));

			Statement stmt9 = new ExpressionStmt(callAssert(Constant.ASSERT_TRUE,
					getMethodCallExpr(new NameExpr(localVar2), Constant.CONTAINS,
							new NodeList<>(new StringLiteralExpr(new NullLiteralExpr().toString()))),
					new StringLiteralExpr(supplier + "null for " + fieldNameIngredients)));

			Expression condition = getMethodCallExpr(new NameExpr(localVar2), Constant.CONTAINS,
					new NodeList<>(getMethodCallExpr(new NameExpr(Constant.STRING), Constant.VALUE_OF,
							new NodeList<>(new NameExpr(fieldNamePrice)))));
			Statement stmt = new ExpressionStmt(callAssert(Constant.ASSERT_TRUE, condition,
					new StringLiteralExpr(supplier + fieldNamePrice + ": "), new NameExpr(fieldNamePrice)));

			method.getBody().get().addStatement(stmt0);
			method.getBody().get().addStatement(stmt1);
			method.getBody().get().addStatement(stmt2);
			method.getBody().get().addStatement(stmt3);
			method.getBody().get().addStatement(stmt4);
			method.getBody().get().addStatement(stmt5);
			method.getBody().get().addStatement(stmt6);
			method.getBody().get().addStatement(stmt7);
			method.getBody().get().addStatement(syso);
			method.getBody().get().addStatement(stmt8);
			method.getBody().get().addStatement(stmt9);
			method.getBody().get().addStatement(stmt);
		}

	}

	/**
	 * Contains core asset elements to be reused in the development of the ChefVO feature line 
	 * @author forest
	 *
	 */
	public static class ChefUtil {

		static Properties prop = PropertiesUtil.readPropertiesFile("resources/chef-tests.properties");

		public static void addFirstOptionMethod(ClassOrInterfaceDeclaration coid, String clazzName) {
			TestConfigUtil.addFirstOptionMethod(coid, clazzName, prop);
		}

		public static void addSecondOptionMethod(ClassOrInterfaceDeclaration coid, String clazzName) {
			
			Map<String, String> variables = new HashMap<>();
			variables.put(prop.getProperty("last_name"), prop.getProperty("last_name_value"));
			variables.put(prop.getProperty("first_name"), prop.getProperty("first_name_value"));

			Map<String, String> asserts = new HashMap<>();
			asserts.put(prop.getProperty("last_name"), prop.getProperty("get_last_name"));
			asserts.put(prop.getProperty("first_name"), prop.getProperty("get_first_name"));

			TestConfigUtil.addSecondOptionMethod(coid, clazzName, INITIALIZATION_CONSTRUCTOR_WITH_2_PARAMETERS,
					TEST_INI_CONSTRUCTOR02_PARAM, variables, asserts, prop);
		}

		public static List<FieldDeclaration> addTestAttributes(ClassOrInterfaceDeclaration coid, String clazzName) {
			
			String[] fields = new String[] {
//					prop.getProperty("field_name_x"),
					prop.getProperty("field_name_y"), prop.getProperty("field_name_z") };
			
			return TestConfigUtil.addTestAttributes(coid, clazzName, fields);
		}

		public static void fillMethodInitEach(ClassOrInterfaceDeclaration coid, String clazzName) {

			String methName = "initEach";

			MethodDeclaration method = coid.getMethodsByName(methName).stream().findFirst().get();

			Statement stmt0 = getAssignExpr(new NameExpr(prop.getProperty("field_name_x")),
					objectCreation(clazzName,
							new NodeList<>(new StringLiteralExpr(prop.getProperty("nach_name")),
									new StringLiteralExpr(prop.getProperty("vor_name")),
									new NameExpr(prop.getProperty("color_white")))));

			method.getBody().get().getStatements().add(stmt0);

			ObjectCreationExpr objectCreation = objectCreation(clazzName,
					new NodeList<>(getMethdExpr(prop.getProperty("field_name_x"), prop.getProperty("get_last_name")),
							getMethdExpr(prop.getProperty("field_name_x"), prop.getProperty("get_first_name")),
							getMethdExpr(prop.getProperty("field_name_x"), prop.getProperty("get_color_apron"))));
			ExpressionStmt stmt1 = getStmt(new NameExpr(prop.getProperty("field_name_y")), objectCreation);
			ExpressionStmt stmt2 = getStmt(new NameExpr(prop.getProperty("field_name_z")), objectCreation);

			method.getBody().get().getStatements().add(stmt1);
			method.getBody().get().getStatements().add(stmt2);

		}

		public static void addMethodEqualsNull(ClassOrInterfaceDeclaration coid, String clazzName) {
			TestConfigUtil.addMethodEqualsNull(coid, clazzName, prop.getProperty("field_name_x"));
		}

		public static void addEqualsDefaultConstructors(ClassOrInterfaceDeclaration coid, String clazzName) {

			String failMessage = "Cannot invoke equals because one attribute is null. Should not throw a NullPointerException";
			String callFail = "fail";

			String displayValue = "equals is tested with 2 objects created by default constructor.";
			String methodName = "equalsDefaultConstructors";

			List<String> varPool = new ArrayList<String>();
			varPool.add(prop.getProperty("default_var1"));
			varPool.add(prop.getProperty("default_var2"));

			MethodDeclaration method = buildSignature(coid, AT_TEST, AT_DISPLAY_NAME, displayValue, methodName);

			Expression target = new NameExpr(prop.getProperty("default_var1"));
			Expression value = new ObjectCreationExpr().setType(clazzName);

			VariableDeclarationExpr declaratorExpr = getVarDeclarationExpr(clazzName, varPool);

			Statement stmt1 = new ExpressionStmt(declaratorExpr);
			Statement stmt2 = getAssignExpr(target, value);
			Statement stmt3 = getAssignExpr(new NameExpr(prop.getProperty("default_var2")), value);

			Statement stmt4 = new ExpressionStmt(
					callAssert(Constant.ASSERT_TRUE, getMethodCallExpr(new NameExpr(prop.getProperty("default_var1")),
							Constant.EQUALS_METH, new NodeList<>(new NameExpr(prop.getProperty("default_var2"))))));

			NodeList<Statement> statements = new NodeList<>();

//			MethodCallExpr condition = getMethodCallExpr(new NameExpr(""), EQUALS,
//					new NodeList<>(new NullLiteralExpr()));
			statements.add(stmt4);
			BlockStmt tryBlock = new BlockStmt().setStatements(statements);

			NodeList<CatchClause> catchClauses = new NodeList<>();
			Parameter parameter = new Parameter(new ClassOrInterfaceType().setName(Constant.NULL_POINTER_EXCEPTION),
					Constant.EXCEPTION_VAR);

			BlockStmt body = new BlockStmt()
					.addStatement(new MethodCallExpr(callFail, new StringLiteralExpr(failMessage)));
			CatchClause catchClauseNode = new CatchClause(parameter, body);
			catchClauses.add(catchClauseNode);

			Statement statement = new TryStmt().setTryBlock(tryBlock).setCatchClauses(catchClauses);

			method.getBody().get().addStatement(stmt1);
			method.getBody().get().addStatement(stmt2);
			method.getBody().get().addStatement(stmt3);
			method.getBody().get().addStatement(statement);

		}

		public static void addEqualsIniAndDefaultConstructors(ClassOrInterfaceDeclaration coid, String clazzName) {
			
			List<String> varPool = new ArrayList<String>();
			varPool.add(prop.getProperty("ini_var"));
			varPool.add(prop.getProperty("default_var2"));

			Expression value = new ObjectCreationExpr().setType(clazzName);

			NodeList<Expression> args1 = addArgs(new StringLiteralExpr(prop.getProperty("nach_name")),
					new StringLiteralExpr(prop.getProperty("vor_name")), new NameExpr(prop.getProperty("color_white")));

			VariableDeclarationExpr declaratorExpr = getVarDeclarationExpr(clazzName, varPool);

			Statement stmt1 = new ExpressionStmt(declaratorExpr);

			String displayValue = "equals is tested with other object created by initalizing construct and this object created by default construct and.";
			String methodName = "equalsIniAndDefaultConstructors";

			MethodDeclaration method = buildSignature(coid, AT_TEST, AT_DISPLAY_NAME, displayValue, methodName);

			Statement stmt2 = getAssignExpr(new NameExpr(prop.getProperty("ini_var")),
					objectCreation(clazzName, args1));
			Statement stmt3 = getAssignExpr(new NameExpr(prop.getProperty("default_var2")), value);
			Statement stmt4 = new ExpressionStmt(
					callAssert(Constant.ASSERT_FALSE, getMethodCallExpr(new NameExpr(prop.getProperty("ini_var")),
							Constant.EQUALS_METH, new NodeList<>(new NameExpr(prop.getProperty("default_var2"))))));

			method.getBody().get().addStatement(stmt1);
			method.getBody().get().addStatement(stmt2);
			method.getBody().get().addStatement(stmt3);
			method.getBody().get().addStatement(stmt4);

		}

		public static void addEquals2EqualObjects(ClassOrInterfaceDeclaration coid, String clazzName) {
			TestConfigUtil.addEquals2EqualObjects(coid, clazzName, prop.getProperty("field_name_y"),
					prop.getProperty("field_name_x"));

		}

		public static void addEquals2IdenticalObjects(ClassOrInterfaceDeclaration coid, String clazzName) {
			TestConfigUtil.addEquals2IdenticalObjects(coid, clazzName, prop.getProperty("field_name_y"));

		}

		public static void addEquals3EqualObjects(ClassOrInterfaceDeclaration coid, String clazzName) {
			TestConfigUtil.addEquals3EqualObjects(coid, clazzName, prop.getProperty("field_name_x"),
					prop.getProperty("field_name_y"), prop.getProperty("field_name_z"));

		}

		public static void addEqualsDifferentObjects(ClassOrInterfaceDeclaration coid, String clazzName) {
			TestConfigUtil.addEqualsDifferentObjects(coid, clazzName, "setLastName", prop.getProperty("field_name_z"),
					prop.getProperty("field_name_x"));

		}

		public static void addEquals2IdenticalObjectsNoColor(ClassOrInterfaceDeclaration coid, String clazzName) {

			String localVar = "chef";
			String displayValue = "equals is tested with  identical objects, but no color of apron. ";
			String methodName = "equals2IdenticalObjectsNoColor";
			MethodDeclaration method = buildSignature(coid, AT_TEST, AT_DISPLAY_NAME, displayValue, methodName);

			Expression target = new VariableDeclarationExpr(
					new VariableDeclarator(new ClassOrInterfaceType().setName(clazzName), localVar));
			Expression value = setAttributes(clazzName, new StringLiteralExpr(prop.getProperty("nach_name")),
					new StringLiteralExpr(prop.getProperty("vor_name")), new NullLiteralExpr());
			Statement stmt1 = getAssignExpr(target, value);

			Statement stmt2 = new ExpressionStmt(callAssert(Constant.ASSERT_TRUE, getMethodCallExpr(
					new NameExpr(localVar), Constant.EQUALS_METH, new NodeList<>(new NameExpr(localVar)))));

			method.getBody().get().addStatement(stmt1);
			method.getBody().get().addStatement(stmt2);
		}

		public static void addEqualsOtherNoLastname(ClassOrInterfaceDeclaration coid, String clazzName) {

			String localVar1 = "chef1";
			String localVar2 = "chef2";
			String key = "color_cyan";

			TestConfigUtil.addEqualsOtherNoLastname(coid, clazzName, prop, localVar1, localVar2, key);

		}

		public static void addEqualsThisNoLastname(ClassOrInterfaceDeclaration coid, String clazzName) {
			String localVar1 = "chef1";
			String localVar2 = "chef2";
			String key = "color_cyan";

			TestConfigUtil.addEqualsThisNoLastname(coid, clazzName, prop, localVar1, localVar2, key);
		}

		public static void addEqualsOtherNoFirstname(ClassOrInterfaceDeclaration coid, String clazzName) {

			String localVar1 = "chef1";
			String localVar2 = "chef2";
			String key = "color_cyan";

			TestConfigUtil.addEqualsOtherNoFirstname(coid, clazzName, prop, localVar1, localVar2, key);

		}

		public static void addEqualsThisNoFirstname(ClassOrInterfaceDeclaration coid, String clazzName) {
			
			String localVar1 = "chef1";
			String localVar2 = "chef2";
			String key = "color_cyan";

			TestConfigUtil.addEqualsThisNoFirstname(coid, clazzName, prop, localVar1, localVar2, key);

		}

		public static void addEqualsOtherNoColor(ClassOrInterfaceDeclaration coid, String clazzName) {
			
			String localVar1 = "chef1";
			String localVar2 = "chef2";
			String displayValue = "equals is tested with other's color of apron is null. ";
			String key = "color_cyan";
			String methodName = "equalsOtherNoColor";

			TestConfigUtil.equalsOtherNoParam(coid, clazzName, displayValue, methodName, prop, localVar1, localVar2,
					key);

		}

		public static void addEqualsThisNoColor(ClassOrInterfaceDeclaration coid, String clazzName) {
			
			String localVar1 = "chef1";
			String localVar2 = "chef2";
			String displayValue = "equals is tested with this color of apron is null. ";
			String methodName = "equalsThisNoColor";
			String key = "color_cyan";
			String failMessage = "equals is tested with this color of apron  is null and other not. Should not throw a NullPointerException";

			TestConfigUtil.equalsThisNoParam(coid, clazzName, displayValue, methodName, prop, localVar1, localVar2, key,
					failMessage);
		}

		public static void addEqualsDifferentObjectsDifferentClasses(ClassOrInterfaceDeclaration coid,
				String clazzName) {
			TestConfigUtil.addEqualsDifferentObjectsDifferentClasses(coid, clazzName, prop.getProperty("field_name_z"));

		}

		public static void addHashCodeTest(ClassOrInterfaceDeclaration coid, String clazzName) {
			
			String methodName = "hashCodeTest";
			TestConfigUtil.addEqualsHashCode(
					coid, 
					clazzName, 
					methodName, 
					prop.getProperty("field_name_x"),
					prop.getProperty("field_name_y"));

		}

		public static void addToStringTest(ClassOrInterfaceDeclaration coid, String clazzName) {
			
			String displayValue = "Test toString: Contains all attribute";
			Map<String, Expression> varMap = new HashMap<>();
			varMap.put(prop.getProperty("last_name"), new StringLiteralExpr(prop.getProperty("last_name_value")));
			varMap.put(prop.getProperty("first_name"), new StringLiteralExpr(prop.getProperty("first_name_value")));
			
			Expression[] arguments = {
					new NameExpr(prop.getProperty("last_name")),
					new NameExpr(prop.getProperty("first_name")), 
					new NameExpr(prop.getProperty("color_white"))
			};
			
			String[] assertExpr = {
					prop.getProperty("last_name"),
					prop.getProperty("first_name")
			};
			
			toStringTest(displayValue, coid, clazzName, varMap, assertExpr, arguments);
		}

		public static void toString2ndOption(ClassOrInterfaceDeclaration coid, String clazzName) {

			String displayValue = "Test toString: Contains two attributes";
			
			coid.getMembers().remove(getMethodByName(coid, "toStringTest"));
			
			Map<String, Expression> varMap = new HashMap<>();
			varMap.put(prop.getProperty("last_name"), new StringLiteralExpr(prop.getProperty("last_name_value")));
			varMap.put(prop.getProperty("first_name"), new StringLiteralExpr(prop.getProperty("first_name_value")));
			
			Expression[] arguments = {
					new NameExpr(prop.getProperty("last_name")),
					new NameExpr(prop.getProperty("first_name")), 
//					new NameExpr(prop.getProperty("color_white"))
			};
			
			String[] assertExpr = {
					prop.getProperty("last_name"),
					prop.getProperty("first_name")
			};
			
			toStringTest(displayValue, coid, clazzName, varMap, assertExpr, arguments);
		}

		public static void toString1stOption(ClassOrInterfaceDeclaration coid, String clazzName) {
			
			String displayValue = "Test toString: Contains one attribute";
			coid.getMembers().remove(getMethodByName(coid, "toStringTest"));
			
			Map<String, Expression> varMap = new HashMap<>();
			varMap.put(prop.getProperty("last_name"), new StringLiteralExpr(prop.getProperty("last_name_value")));
//			varMap.put(prop.getProperty("first_name"), new StringLiteralExpr(prop.getProperty("first_name_value")));
			
			Expression[] arguments = {
					new NameExpr(prop.getProperty("last_name")),
//					new NameExpr(prop.getProperty("first_name")), 
//					new NameExpr(prop.getProperty("color_white"))
			};
			
			String[] assertExpr = {
					prop.getProperty("last_name"),
//					prop.getProperty("first_name")
			};
			
			toStringTest(displayValue, coid, clazzName, varMap, assertExpr, arguments);
			
		}
		
		private static void toStringTest(String displayValue, ClassOrInterfaceDeclaration coid, String clazzName
				,Map<String, Expression> varMap, String[] assertExpr, Expression... arguments) {

			List<Statement> statements = new ArrayList<Statement>();
//			String displayValue = "Test toString: Contains all attributes";
			String methodName = "toStringTest";
			String localVar2 = "actualString";
			String localVar = "chef";

			MethodDeclaration method = buildSignature(coid, AT_TEST, AT_DISPLAY_NAME, displayValue, methodName);
			
			Statement stmt1 = new ExpressionStmt(getVarDeclarationExpr(clazzName, Constant.STRING, varMap));

			statements.add(stmt1);
			
			Expression target = new VariableDeclarationExpr(
					TestConfigUtil.getVar(new ClassOrInterfaceType().setName(clazzName), localVar));
			Expression value = setAttributes(clazzName, arguments);

			Statement stmt2 = getAssignExpr(target, value);
			
			statements.add(stmt2);

			VariableDeclarator v = new VariableDeclarator().setName(localVar2).setType(Constant.STRING)
					.setInitializer(getMethdExpr(localVar, Constant.TO_STRING));
			Statement stmt3 = new ExpressionStmt(new VariableDeclarationExpr(v)); //
			
			statements.add(stmt3);

			Stream.of(assertExpr).forEach(a->{
				Expression condition4 = getMethodCallExpr(
						new NameExpr(localVar2), 
						Constant.CONTAINS,
						new NodeList<>(new NodeList<>(new NameExpr(a))));
				
				Statement stmt4 = new ExpressionStmt(callAssert(Constant.ASSERT_TRUE, condition4));
				statements.add(stmt4);
			});
		
			statements.forEach(
					s->method.getBody()
					.get()
					.addStatement(s));
			
		}

	}

	/**
	 * Contains core asset elements to be reused in the development of the CustomerVO feature line 
	 * @author forest
	 *
	 */
	public static class CustomerUtil {

		private static final com.github.javaparser.ast.expr.BinaryExpr.Operator PLUS = com.github.javaparser.ast.expr.BinaryExpr.Operator.PLUS;
		private static final String METHOD = "Method";
		private static final String LENGTH = "length";
		private static final String FIELD = "Field";
		private static final String GET_DECLARED_FIELDS = "getDeclaredFields";
		private static final String FIELD_ARRAY = "Field[]";
		private static final String METHOD_ARRAY = "Method[]";
		private static final String CLASS = "class";

		static Properties prop = PropertiesUtil.readPropertiesFile("resources/customer-tests.properties");

		public static void addFirstOptionMethod(ClassOrInterfaceDeclaration coid, String clazzName) {
			TestConfigUtil.addFirstOptionMethod(coid, clazzName, prop);
		}

		public static void addSecondOptionMethod(ClassOrInterfaceDeclaration coid, String clazzName) {

			Map<String, String> variables = new HashMap<>();
			variables.put(prop.getProperty("last_name"), prop.getProperty("last_name_value"));
			variables.put(prop.getProperty("first_name"), prop.getProperty("first_name_value"));

			Map<String, String> asserts = new HashMap<>();
			asserts.put(prop.getProperty("last_name"), prop.getProperty("get_last_name"));
			asserts.put(prop.getProperty("first_name"), prop.getProperty("get_first_name"));

			TestConfigUtil.addSecondOptionMethod(coid, clazzName, INITIALIZATION_CONSTRUCTOR_WITH_2_PARAMETERS,
					TEST_INI_CONSTRUCTOR02_PARAM, variables, asserts, prop);
		}

		public static void addThirdOptionMethod(ClassOrInterfaceDeclaration coid, String clazzName) {

			Map<String, String> variables = new HashMap<>();
			variables.put(prop.getProperty("last_name"), prop.getProperty("last_name_value"));
			variables.put(prop.getProperty("first_name"), prop.getProperty("first_name_value"));
			variables.put(prop.getProperty("gender"), prop.getProperty("gender_value"));

			Map<String, String> asserts = new HashMap<>();
			asserts.put(prop.getProperty("last_name"), prop.getProperty("get_last_name"));
			asserts.put(prop.getProperty("first_name"), prop.getProperty("get_first_name"));
			asserts.put(prop.getProperty("gender"), prop.getProperty("get_gender"));

			TestConfigUtil.addSecondOptionMethod(coid, clazzName, INITIALIZATION_CONSTRUCTOR_WITH_3_PARAMETERS,
					TEST_INI_CONSTRUCTOR03_PARAM, variables, asserts, prop);

		}

		public static void addTestAttributes(ClassOrInterfaceDeclaration coid, String clazzName) {
			
			String[] fields = new String[] { 
					prop.getProperty("field_default"), 
					prop.getProperty("field_iniOnce"),
					prop.getProperty("field_y"), prop.getProperty("field_z") };
			
			TestConfigUtil.addTestAttributes(coid, clazzName, fields);

		}

		public static void addInitOnce(ClassOrInterfaceDeclaration coid, String clazzName) {
			
			String methodName = "initOnce";
			String atBeforeAll = "BeforeAll";
			MethodDeclaration method = buildAddSignature(coid, atBeforeAll, methodName);

			Statement stmt1 = getStmt(prop.getProperty("field_class"),
					new FieldAccessExpr(new NameExpr(clazzName), CLASS));

			NodeList<Expression> arguments = addArgs(new StringLiteralExpr(prop.getProperty("nach_name")),
					new StringLiteralExpr(prop.getProperty("vor_name")), new StringLiteralExpr(prop.getProperty("h")),
					new NameExpr(prop.getProperty("dob")));

			Statement stmt2 = getAssignExpr(new NameExpr(prop.getProperty("field_iniOnce")),
					objectCreation(clazzName, arguments));

			method.getBody().get().getStatements().add(stmt1);
			method.getBody().get().getStatements().add(stmt2);
			MethodDeclaration node = coid.getMethodsByName("initEach").get(0);

			coid.getMembers().remove(method);
			coid.tryAddImportToParentCompilationUnit(BeforeAll.class);
			coid.getMembers().addBefore(method, node);
		}

		public static void fillMethodInitEach(ClassOrInterfaceDeclaration coid, String clazzName) {
			
			String fieldName = getFirstFieldElement(coid);

			String methName = "initEach";
			MethodDeclaration method = TestConfigUtil.getMethodByName(coid, methName);

			String msg = "NullPointerException when calling default constructor. Maybe method calculateAge doesn't check for dateOfBirth to be null.";
			NodeList<Statement> statements = new NodeList<>();
			NodeList<Expression> arguments = new NodeList<>();
			arguments.add(new StringLiteralExpr(msg));

			statements.add(getAssignExpr(new NameExpr(prop.getProperty("field_default")),
					objectCreation(clazzName, new NodeList<Expression>())));
			BlockStmt tryBlock = new BlockStmt().setStatements(statements);

			NodeList<CatchClause> catchClauses = new NodeList<>();
			Parameter parameter = new Parameter(new ClassOrInterfaceType().setName(Constant.NULL_POINTER_EXCEPTION),
					Constant.EXCEPTION_VAR);

			BlockStmt body = new BlockStmt()
					.addStatement(new ThrowStmt(objectCreation(Constant.NULL_POINTER_EXCEPTION, arguments)));
			CatchClause catchClauseNode = new CatchClause(parameter, body);
			catchClauses.add(catchClauseNode);

			Statement tryCatchStmt = new TryStmt().setTryBlock(tryBlock).setCatchClauses(catchClauses);

			Statement stmtX = getAssignExpr(new NameExpr(fieldName),
					objectCreation(clazzName, addArgs(new StringLiteralExpr(prop.getProperty("nach_name")),
							new StringLiteralExpr(prop.getProperty("vor_name")),
							new StringLiteralExpr(prop.getProperty("h")), new NameExpr(prop.getProperty("dob")))));

			Statement stmtY = getAssignExpr(new NameExpr(prop.getProperty("field_y")),
					objectCreation(clazzName,
							addArgs(getMethdExpr(fieldName, prop.getProperty("get_last_name")),
									getMethdExpr(fieldName, prop.getProperty("get_first_name")),
									getMethdExpr(fieldName, prop.getProperty("get_gender")),
									getMethdExpr(fieldName, prop.getProperty("get_date_of_birth")))));

			Statement stmtZ = getAssignExpr(new NameExpr(prop.getProperty("field_z")),
					objectCreation(clazzName,
							addArgs(getMethdExpr(fieldName, prop.getProperty("get_last_name")),
									getMethdExpr(fieldName, prop.getProperty("get_first_name")),
									getMethdExpr(fieldName, prop.getProperty("get_gender")),
									getMethdExpr(fieldName, prop.getProperty("get_date_of_birth")))));

			method.getBody().get().getStatements().add(tryCatchStmt);
			method.getBody().get().getStatements().add(stmtX);
			method.getBody().get().getStatements().add(stmtY);

			method.getBody().get().getStatements().add(stmtZ);

		}

		public static void test6Attributes(ClassOrInterfaceDeclaration coid, String clazzName) {
			
			MethodDeclaration afterThis = getMethodByName(coid, "test4Attributes");
			String methodName = "test6Attributes";
			String displyValue = "Class has 6 instance attributes";
			MethodDeclaration method = buildSignature(coid, AT_TEST, AT_DISPLAY_NAME, displyValue, methodName);

			Statement stmt1 = getAssignExpr(new NameExpr(prop.getProperty("field_class")),
					new FieldAccessExpr(new NameExpr(clazzName), CLASS));

			Statement stmt2 = getAssignExpr(
					new VariableDeclarationExpr(new VariableDeclarator(new ClassOrInterfaceType().setName(FIELD_ARRAY),
							prop.getProperty("local_var_attr"))),
					getMethdExpr(prop.getProperty("field_class"), GET_DECLARED_FIELDS));

			Statement assertEqual = assertEqualsStmt(new IntegerLiteralExpr("6"),
					new FieldAccessExpr(new NameExpr(prop.getProperty("local_var_attr")), LENGTH));

			method.getBody().get().getStatements().add(stmt1);
			method.getBody().get().getStatements().add(stmt2);
			method.getBody().get().getStatements().add(assertEqual);

			coid.getMembers().remove(method);
			coid.getMembers().addAfter(method, afterThis);
			coid.getMembers().remove(afterThis);
		}
		
		public static void test7Attributes(ClassOrInterfaceDeclaration coid, String clazzName) {
			
			MethodDeclaration method_6 = coid.getMethodsByName("test6Attributes").get(0);
			String methodName = "test7Attributes";
			String displyValue = "Class has 7 instance attributes";
			MethodDeclaration method = buildSignature(coid, AT_TEST, AT_DISPLAY_NAME, displyValue, methodName);
			
			Statement stmt1 = getAssignExpr(new NameExpr(prop.getProperty("field_class")),
					new FieldAccessExpr(new NameExpr(clazzName), CLASS));
			
			Statement stmt2 = getAssignExpr(
					new VariableDeclarationExpr(new VariableDeclarator(new ClassOrInterfaceType().setName(FIELD_ARRAY),
							prop.getProperty("local_var_attr"))),
					getMethdExpr(prop.getProperty("field_class"), GET_DECLARED_FIELDS));
			
			Statement assertEqual = assertEqualsStmt(new IntegerLiteralExpr("7"),
					new FieldAccessExpr(new NameExpr(prop.getProperty("local_var_attr")), LENGTH));
			
			method.getBody().get().getStatements().add(stmt1);
			method.getBody().get().getStatements().add(stmt2);
			method.getBody().get().getStatements().add(assertEqual);
			
			coid.getMembers().remove(method);
			coid.getMembers().addAfter(method, method_6);
			coid.getMembers().remove(method_6);
		}

		public static void testShortCalculateAge(ClassOrInterfaceDeclaration coid, String clazzName) {

			String methodName = "testShortCalculateAge";
			String displyValue = "calculateAge return data type is short";
			String local_var_return = "returnsShort";
			String assertEqual_msg = " calculateAge should return short";
			String compareSignature = "public short de.thb.dim.pizzaPronto.CustomerVO.calculateAge()";

			testSpecificAttr(coid, clazzName, methodName, displyValue, local_var_return, assertEqual_msg,
					compareSignature);

		}

		public static void testCustomerVOnoAttributeAge(ClassOrInterfaceDeclaration coid, String clazzName) {

			String methodName = "testCustomerVOnoAttributeAge";
			String displyValue = "No attribute for age, since is derived. ";
			String local_var_return = "attributeAge";
			String forVariableName = "actual";
			String array_attr = "fields";

			MethodDeclaration method = buildSignature(coid, AT_TEST, AT_DISPLAY_NAME, displyValue, methodName);

			Statement stmt1 = getAssignExpr(
					new VariableDeclarationExpr(new VariableDeclarator(new ClassOrInterfaceType().setName(FIELD_ARRAY),
							prop.getProperty("local_var_attr"))),
					getMethdExpr(prop.getProperty("field_class"), GET_DECLARED_FIELDS));

			Statement stmt2 = getAssignExpr(
					new VariableDeclarationExpr(new VariableDeclarator(
							new ClassOrInterfaceType().setName(Constant.BOOLEAN_SIMPLE_NAME), local_var_return)),
					new BooleanLiteralExpr(false));

			VariableDeclarationExpr variable = new VariableDeclarationExpr(new ClassOrInterfaceType().setName(FIELD),
					forVariableName);
			Expression iterable = new NameExpr(array_attr);

			String value = "private short de.thb.dim.pizzaPronto.CustomerVO.age";
			Expression condition = getMethodCallExpr(getMethdExpr(forVariableName, Constant.TO_STRING),
					Constant.EQUALS_METH, new NodeList<>(new StringLiteralExpr(value)));

			BlockStmt body = new BlockStmt(new NodeList<>(new IfStmt().setCondition(condition)
					.setThenStmt(getAssignExpr(new NameExpr(local_var_return), new BooleanLiteralExpr(true)))));

			Statement stmt3 = new ForEachStmt(variable, iterable, body);

			String assertEqual_msg = " field age";
			Statement assertEqual = assertEqualsStmt(new BooleanLiteralExpr(false), new NameExpr(local_var_return),
					getMethdExpr(prop.getProperty("field_default"), Constant.GET_CLASS),
					new StringLiteralExpr(assertEqual_msg));

			method.getBody().get().getStatements().add(stmt1);
			method.getBody().get().getStatements().add(stmt2);
			method.getBody().get().getStatements().add(stmt3);
			method.getBody().get().getStatements().add(assertEqual);
		}

		public static void testIdStart0(ClassOrInterfaceDeclaration coid, String clazzName) {
			
			String methodName = "testIdStart0";
			String displyValue = "id starts with 0.";

			MethodDeclaration method = buildSignature(coid, AT_TEST, AT_DISPLAY_NAME, displyValue, methodName);

			String assertEqual_msg = " should have the ID  0";
			Statement assertEqual = assertEqualsStmt(new IntegerLiteralExpr("0"),
					getMethdExpr(prop.getProperty("field_iniOnce"), "getId"),
					getMethdExpr(prop.getProperty("field_iniOnce"), Constant.GET_CLASS),
					new StringLiteralExpr(assertEqual_msg));

			method.getBody().get().getStatements().add(assertEqual);
		}

		public static void testIdofObjectNoChange(ClassOrInterfaceDeclaration coid, String clazzName) {

			String methodName = "testIdofObjectNoChange";
			String displyValue = "id is not changed when new customers are created and nextId is increased.";
			String nextId1 = "nextId1";
			String nextId2 = "nextId2";

			MethodDeclaration method = buildSignature(coid, AT_TEST, AT_DISPLAY_NAME, displyValue, methodName);

			List<String> varList = new ArrayList<String>();

			varList.add(nextId1);
			varList.add(nextId2);

			Statement stmt1 = new ExpressionStmt(getVarDeclarationExpr(Constant.INT_SIMPLE_NAME, varList));
			Statement stmt2 = getAssignExpr(new NameExpr(nextId1),
					getMethdExpr(clazzName, prop.getProperty("get_next_id")));

			String assertEqual_msg = " should have the ID  0";

			Statement assertEqual = assertEqualsStmt(new IntegerLiteralExpr("0"),
					getMethdExpr(prop.getProperty("field_iniOnce"), "getId"),
					getMethdExpr(prop.getProperty("field_iniOnce"), Constant.GET_CLASS),
					new StringLiteralExpr(assertEqual_msg));

			Statement stmt3 = new ExpressionStmt(objectCreation(clazzName, new NodeList<>()));
			Statement stmt4 = getAssignExpr(new NameExpr(nextId2),
					getMethdExpr(clazzName, prop.getProperty("get_next_id")));

			Statement assertTrueStmt = new ExpressionStmt(callAssert(Constant.ASSERT_TRUE,
					getBinaryExpr(nextId2, nextId1 + 1, com.github.javaparser.ast.expr.BinaryExpr.Operator.EQUALS)));

//			Statement assertEqual2 = assertEqualsStmt(
//					new IntegerLiteralExpr("0"), 
//					getMethdExpr(prop.getProperty("field_iniOnce"), "getId"), 
//					getBinaryExpr(getMethdExpr(
//							prop.getProperty("field_iniOnce"), 
//							Constant.GET_CLASS), new StringLiteralExpr(assertEqual_msg), 
//							com.github.javaparser.ast.expr.BinaryExpr.Operator.PLUS));

			method.getBody().get().getStatements().add(stmt1);
			method.getBody().get().getStatements().add(stmt2);
			method.getBody().get().getStatements().add(stmt3);
			method.getBody().get().getStatements().add(stmt4);
			method.getBody().get().getStatements().add(assertEqual);
			method.getBody().get().getStatements().add(assertTrueStmt);
			method.getBody().get().getStatements().add(assertEqual);
		}

		public static void testIdsIncreasing(ClassOrInterfaceDeclaration coid, String clazzName) {

			String methodName = "testIdsIncreasing";
			String displyValue = "id starts with 0 and increases correctly";
			String nextId1 = "nextId1";

			MethodDeclaration method = buildSignature(coid, AT_TEST, AT_DISPLAY_NAME, displyValue, methodName);

			Statement stmt1 = new ExpressionStmt(new VariableDeclarationExpr(
					getVar(new ClassOrInterfaceType().setName(Constant.INT_SIMPLE_NAME), "nextId1")));

			Statement stmt2 = new ExpressionStmt(
					new VariableDeclarationExpr(getVar(new ClassOrInterfaceType().setName(clazzName), "customerTest")));

			String index = "index";
			NodeList<Expression> initialization = new NodeList<>();
			initialization.add(getExprAssignment(
					new VariableDeclarationExpr(
							getVar(new ClassOrInterfaceType().setName(Constant.INT_SIMPLE_NAME), index)),
					new NameExpr(nextId1)));
			Expression compare = getBinaryExpr(new NameExpr(nextId1), new IntegerLiteralExpr(" 10"), PLUS);

			NodeList<Expression> update = new NodeList<>();

			update.add(new UnaryExpr(new NameExpr(index),
					com.github.javaparser.ast.expr.UnaryExpr.Operator.POSTFIX_INCREMENT));

			NodeList<Statement> statements = new NodeList<>();
			String assertEqual_msg = " should have the ID  0";

			Statement node1 = getAssignExpr(new NameExpr("customerTest"), objectCreation(clazzName, new NodeList<>()));

			Statement node2 = assertEqualsStmt(new NameExpr(index),
					getMethdExpr(prop.getProperty("field_iniOnce"), prop.getProperty("get_id")),
					getMethdExpr(prop.getProperty("field_iniOnce"), Constant.GET_CLASS),
					getBinaryExpr(new StringLiteralExpr(assertEqual_msg), new NameExpr(index), PLUS));

			statements.add(node1);
			statements.add(node2);
			BlockStmt body = new BlockStmt(statements);

			Statement stmt3 = new ForStmt(initialization, compare, update, body);

			Statement assertEqual = assertEqualsStmt(new IntegerLiteralExpr("0"),
					getMethdExpr(prop.getProperty("field_iniOnce"), "getId"),
					getMethdExpr(prop.getProperty("field_iniOnce"), Constant.GET_CLASS),
					new StringLiteralExpr(assertEqual_msg));

			method.getBody().get().getStatements().add(stmt1);
			method.getBody().get().getStatements().add(stmt2);
			method.getBody().get().getStatements().add(stmt3);
			method.getBody().get().getStatements().add(assertEqual);
		}

		public static void dobToStringPrivate(ClassOrInterfaceDeclaration coid, String clazzName) {

			String methodName = "dobToStringPrivate";
			String displyValue = "dobToString is private";
			String local_var_return = "returnsPrivate";
			String forVariableName = "actual";
			String array_attr = "methods";
			String get_declared_methods = "getDeclaredMethods";
			String assertEqual_msg = " dobToString should be private";

			MethodDeclaration method = buildSignature(coid, AT_TEST, AT_DISPLAY_NAME, displyValue, methodName);

			Statement stmt1 = getAssignExpr(
					new VariableDeclarationExpr(
							new VariableDeclarator(new ClassOrInterfaceType().setName(METHOD_ARRAY), array_attr)),
					getMethdExpr(prop.getProperty("field_class"), get_declared_methods));

			Statement stmt2 = getAssignExpr(
					new VariableDeclarationExpr(new VariableDeclarator(
							new ClassOrInterfaceType().setName(Constant.BOOLEAN_SIMPLE_NAME), local_var_return)),
					new BooleanLiteralExpr(false));

			VariableDeclarationExpr variable = new VariableDeclarationExpr(new ClassOrInterfaceType().setName(METHOD),
					forVariableName);
			Expression iterable = new NameExpr(array_attr);

			String value = "private java.lang.String de.thb.dim.pizzaPronto.CustomerVO.dobToString()";
			Expression condition = getMethodCallExpr(getMethdExpr(forVariableName, Constant.TO_STRING),
					Constant.EQUALS_METH, new NodeList<>(new StringLiteralExpr(value)));

			BlockStmt body = new BlockStmt(new NodeList<>(new IfStmt().setCondition(condition)
					.setThenStmt(getAssignExpr(new NameExpr(local_var_return), new BooleanLiteralExpr(true)))));

			Statement stmt3 = new ForEachStmt(variable, iterable, body);

			Statement assertEqual = assertEqualsStmt(new BooleanLiteralExpr(true), new NameExpr(local_var_return),
					getMethdExpr(prop.getProperty("field_default"), Constant.GET_CLASS),
					new StringLiteralExpr(assertEqual_msg));

			method.getBody().get().getStatements().add(stmt1);
			method.getBody().get().getStatements().add(stmt2);
			method.getBody().get().getStatements().add(stmt3);
			method.getBody().get().getStatements().add(assertEqual);
		}

		public static void calculateAgeDoBNull(ClassOrInterfaceDeclaration coid, String clazzName) {
			
			String methodName = "calculateAgeDoBNull";
			String displyValue = "Test calculateAge: date of birth is null, alter -1";
			MethodDeclaration method = buildSignature(coid, AT_TEST, AT_DISPLAY_NAME, displyValue, methodName);

			Statement stmt1 = new ExpressionStmt(getMethodCallExpr(new NameExpr(prop.getProperty("field_default")),
					"setDateOfBirth", new NodeList<>(new NullLiteralExpr())));

			String assertEqual_msg = "should have the age null";
			Statement assertEqual1 = assertEqualsStmt(new IntegerLiteralExpr("-1"),
					getMethdExpr(prop.getProperty("field_default"), "calculateAge"),
					getMethdExpr(prop.getProperty("field_default"), Constant.GET_CLASS),
					new StringLiteralExpr(assertEqual_msg));

			String msg = " date of birth should be set null ";
			Statement assertEqual2 = assertEqualsStmt(new NullLiteralExpr(),
					getMethdExpr(prop.getProperty("field_default"), "getDateOfBirth"),
					getMethdExpr(prop.getProperty("field_default"), Constant.GET_CLASS), new StringLiteralExpr(msg));

			method.getBody().get().getStatements().add(stmt1);
			method.getBody().get().getStatements().add(assertEqual1);
			method.getBody().get().getStatements().add(assertEqual2);
		}

		public static void calculateDoBFor16Years(ClassOrInterfaceDeclaration coid, String clazzName) {

			String methodName = "calculateDoBFor16Years";
			String displyValue = "Test calculateAge:  date of birth for 16 years old.";
			String x_year = "16";

			calculateDoBForX_Years(coid, clazzName, methodName, displyValue, x_year);

		}

		public static void calculateDoBFor18Years(ClassOrInterfaceDeclaration coid, String clazzName) {
			
			String methodName = "calculateDoBFor18Years";
			String displyValue = "Test calculateAge:  date of birth for 18 years old.";
			String x_year = "18";

			calculateDoB(coid, clazzName, methodName, displyValue, x_year);
		}

		public static void calculateDoBFor17Years(ClassOrInterfaceDeclaration coid, String clazzName) {

			String methodName = "calculateDoBFor17Years";
			String displyValue = "Test calculateAge:  date of birth for 18 years old minus 1 day.";

			String class_localDate = "LocalDate";
			String call_now = "now";
			String local_today = "today";
			String local_mydate = "myDate";
			String x_year = "18";

			MethodDeclaration method = buildSignature(coid, AT_TEST, AT_DISPLAY_NAME, displyValue, methodName);

			Statement stmtToday = getAssignExpr(
					new VariableDeclarationExpr(
							getVar(new ClassOrInterfaceType().setName(Constant.INT_SIMPLE_NAME), local_today)),
					getMethdExpr(class_localDate, call_now));

			Statement stmtMyDate = new ExpressionStmt(new VariableDeclarationExpr(
					getVar(new ClassOrInterfaceType().setName(Constant.INT_SIMPLE_NAME), local_mydate)));

			Statement stmtInit_myDate = getAssignExpr(new NameExpr(local_mydate), getMethodCallExpr(
					new NameExpr(local_today), "minusYears", new NodeList<>(new IntegerLiteralExpr(x_year))));

			NodeList<Expression> args = new NodeList<>();
			args.add(getMethodCallExpr(new NameExpr(local_mydate), "plusDays",
					new NodeList<>(new IntegerLiteralExpr("1"))));
			Statement stmtSetter = new ExpressionStmt(
					getMethodCallExpr(new NameExpr(prop.getProperty("field_default")), "setDateOfBirth", args));

			String assertEqual_msg = " should have the age of 1 day before the 18th birthday.";
			Statement assertEqual = assertEqualsStmt(new IntegerLiteralExpr("-1"),
					getMethdExpr(prop.getProperty("field_default"), "calculateAge"),
					getMethdExpr(prop.getProperty("field_default"), Constant.GET_CLASS),
					new StringLiteralExpr(assertEqual_msg));

			method.getBody().get().getStatements().add(stmtToday);
			method.getBody().get().getStatements().add(stmtMyDate);
			;
			method.getBody().get().getStatements().add(stmtInit_myDate);
			method.getBody().get().getStatements().add(stmtSetter);
			method.getBody().get().getStatements().add(assertEqual);

		}

		public static void calculateDoBFor60Years(ClassOrInterfaceDeclaration coid, String clazzName) {
			
			String methodName = "calculateDoBFor60Years";
			String displyValue = "Test calculateAge:  date of birth for 60 years old.";
			String x_year = "60";

			calculateDoB(coid, clazzName, methodName, displyValue, x_year);

		}

		public static void addMethodEqualsNull(ClassOrInterfaceDeclaration coid, String clazzName) {
			TestConfigUtil.addMethodEqualsNull(coid, clazzName, prop.getProperty("field_x"));

		}

		public static void addEqualsDefaultConstructors(ClassOrInterfaceDeclaration coid, String clazzName) {
			
			String displayValue = "equals is tested with 2 objects created by default constructor.";
			String methodName = "equalsDefaultConstructors";

			List<String> varPool = new ArrayList<String>();
			varPool.add(prop.getProperty("default_var1"));
			varPool.add(prop.getProperty("default_var2"));

			MethodDeclaration method = buildSignature(coid, AT_TEST, AT_DISPLAY_NAME, displayValue, methodName);

			Expression target = new NameExpr(prop.getProperty("default_var1"));
			Expression value = new ObjectCreationExpr().setType(clazzName);

			VariableDeclarationExpr declaratorExpr = getVarDeclarationExpr(clazzName, varPool);

			Statement stmt1 = new ExpressionStmt(declaratorExpr);
			Statement stmt2 = getAssignExpr(target, value);
			Statement stmt3 = getAssignExpr(new NameExpr(prop.getProperty("default_var2")), value);

			Statement stmt4 = new ExpressionStmt(
					callAssert(Constant.ASSERT_TRUE, getMethodCallExpr(new NameExpr(prop.getProperty("default_var1")),
							Constant.EQUALS_METH, new NodeList<>(new NameExpr(prop.getProperty("default_var2"))))));

			method.getBody().get().addStatement(stmt1);
			method.getBody().get().addStatement(stmt2);
			method.getBody().get().addStatement(stmt3);
			method.getBody().get().addStatement(stmt4);
		}

		public static void addEqualsIniAndDefaultConstructors(ClassOrInterfaceDeclaration coid, String clazzName) {

			String displayValue = "equals is tested with other object created by initalizing construct and this object created by default construct and.";
			String methodName = "equalsIniAndDefaultConstructors";

			MethodDeclaration method = buildSignature(coid, AT_TEST, AT_DISPLAY_NAME, displayValue, methodName);

			List<String> varPool = new ArrayList<String>();
			varPool.add(prop.getProperty("ini_var"));
			varPool.add(prop.getProperty("default_var2"));

			Expression value = objectCreation(clazzName, new NodeList<>());

			NodeList<Expression> args1 = addArgs(new StringLiteralExpr(prop.getProperty("nach_name")),
					new StringLiteralExpr(prop.getProperty("vor_name")), new StringLiteralExpr(prop.getProperty("h")),
					new NameExpr(prop.getProperty("dob")));

			VariableDeclarationExpr declaratorExpr = getVarDeclarationExpr(clazzName, varPool);

			Statement stmt1 = new ExpressionStmt(declaratorExpr);
			Statement stmt2 = getAssignExpr(new NameExpr(prop.getProperty("ini_var")),
					objectCreation(clazzName, args1));
			Statement stmt3 = getAssignExpr(new NameExpr(prop.getProperty("default_var2")), value);
			Statement stmt4 = new ExpressionStmt(
					callAssert(Constant.ASSERT_FALSE, getMethodCallExpr(new NameExpr(prop.getProperty("ini_var")),
							Constant.EQUALS_METH, new NodeList<>(new NameExpr(prop.getProperty("default_var2"))))));

			method.getBody().get().addStatement(stmt1);
			method.getBody().get().addStatement(stmt2);
			method.getBody().get().addStatement(stmt3);
			method.getBody().get().addStatement(stmt4);

		}

		public static void addEquals2EqualObjects(ClassOrInterfaceDeclaration coid, String clazzName) {
			
			TestConfigUtil.addEquals2EqualObjects(
					coid, 
					clazzName, 
					prop.getProperty("field_y"),
					prop.getProperty("field_x"));

		}

		public static void addEquals2IdenticalObjects(ClassOrInterfaceDeclaration coid, String clazzName) {
			TestConfigUtil.addEquals2IdenticalObjects(
					coid, 
					clazzName, 
					prop.getProperty("field_y"));
		}

		public static void addEquals3EqualObjects(ClassOrInterfaceDeclaration coid, String clazzName) {
			
			TestConfigUtil.addEquals3EqualObjects(
					coid, 
					clazzName, 
					prop.getProperty("field_x"),
					prop.getProperty("field_y"), 
					prop.getProperty("field_z"));
		}

		public static void addEqualsOtherNoLastname(ClassOrInterfaceDeclaration coid, String clazzName) {
			
			String localVar1 = "customer1";
			String localVar2 = "customer2";
			String key = "dob";

			TestConfigUtil.addEqualsOtherNoLastname(coid, clazzName, prop, localVar1, localVar2, key);
		}

		public static void addEqualsThisNoLastname(ClassOrInterfaceDeclaration coid, String clazzName) {
			
			String localVar1 = "customer1";
			String localVar2 = "customer2";
			String key = "dob";

			TestConfigUtil.addEqualsThisNoLastname(coid, clazzName, prop, localVar1, localVar2, key);
		}

		public static void addEqualsOtherNoFirstname(ClassOrInterfaceDeclaration coid, String clazzName) {
			
			String localVar1 = "customer1";
			String localVar2 = "customer2";
			String key = "dob";

			TestConfigUtil.addEqualsOtherNoFirstname(coid, clazzName, prop, localVar1, localVar2, key);

		}

		public static void addEqualsThisNoFirstname(ClassOrInterfaceDeclaration coid, String clazzName) {
			
			String localVar1 = "customer1";
			String localVar2 = "customer2";
			String key = "dob";

			TestConfigUtil.addEqualsThisNoFirstname(coid, clazzName, prop, localVar1, localVar2, key);

		}

		public static void addEqualsOtherNoDob(ClassOrInterfaceDeclaration coid, String clazzName) {
			
			String localVar1 = "customer1";
			String localVar2 = "customer2";
			String displayValue = "equals is tested with other's date of birth is null. ";
			String key = "dob";
			String methodName = "equalsOtherNoDob";

			TestConfigUtil.equalsOtherNoParam(coid, clazzName, displayValue, methodName, prop, localVar1, localVar2,
					key);

		}

		public static void addEqualsThisNoDob(ClassOrInterfaceDeclaration coid, String clazzName) {
			
			String localVar1 = "customer1";
			String localVar2 = "customer2";
			String displayValue = "equals is tested with this date of birth is null. ";
			String key = "dob";
			String methodName = "equalsThisNoDob";
			String failMessage = "equals is tested with this date of birth is null. Should not throw a NullPointerException";

			TestConfigUtil.equalsThisNoParam(coid, clazzName, displayValue, methodName, prop, localVar1, localVar2, key,
					failMessage);

		}

		public static void addEqualsDifferentObjects(ClassOrInterfaceDeclaration coid, String clazzName) {
			
			TestConfigUtil.addEqualsDifferentObjects(
					coid, 
					clazzName, 
					"setLastName", 
					prop.getProperty("field_z"),
					prop.getProperty("field_x"));

		}

		public static void addEqualsDifferentObjectsDifferentClasses(ClassOrInterfaceDeclaration coid,
				String clazzName) {
			
			TestConfigUtil.addEqualsDifferentObjectsDifferentClasses(
					coid, 
					clazzName, 
					prop.getProperty("field_z"));

		}

		public static void addHashCodeTest(ClassOrInterfaceDeclaration coid, String clazzName) {
			
			String methodName = "hashCodeTest";
			TestConfigUtil.addEqualsHashCode(
					coid, 
					clazzName, 
					methodName, 
					prop.getProperty("field_x"),
					prop.getProperty("field_y"));

		}

		public static List<Statement> addToStringTest(ClassOrInterfaceDeclaration coid, String clazzName) {
			
			String localVar2 = "actualString";
			String local_dateOfBirth = "dateOfBirth";
			Map<String, Expression> varMap = new HashMap<>();
			varMap.put(prop.getProperty("last_name"), new StringLiteralExpr(prop.getProperty("last_name_value")));
			varMap.put(prop.getProperty("first_name"), new StringLiteralExpr(prop.getProperty("first_name_value")));
			varMap.put(prop.getProperty("gender"), new StringLiteralExpr(prop.getProperty("gender_value")));
			
			NodeList<Expression> arguments = new NodeList<>();
			arguments.add(new NameExpr(prop.getProperty("last_name")));
			arguments.add(new NameExpr(prop.getProperty("first_name")));
			arguments.add(new NameExpr(prop.getProperty("gender")));
			arguments.add(new NameExpr(local_dateOfBirth));
			
			Expression[] conditions = {
					getMethodCallExpr(new NameExpr(localVar2), Constant.CONTAINS,
							new NodeList<>(new NodeList<>(new NameExpr(prop.getProperty("last_name"))))),

					getMethodCallExpr(new NameExpr(localVar2), Constant.CONTAINS,
							new NodeList<>(new NodeList<>(new NameExpr(prop.getProperty("first_name"))))),

					getMethodCallExpr(new NameExpr(localVar2), Constant.CONTAINS,
							new NodeList<>(new NodeList<>(new NameExpr(prop.getProperty("gender")))))
			};
			
			return toStringTest(coid, clazzName, varMap, arguments, conditions);
		}
		

		public static void toString03Option(ClassOrInterfaceDeclaration coid, String clazzName) {
			
			coid.getMembers().remove(getMethodByName(coid, "toStringTest"));
			
			String displayValue = "Test toString: Contains three(03) attributes";
			String methodName = "toStringTest";
			String localVar2 = "actualString";
			String localVar = "customer";
			String local_dateOfBirth = "dateOfBirth";

			MethodDeclaration method = buildSignature(coid, AT_TEST, AT_DISPLAY_NAME, displayValue, methodName);
			
			Map<String, Expression> varMap = new HashMap<>();
			varMap.put(prop.getProperty("last_name"), new StringLiteralExpr(prop.getProperty("last_name_value")));
			varMap.put(prop.getProperty("first_name"), new StringLiteralExpr(prop.getProperty("first_name_value")));
			varMap.put(prop.getProperty("gender"), new StringLiteralExpr(prop.getProperty("gender_value")));
			
			NodeList<Expression> arguments = new NodeList<>();
			arguments.add(new NameExpr(prop.getProperty("last_name")));
			arguments.add(new NameExpr(prop.getProperty("first_name")));
			arguments.add(new NameExpr(prop.getProperty("gender")));
			
			Expression[] conditions = {
					getMethodCallExpr(new NameExpr(localVar2), Constant.CONTAINS,
							new NodeList<>(new NodeList<>(new NameExpr(prop.getProperty("last_name"))))),

					getMethodCallExpr(new NameExpr(localVar2), Constant.CONTAINS,
							new NodeList<>(new NodeList<>(new NameExpr(prop.getProperty("first_name"))))),

					getMethodCallExpr(new NameExpr(localVar2), Constant.CONTAINS,
							new NodeList<>(new NodeList<>(new NameExpr(prop.getProperty("gender")))))
			};

			Statement init = forToStringVarInit(clazzName, varMap);
			
			Statement objectCreationStmt = forToStringObjCreation(clazzName, arguments, local_dateOfBirth, localVar);

			List<Statement> assertAttrStmts = forToString_assertAttr(localVar2, localVar, conditions);

			List<Statement> ageAndIdStmts = forToString_ageAndId(localVar, localVar2);

			method.getBody().get().getStatements().add(init);
			method.getBody().get().getStatements().add(objectCreationStmt);
			method.getBody().get().getStatements().addAll(assertAttrStmts);
			method.getBody().get().getStatements().addAll(ageAndIdStmts);			
		}
		
		public static void toString02Option(ClassOrInterfaceDeclaration coid, String clazzName) {
			
			coid.getMembers().remove(getMethodByName(coid, "toStringTest"));
			
			String displayValue = "Test toString: Contains two(02) attributes";
			String methodName = "toStringTest";
			String localVar2 = "actualString";
			String localVar = "customer";
			String local_dateOfBirth = "dateOfBirth";

			MethodDeclaration method = buildSignature(coid, AT_TEST, AT_DISPLAY_NAME, displayValue, methodName);
			
			Map<String, Expression> varMap = new HashMap<>();
			varMap.put(prop.getProperty("last_name"), new StringLiteralExpr(prop.getProperty("last_name_value")));
			varMap.put(prop.getProperty("first_name"), new StringLiteralExpr(prop.getProperty("first_name_value")));
			
			NodeList<Expression> arguments = new NodeList<>();
			arguments.add(new NameExpr(prop.getProperty("last_name")));
			arguments.add(new NameExpr(prop.getProperty("first_name")));
			
			Expression[] conditions = {
					getMethodCallExpr(new NameExpr(localVar2), Constant.CONTAINS,
							new NodeList<>(new NodeList<>(new NameExpr(prop.getProperty("last_name"))))),

					getMethodCallExpr(new NameExpr(localVar2), Constant.CONTAINS,
							new NodeList<>(new NodeList<>(new NameExpr(prop.getProperty("first_name"))))),
			};

			Statement init = forToStringVarInit(clazzName, varMap);
			
			Statement objectCreationStmt = forToStringObjCreation(clazzName, arguments, local_dateOfBirth, localVar);

			List<Statement> assertAttrStmts = forToString_assertAttr(localVar2, localVar, conditions);

			List<Statement> ageAndIdStmts = forToString_ageAndId(localVar, localVar2);

			method.getBody().get().getStatements().add(init);
			method.getBody().get().getStatements().add(objectCreationStmt);
			method.getBody().get().getStatements().addAll(assertAttrStmts);
			method.getBody().get().getStatements().addAll(ageAndIdStmts);			
		}

		public static void toString01Option(ClassOrInterfaceDeclaration coid, String clazzName) {
		
			coid.getMembers().remove(getMethodByName(coid, "toStringTest"));
			
			String displayValue = "Test toString: Contains one(01) attributes";
			String methodName = "toStringTest";
			String localVar2 = "actualString";
			String localVar = "customer";
			String local_dateOfBirth = "dateOfBirth";

			MethodDeclaration method = buildSignature(coid, AT_TEST, AT_DISPLAY_NAME, displayValue, methodName);
			
			Map<String, Expression> varMap = new HashMap<>();
			
			NodeList<Expression> arguments = new NodeList<>();
			arguments.add(new NameExpr(prop.getProperty("last_name")));
			
			Expression[] conditions = {
					getMethodCallExpr(new NameExpr(localVar2), Constant.CONTAINS,
							new NodeList<>(new NodeList<>(new NameExpr(prop.getProperty("last_name"))))),
			};

			Statement init = forToStringVarInit(clazzName, varMap);
			
			Statement objectCreationStmt = forToStringObjCreation(clazzName, arguments, local_dateOfBirth, localVar);

			List<Statement> assertAttrStmts = forToString_assertAttr(localVar2, localVar, conditions);

			List<Statement> ageAndIdStmts = forToString_ageAndId(localVar, localVar2);

			method.getBody().get().getStatements().add(init);
			method.getBody().get().getStatements().add(objectCreationStmt);
			method.getBody().get().getStatements().addAll(assertAttrStmts);
			method.getBody().get().getStatements().addAll(ageAndIdStmts);				
		}
		
		public static void testNoSettersForIds(ClassOrInterfaceDeclaration coid, String clazzName) {

			String methodName = "testNoSettersForIds";
			String displyValue = "Information hiding principle (Geheimnisprinzip): No setter for id and nextId";
			String forVariableName = "actual";
			String array_attr = "methods";
			String get_declared_methods = "getDeclaredMethods";
			String assertEqual_msg1 = " should have no setter for id";
			String assertEqual_msg2 = " should have no setter for nextId";

			MethodDeclaration method = buildSignature(coid, AT_TEST, AT_DISPLAY_NAME, displyValue, methodName);

			Statement stmt1 = getAssignExpr(
					new VariableDeclarationExpr(
							new VariableDeclarator(new ClassOrInterfaceType().setName(METHOD_ARRAY), array_attr)),
					getMethdExpr(prop.getProperty("field_class"), get_declared_methods));

			VariableDeclarationExpr variable = new VariableDeclarationExpr(new ClassOrInterfaceType().setName(METHOD),
					forVariableName);
			Expression iterable = new NameExpr(array_attr);

			NodeList<Statement> statements = new NodeList<>();
			statements
					.add(assertEqualsStmt(Constant.ASSERT_NOT_EQUALS, getMethdExpr(forVariableName, Constant.TO_STRING),
							getMethdExpr(prop.getProperty("field_default"), Constant.GET_CLASS),
							new StringLiteralExpr(assertEqual_msg1)));

			statements
					.add(assertEqualsStmt(Constant.ASSERT_NOT_EQUALS, getMethdExpr(forVariableName, Constant.TO_STRING),
							getMethdExpr(prop.getProperty("field_default"), Constant.GET_CLASS),
							new StringLiteralExpr(assertEqual_msg2)));

			BlockStmt body = new BlockStmt(statements);
			Statement stmt2 = new ForEachStmt(variable, iterable, body);

			method.getBody().get().addStatement(stmt1);
			method.getBody().get().addStatement(stmt2);

		}

		public static void testStaticGetterForNextId(ClassOrInterfaceDeclaration coid, String clazzName) {
			
			String methodName = "testStaticGetterForNextId";
			String displyValue = "Information hiding principle (Geheimnisprinzip): Static getter for nextId";
			String local_var_return = "staticGetterForNextId";
			String assertEqual_msg = " should have a static getter for nextId";
			String compareSignature = "public static int de.thb.dim.pizzaPronto.CustomerVO.getNextId()";
			
			testSpecificAttr(
					coid, 
					clazzName, 
					methodName, 
					displyValue, 
					local_var_return, 
					assertEqual_msg,
					compareSignature);

		}

		public static void getIdTest(ClassOrInterfaceDeclaration coid, String clazzName) {
			
			String methodName = "getIdTest";
			String displyValue = "Information hiding principle (Geheimnisprinzip): Test getter for id";
			String local_var_return = "getterForId";
			String assertEqual_msg = " should have a non static getter for id";
			String compareSignature = "public int de.thb.dim.pizzaPronto.CustomerVO.getId()";
			
			testSpecificAttr(coid, clazzName, methodName, displyValue, local_var_return, assertEqual_msg, compareSignature);
		}

		public static void setDateOfBirthCorrectDate(ClassOrInterfaceDeclaration coid, String clazzName) {
			
			String local_today = "today";
			String class_localDate = "LocalDate";
			String call_now = "now";
			String local_alter = "age";
			String local_day = "day";
			String local_month = "month";
			String local_year = "year";
			
			String methodName = "setDateOfBirthCorrectDate";
			String displyValue = "Information hiding principle (Geheimnisprinzip): Setter Test: setDateOfBirth wirh correct date";
			MethodDeclaration method = buildSignature(
					coid, 
					AT_TEST, 
					AT_DISPLAY_NAME, 
					displyValue, 
					methodName);

			
			Statement stmtAlter = new ExpressionStmt(new VariableDeclarationExpr(
					getVar(
							new ClassOrInterfaceType()
							.setName(Constant.INT_SIMPLE_NAME), local_alter)
					.setInitializer(new IntegerLiteralExpr("31"))));

			Statement stmtToday = getAssignExpr(
					new VariableDeclarationExpr(
							getVar(new ClassOrInterfaceType().setName(Constant.INT_SIMPLE_NAME), local_today)),
					getMethdExpr(class_localDate, call_now));

			Statement stmtYear = getAssignExpr(
					new VariableDeclarationExpr(
							getVar(new ClassOrInterfaceType().setName(Constant.INT_SIMPLE_NAME), local_year)),
					getMethdExpr(local_today, "getYear"));

			Statement stmtMonth = getAssignExpr(
					new VariableDeclarationExpr(
							getVar(new ClassOrInterfaceType().setName(Constant.INT_SIMPLE_NAME), local_month)),
					getMethdExpr(local_today, "getMonthValue"));

			Statement stmtDay = getAssignExpr(
					new VariableDeclarationExpr(
							getVar(new ClassOrInterfaceType().setName(Constant.INT_SIMPLE_NAME), local_day)),
					getMethdExpr(local_today, "getDayOfMonth"));
			
			BinaryExpr yearMinusAge = getBinaryExpr(new NameExpr(local_year), new NameExpr(local_alter),
					com.github.javaparser.ast.expr.BinaryExpr.Operator.MINUS);
			NodeList<Expression> arguments = addArgs(
					yearMinusAge,
					new NameExpr(local_month), 
					new NameExpr(local_day));
			
			NodeList<Expression> args = addArgs(getMethodCallExpr(new NameExpr(class_localDate), "of", arguments));

			Statement stmtSetter = new ExpressionStmt(
					getMethodCallExpr(new NameExpr(prop.getProperty("field_default")), "setDateOfBirth", args));
			
			String assertEqual_msg1 = " should have day of birth in the year ";
			Statement assertEqual1 = assertEqualsStmt(yearMinusAge,
					getMethdExpr(getMethdExpr(prop.getProperty("field_default"), "getDateOfBirth").toString(), "getYear"),
					getMethdExpr(prop.getProperty("field_default"), Constant.GET_CLASS),
					getBinaryExpr(new StringLiteralExpr(assertEqual_msg1), yearMinusAge,
							com.github.javaparser.ast.expr.BinaryExpr.Operator.PLUS));
			
			String assertEqual_msg2 = " should have day of birth in the month ";
			Statement assertEqual2 = assertEqualsStmt(new NameExpr(local_month),
					getMethdExpr(getMethdExpr(prop.getProperty("field_default"), "getDateOfBirth").toString(), "getMonthValue"),
					getMethdExpr(prop.getProperty("field_default"), Constant.GET_CLASS),
					getBinaryExpr(new StringLiteralExpr(assertEqual_msg2), new NameExpr(local_month),
							com.github.javaparser.ast.expr.BinaryExpr.Operator.PLUS));
			
			String assertEqual_msg3 = " should have day of birth on the day ";
			Statement assertEqual3 = assertEqualsStmt(new NameExpr(local_day),
					getMethdExpr(getMethdExpr(prop.getProperty("field_default"), "getDateOfBirth").toString(), "getDayOfMonth"),
					getMethdExpr(prop.getProperty("field_default"), Constant.GET_CLASS),
					getBinaryExpr(new StringLiteralExpr(assertEqual_msg3), new NameExpr(local_day),
							com.github.javaparser.ast.expr.BinaryExpr.Operator.PLUS));
			
			
			method.getBody().get().addStatement(stmtAlter);
			method.getBody().get().addStatement(stmtToday);
			method.getBody().get().addStatement(stmtYear);
			method.getBody().get().addStatement(stmtMonth);
			method.getBody().get().addStatement(stmtDay);
			method.getBody().get().addStatement(stmtSetter);
			method.getBody().get().addStatement(assertEqual1);
			method.getBody().get().addStatement(assertEqual2);		
			method.getBody().get().addStatement(assertEqual3);
		}

		public static void setDateOfBirthAgeTooYoung(ClassOrInterfaceDeclaration coid, String clazzName) {
				
			String methodName = "setDateOfBirthAgeTooYoung";
			String displyValue = "Information hiding principle (Geheimnisprinzip): Setter Test: setDateOfBirth with age too young";
			String msg_ageLimit = ", is to young and since no object";
			String ageLimit = "12";
			
			setDateOfBirthAge(coid, clazzName, methodName, displyValue, ageLimit, msg_ageLimit);
		}

		public static void setDateOfBirthAge60(ClassOrInterfaceDeclaration coid, String clazzName) {
			
			String methodName = "setDateOfBirthAge60";
			String displyValue = "Information hiding principle (Geheimnisprinzip): Setter Test: setDateOfBirth with age 60";
			String msg_ageLimit = ", is to old and since no object";
			String ageLimit = "60";
			
			setDateOfBirthAge(coid, clazzName, methodName, displyValue, ageLimit, msg_ageLimit);
		}
		
		public static void setDateOfBirthLeapYear(ClassOrInterfaceDeclaration coid, String clazzName) {
			String methodName = "setDateOfBirthLeapYear";
			String displyValue = "Information hiding principle (Geheimnisprinzip): Setter test: setDateOfBirth with date leap year";
			String class_localDate = "LocalDate";
			
			MethodDeclaration method = buildSignature(coid, AT_TEST, AT_DISPLAY_NAME, displyValue, methodName);
			
			NodeList<Expression> args = addArgs(
					getMethodCallExpr(
							new NameExpr(class_localDate), 
							"of", 
							new NodeList<>(new NameExpr(prop.getProperty("leap_year")))));
			
			Statement stmtSetter = new ExpressionStmt(
					getMethodCallExpr(new NameExpr(prop.getProperty("field_default")), "setDateOfBirth", args));	
			
			String msg = " should have day of birth on 29th of february 1964 and be a correct object";
			
			Statement assertNotNull = assertEqualsStmt(Constant.ASSERT_NOT_NULL,
							getMethdExpr(prop.getProperty("field_default"), "getDateOfBirth"),
							getMethdExpr(prop.getProperty("field_default"), Constant.GET_CLASS), 
							new StringLiteralExpr(msg));
			
			method.getBody().get().addStatement(stmtSetter);
			method.getBody().get().addStatement(assertNotNull);
		}
		
		private static void setDateOfBirthAge(ClassOrInterfaceDeclaration coid, String clazzName, 
				String methodName, String displyValue,
				String ageLimit, String msg_ageLimit) {
			
			String local_today = "today";
			String class_localDate = "LocalDate";
			String call_now = "now";
			String local_alter = "age";
			String local_day = "day";
			String local_month = "month";
			String local_year = "year";

			MethodDeclaration method = buildSignature(coid, AT_TEST, AT_DISPLAY_NAME, displyValue, methodName);

			
			Statement stmtAlter = new ExpressionStmt(new VariableDeclarationExpr(
					getVar(
							new ClassOrInterfaceType()
							.setName(Constant.INT_SIMPLE_NAME), local_alter)
					.setInitializer(new IntegerLiteralExpr(ageLimit))));

			Statement stmtToday = getAssignExpr(
					new VariableDeclarationExpr(
							getVar(new ClassOrInterfaceType().setName(Constant.INT_SIMPLE_NAME), local_today)),
					getMethdExpr(class_localDate, call_now));

			Statement stmtYear = getAssignExpr(
					new VariableDeclarationExpr(
							getVar(new ClassOrInterfaceType().setName(Constant.INT_SIMPLE_NAME), local_year)),
					getMethdExpr(local_today, "getYear"));

			Statement stmtMonth = getAssignExpr(
					new VariableDeclarationExpr(
							getVar(new ClassOrInterfaceType().setName(Constant.INT_SIMPLE_NAME), local_month)),
					getMethdExpr(local_today, "getMonthValue"));

			Statement stmtDay = getAssignExpr(
					new VariableDeclarationExpr(
							getVar(new ClassOrInterfaceType().setName(Constant.INT_SIMPLE_NAME), local_day)),
					getMethdExpr(local_today, "getDayOfMonth"));	
			
			BinaryExpr yearMinusAge = getBinaryExpr(new NameExpr(local_year), new NameExpr(local_alter),
					com.github.javaparser.ast.expr.BinaryExpr.Operator.MINUS);
			NodeList<Expression> arguments = addArgs(
					yearMinusAge,
					new NameExpr(local_month), 
					new NameExpr(local_day));
			
			NodeList<Expression> args = addArgs(getMethodCallExpr(new NameExpr(class_localDate), "of", arguments));

			Statement stmtSetter = new ExpressionStmt(
					getMethodCallExpr(new NameExpr(prop.getProperty("field_default")), "setDateOfBirth", args));
			
			String msg1 = " should have day of birth in the year ";
			Statement assertEqual1 = assertEqualsStmt(new NullLiteralExpr(),
					getMethdExpr(prop.getProperty("field_default"), "getDateOfBirth"),
					getBinaryExpr(
							getMethdExpr(prop.getProperty("field_default"), Constant.GET_CLASS), 
							new StringLiteralExpr(msg1),
							com.github.javaparser.ast.expr.BinaryExpr.Operator.PLUS),
					getBinaryExpr( new EnclosedExpr(yearMinusAge), new StringLiteralExpr(msg_ageLimit),
							com.github.javaparser.ast.expr.BinaryExpr.Operator.PLUS));
			
			method.getBody().get().addStatement(stmtAlter);
			method.getBody().get().addStatement(stmtToday);
			method.getBody().get().addStatement(stmtYear);
			method.getBody().get().addStatement(stmtMonth);
			method.getBody().get().addStatement(stmtDay);
			method.getBody().get().addStatement(stmtSetter);
			method.getBody().get().addStatement(assertEqual1);
		}

		public static void calculateDoB(ClassOrInterfaceDeclaration coid, String clazzName, String methodName,
				String displyValue, String x_year) {

			String local_alter = "alter";

			MethodDeclaration method = buildSignature(coid, AT_TEST, AT_DISPLAY_NAME, displyValue, methodName);

			List<Statement> statements = statementList(x_year);

			String assertEqual_msg = " should have the age ";
			Statement assertEqual = assertEqualsStmt(new IntegerLiteralExpr(x_year),
					getMethdExpr(prop.getProperty("field_default"), "calculateAge"),
					getMethdExpr(prop.getProperty("field_default"), Constant.GET_CLASS),
					getBinaryExpr(new StringLiteralExpr(assertEqual_msg), new NameExpr(local_alter),
							com.github.javaparser.ast.expr.BinaryExpr.Operator.PLUS));

			statements.add(assertEqual);

			for (Statement statement : statements) {
				method.getBody().get().getStatements().add(statement);
			}

		}

		private static MethodDeclaration calculateDoBForX_Years(ClassOrInterfaceDeclaration coid, String clazzName,
				String methodName, String displyValue, String x_year) {

			List<Statement> statements = statementList(x_year);
			String local_alter = "alter";

			MethodDeclaration method = buildSignature(coid, AT_TEST, AT_DISPLAY_NAME, displyValue, methodName);

			String assertEqual_msg = " has the age ";
			Statement assertEqual1 = assertEqualsStmt(new IntegerLiteralExpr("-1"),
					getMethdExpr(prop.getProperty("field_default"), "calculateAge"),
					getMethdExpr(prop.getProperty("field_default"), Constant.GET_CLASS),
					getBinaryExpr(new StringLiteralExpr(assertEqual_msg), new NameExpr(local_alter),
							com.github.javaparser.ast.expr.BinaryExpr.Operator.PLUS));

			String msg = "  date of birth should be set null ";
			Statement assertEqual2 = assertEqualsStmt(new NullLiteralExpr(),
					getMethdExpr(prop.getProperty("field_default"), "getDateOfBirth"),
					getMethdExpr(prop.getProperty("field_default"), Constant.GET_CLASS), new StringLiteralExpr(msg));

			statements.add(assertEqual1);
			statements.add(assertEqual2);

			for (Statement statement : statements) {
				method.getBody().get().getStatements().add(statement);
			}

			return method;

		}

		private static List<Statement> statementList(String x_year) {

			String local_today = "today";
			String class_localDate = "LocalDate";
			String call_now = "now";
			String local_alter = "alter";
			String local_day = "day";
			String local_month = "month";
			String local_year = "year";
			List<Statement> statements = new ArrayList<Statement>();

			Statement stmtAlter = new ExpressionStmt(new VariableDeclarationExpr(
					getVar(new ClassOrInterfaceType().setName(Constant.INT_SIMPLE_NAME), local_alter)));

			Statement stmtToday = getAssignExpr(
					new VariableDeclarationExpr(
							getVar(new ClassOrInterfaceType().setName(Constant.INT_SIMPLE_NAME), local_today)),
					getMethdExpr(class_localDate, call_now));

			Statement stmtYear = getAssignExpr(
					new VariableDeclarationExpr(
							getVar(new ClassOrInterfaceType().setName(Constant.INT_SIMPLE_NAME), local_year)),
					getMethdExpr(local_today, "getYear"));

			Statement stmtMonth = getAssignExpr(
					new VariableDeclarationExpr(
							getVar(new ClassOrInterfaceType().setName(Constant.INT_SIMPLE_NAME), local_month)),
					getMethdExpr(local_today, "getMonthValue"));

			Statement stmtDay = getAssignExpr(
					new VariableDeclarationExpr(
							getVar(new ClassOrInterfaceType().setName(Constant.INT_SIMPLE_NAME), local_day)),
					getMethdExpr(local_today, "getDayOfMonth"));

			Statement stmtInit_Alter = getAssignExpr(new NameExpr(local_alter), new IntegerLiteralExpr(x_year));

			NodeList<Expression> arguments = addArgs(
					getBinaryExpr(new NameExpr(local_year), new NameExpr(local_alter),
							com.github.javaparser.ast.expr.BinaryExpr.Operator.MINUS),
					new NameExpr(local_month), new NameExpr(local_day));
			NodeList<Expression> args = addArgs(getMethodCallExpr(new NameExpr(class_localDate), "of", arguments));

			Statement stmtSetter = new ExpressionStmt(
					getMethodCallExpr(new NameExpr(prop.getProperty("field_default")), "setDateOfBirth", args));

			statements.add(stmtAlter);
			statements.add(stmtToday);
			statements.add(stmtYear);
			statements.add(stmtMonth);
			statements.add(stmtDay);
			statements.add(stmtInit_Alter);
			statements.add(stmtSetter);

			return statements;
		}

		private static void testSpecificAttr(ClassOrInterfaceDeclaration coid, String clazzName, String methodName,
				String displyValue, String local_var_return, String assertEqual_msg, String compareSignature) {

			String forVariableName = "actual";
			String array_attr = "methods";
			String get_declared_methods = "getDeclaredMethods";

			MethodDeclaration method = buildSignature(coid, AT_TEST, AT_DISPLAY_NAME, displyValue, methodName);

			Statement stmt1 = getAssignExpr(
					new VariableDeclarationExpr(
							new VariableDeclarator(new ClassOrInterfaceType().setName(METHOD_ARRAY), array_attr)),
					getMethdExpr(prop.getProperty("field_class"), get_declared_methods));

			Statement stmt2 = getAssignExpr(
					new VariableDeclarationExpr(new VariableDeclarator(
							new ClassOrInterfaceType().setName(Constant.BOOLEAN_SIMPLE_NAME), local_var_return)),
					new BooleanLiteralExpr(false));

			VariableDeclarationExpr variable = new VariableDeclarationExpr(new ClassOrInterfaceType().setName(METHOD),
					forVariableName);
			Expression iterable = new NameExpr(array_attr);

			Expression condition = getMethodCallExpr(getMethdExpr(forVariableName, Constant.TO_STRING),
					Constant.EQUALS_METH, new NodeList<>(new StringLiteralExpr(compareSignature)));

			BlockStmt body = new BlockStmt(new NodeList<>(new IfStmt().setCondition(condition)
					.setThenStmt(getAssignExpr(new NameExpr(local_var_return), new BooleanLiteralExpr(true)))));

			Statement stmt3 = new ForEachStmt(variable, iterable, body);

			Statement assertEqual = assertEqualsStmt(new BooleanLiteralExpr(true), new NameExpr(local_var_return),
					getMethdExpr(prop.getProperty("field_default"), Constant.GET_CLASS),
					new StringLiteralExpr(assertEqual_msg));

			method.getBody().get().getStatements().add(stmt1);
			method.getBody().get().getStatements().add(stmt2);
			method.getBody().get().getStatements().add(stmt3);
			method.getBody().get().getStatements().add(assertEqual);
		}

		
		private static List<Statement> toStringTest(ClassOrInterfaceDeclaration coid, 
				String clazzName, Map<String, Expression> varMap, NodeList<Expression> arguments, Expression[] conditions) {
			
			List<Statement> statements = new ArrayList<Statement>();
			
			String displayValue = "Test toString: Contains all attributes";
			String methodName = "toStringTest";
			String localVar2 = "actualString";
			String localVar = prop.getProperty("local_var_customer");//"customer";
			String class_localDate = "LocalDate";
			String local_dateOfBirth = "dateOfBirth";
			String call_of = "of";

			String local_day = "day";
			String local_month = "month";
			String local_year = "year";

			MethodDeclaration method = buildSignature(coid, AT_TEST, AT_DISPLAY_NAME, displayValue, methodName);

			Statement init = forToStringVarInit(clazzName, varMap);

			List<Statement> dob_stmts = forDod(local_year, local_month, local_day, class_localDate, local_dateOfBirth, call_of);
			
			Statement objectCreationStmt = forToStringObjCreation(clazzName, arguments, local_dateOfBirth, localVar);
			
			List<Statement> assertAttrStmts = forToString_assertAttr(localVar2, localVar, conditions);

			Statement dobStmt = forToStringDob_assertion(localVar, localVar2);
			
			List<Statement> ageAndIdStmts = forToString_ageAndId(localVar, localVar2);
			
			
			statements.add(init);
			statements.addAll(dob_stmts);
			statements.add(objectCreationStmt);
			statements.addAll(assertAttrStmts);
			statements.add(dobStmt);
			statements.addAll(ageAndIdStmts);					

			statements.forEach(s->method.getBody().get().addStatement(s));	
			
			return statements;
		}
		
		private static List<Statement> forToString_ageAndId(String localVar, String localVar2){
			
			List<Statement> statements = new ArrayList<Statement>();
			
			Expression condition6 = getMethodCallExpr(new NameExpr(localVar2), Constant.CONTAINS,
					new NodeList<>(new NodeList<>(getMethodCallExpr(new NameExpr(Constant.STRING), "valueOf",
							new NodeList<>(getMethdExpr(localVar, "getId")))

					)));

			Expression condition7 = getMethodCallExpr(new NameExpr(localVar2), Constant.CONTAINS,
					new NodeList<>(new NodeList<>(getMethodCallExpr(new NameExpr(Constant.STRING), "valueOf",
							new NodeList<>(getMethdExpr(localVar, "calculateAge")))

					)));
			
			Statement stmt6 = new ExpressionStmt(callAssert(Constant.ASSERT_TRUE, condition6));
			Statement stmt7 = new ExpressionStmt(callAssert(Constant.ASSERT_TRUE, condition7));
					
			statements.add(stmt6);
			statements.add(stmt7);	
			
			return statements;
		}
		
		private static Statement forToStringDob_assertion(String localVar, String localVar2) {		

			NodeList<Expression> arg5 = new NodeList<>();
			Expression scope = getMethdExpr(localVar, "getDateOfBirth");
			NodeList<Expression> args51 = new NodeList<>();
			Expression scope2 = new NameExpr("DateTimeFormatter");
			NodeList<Expression> args52 = new NodeList<>();
			args52.add(new StringLiteralExpr("dd MMM yyyy"));
			args51.add(getMethodCallExpr(scope2, "ofPattern", args52));
			arg5.add(getMethodCallExpr(scope, "format", args51));
			Expression condition5 = getMethodCallExpr(new NameExpr(localVar2), Constant.CONTAINS, arg5);
			
			String assertMessage = "Format should be dd MMM yyyy";
			return new ExpressionStmt(callAssert(Constant.ASSERT_TRUE, condition5, assertMessage));
		}
		
		private static List<Statement> forToString_assertAttr(String localVar2, String localVar, Expression... conditions){
			
			List<Statement> statements = new ArrayList<Statement>();

			VariableDeclarator v = new VariableDeclarator().setName(localVar2).setType(Constant.STRING)
					.setInitializer(getMethdExpr(localVar, Constant.TO_STRING));
			
			Statement stmt_actual = new ExpressionStmt(new VariableDeclarationExpr(v));
			statements.add(stmt_actual);

			Stream.of(conditions).forEach(c->{
				Statement stmt = new ExpressionStmt(callAssert(Constant.ASSERT_TRUE, c));
				statements.add(stmt);
			});

			return statements;
		}
		
		private static Statement forToStringObjCreation(String clazzName, NodeList<Expression> arguments, String local_dateOfBirth, String localVar) {
			
			VariableDeclarator cus = new VariableDeclarator().setName(localVar).setType(Constant.STRING);

			return getAssignExpr(new VariableDeclarationExpr(cus),
					objectCreation(clazzName, arguments)); 
		}
		
		private static Statement forToStringVarInit(String clazzName, Map<String, Expression> varMap){

			return new ExpressionStmt(getVarDeclarationExpr(clazzName, Constant.STRING, varMap));
		}
		
		private static List<Statement> forDod(String local_year, 
				String local_month, String local_day, String class_localDate, String local_dateOfBirth, String call_of){
			
			List<Statement> statements = new ArrayList<Statement>();
			
			Statement stmtYear = getAssignExpr(
					new VariableDeclarationExpr(
							getVar(new ClassOrInterfaceType().setName(Constant.INT_SIMPLE_NAME), local_year)),
					new IntegerLiteralExpr("1998"));
			statements.add(stmtYear);

			Statement stmtMonth = getAssignExpr(
					new VariableDeclarationExpr(
							getVar(new ClassOrInterfaceType().setName(Constant.INT_SIMPLE_NAME), local_month)),
					new IntegerLiteralExpr("6"));
			statements.add(stmtMonth);

			Statement stmtDay = getAssignExpr(
					new VariableDeclarationExpr(
							getVar(new ClassOrInterfaceType().setName(Constant.INT_SIMPLE_NAME), local_day)),
					new IntegerLiteralExpr("18"));
			statements.add(stmtDay);

			NodeList<Expression> args = addArgs(new NameExpr(local_year), new NameExpr(local_month),
					new NameExpr(local_day));

			Statement stmtDateOfBirth = getAssignExpr(
					new VariableDeclarationExpr(
							getVar(new ClassOrInterfaceType().setName(class_localDate), local_dateOfBirth)),
					getMethodCallExpr(new NameExpr(class_localDate), call_of, args));
			statements.add(stmtDateOfBirth);
			
			return statements;
		}

		public static void addFieldFromOrderType(ClassOrInterfaceDeclaration coid) {
			
			NodeList<Modifier> modifiers = new NodeList<>();
			modifiers.add(Modifier.privateModifier());
			
			VariableDeclarator variable = getVar(new ClassOrInterfaceType().setName("OrderVO"), "order");
			FieldDeclaration fieldDeclaration = new FieldDeclaration(modifiers, variable);
			BodyDeclaration<?> node = fieldDeclaration;
			BodyDeclaration<?> afterThisNode =  coid.getFieldByName("dateOfBirth").get();
			
			coid.getMembers().addAfter(node, afterThisNode);
			fieldDeclaration.createGetter();
			fieldDeclaration.createSetter();
			
		}

		public static void addMethodHasOrder(ClassOrInterfaceDeclaration coid) {
			
			String methodName = "hasOrder";
			MethodDeclaration method = new MethodDeclaration(
												new NodeList<>(Modifier.publicModifier()), 
												new ClassOrInterfaceType().setName(Constant.BOOLEAN_SIMPLE_NAME), 
												methodName
											);
			
			Statement ifStmt = getIfStmt();
			method.getBody().get().getStatements().add(ifStmt);
			
			
			String text = "\r\n"+
							 " Checks whether there is a current orderVO or not\r\n"+
							 "\r\n"+ 
							"  @return true => orderVO available, false => there is no orderVO"+
							" "+ 
							 "\r\n";
			method.setJavadocComment(text);
			coid.getMembers().add(method);
			
			MethodDeclaration toStringDeclaration = getMethodByName(coid, "toString");
			
			BinaryExpr asBinaryExpr = toStringDeclaration
													.getBody().get()
													.getStatements().getFirst().get()
													.asReturnStmt().getExpression().get()
													.asBinaryExpr();
			
			Expression rightExpr = asBinaryExpr.getRight();
			
			StringLiteralExpr asStringLiteralExpr = rightExpr.asStringLiteralExpr();
			
			String asString = asStringLiteralExpr.asString();
			asString = asString.replace(
							asString, getBinaryExpr(new StringLiteralExpr(", Order: "), 
							new MethodCallExpr().setName(methodName), PLUS).toString());
			
			asBinaryExpr.setRight(getBinaryExpr(new NameExpr(asString), asStringLiteralExpr, PLUS));
			
		}
		
		private static IfStmt getIfStmt() {
			return new IfStmt()
						.setCondition(
								new BinaryExpr(
										new NameExpr("order"), 
										new NullLiteralExpr(), 
										com.github.javaparser.ast.expr.BinaryExpr.Operator.NOT_EQUALS))
						
						.setThenStmt(new ReturnStmt(new BooleanLiteralExpr(true)))		
						
						.setElseStmt(new ReturnStmt(new BooleanLiteralExpr(false)));
		}

		public static void testMethodHasOrder(ClassOrInterfaceDeclaration coid, String clazzName) {
			
			String methodNameTrue = "hasOderTrue";
			String assertCallTrue = "assertTrue";
			String displyValueTrue = "Order is set in Customer and hasOrder gives true";
			
			String methodNameFalse= "hasOderFalse";
			String assertCallFalse = "assertFalse";
			String displyValueFalse = "Order is null in customer (the setter isn't called) and hasOrder gives false";
			
			
			testMethodHasOrder(coid, methodNameTrue, displyValueTrue, assertCallTrue);
			testMethodHasOrder(coid, methodNameFalse, displyValueFalse, assertCallFalse);
						
		}
		
		private static MethodDeclaration testMethodHasOrder(ClassOrInterfaceDeclaration coid, String methodName, String displyValue, String assertCall) {
			
			String localVar_order = "order";
			String typeName = "OrderVO";
			String customerField = prop.getProperty("field_default");
			String method = "hasOder";
			String setter = "setOrder";
			String localDateTimeType = "LocalDateTime";
			
			MethodDeclaration hasOrderMethod = buildSignature(coid, AT_TEST, AT_DISPLAY_NAME, displyValue, methodName);
			
			//Begin statements declaration
			Statement initialization = getOrderInitialization(localVar_order, typeName, customerField,
					localDateTimeType);
					
			Statement methodCall = getOrderSetterCall(localVar_order, customerField, setter);
			
			Statement assertTrue = getOrderAssertStmt(assertCall, customerField, method);
			
			NodeList<Statement> statements = hasOrderMethod.getBody().get().getStatements();
			statements.add(initialization);
			if(methodName.equals("hasOderTrue"))
				statements.add(methodCall);
			statements.add(assertTrue);
			
			// Add import statement of the association class
			String clazz = "generated.de.thb.dim.pizzaPronto.u3.OrderVO";
			ImportDeclaration importDeclaration = 
					new ImportDeclaration(clazz, false, false);
			hasOrderMethod.findCompilationUnit()
				.get()
				.addImport(importDeclaration);
			
			return hasOrderMethod;
			
		}

		private static Statement getOrderInitialization(String localVar_order, String typeName, String customerField,
				String localDateTimeType) {
			List<String> varList = new ArrayList<String>();
			varList.add(localVar_order);
			Expression target = getVarDeclarationExpr(typeName, varList);
			
			NodeList<Expression> arguments = new NodeList<>();
			
			arguments.add(getMethodCallExpr(new NameExpr(localDateTimeType), Constant.NOW, new NodeList<>()));
			arguments.add(new NameExpr(customerField));
			
			Expression value = objectCreation(typeName, arguments);
			Statement initialization = getAssignExpr(target, value);
			return initialization;
		}

		private static Statement getOrderSetterCall(String localVar_order, String customerField, String setter) {
			Statement methodCall = new ExpressionStmt(
					getMethodCallExpr(
							new NameExpr(customerField), setter, 
							new NodeList<>(new NameExpr(localVar_order))
							));
			return methodCall;
		}

		private static Statement getOrderAssertStmt(String assertCall, String customerField, String method) {
			Expression scope = new NameExpr(customerField);
			
			NodeList<Expression> args = new NodeList<>();
			Expression condition = getMethodCallExpr(scope, method, args);
			
			Statement assertTrue = new ExpressionStmt(
					callAssert(assertCall, condition)
					);
			return assertTrue;
		}
		
		private static Statement getOrderAssertEqualStmt(String assertCall, String customerField, String method) {
			Expression scope = new NameExpr(customerField);
			
			NodeList<Expression> args = new NodeList<>();
			MethodCallExpr condition = getMethodCallExpr(scope, method, args);
			
			Statement assertEqual = assertEqualsStmt(assertCall, condition);
			return assertEqual;
		}

		public static void updateToStringTest(ClassOrInterfaceDeclaration coid, String clazzName) {
			
			String customerField = prop.getProperty("local_var_customer");
			String method = "hasOder";
			String assertCallFalse = "assertFalse";
			String toBeUpdatedMethod = "toStringTest";
			
			MethodDeclaration toString = getMethodByName(coid, toBeUpdatedMethod);
			
			toString.getBody()
					.get()
					.getStatements()
					.addLast(getOrderAssertStmt(assertCallFalse, customerField, method));			
		}

		public static void testSetOrder(ClassOrInterfaceDeclaration coid, String clazzName) {
			
			// TODO Auto-generated method stub
			String localVar_order = "order";
			String typeName = "OrderVO";
			String customerField = prop.getProperty("field_default");
			String method = "hasOder";
			String setter = "setOrder";
			String localDateTimeType = "LocalDateTime";
			String displyValue = "Information hiding principle (Geheimnisprinzip): Setter/getter order";
			String methodName = "setGetOrder";
			
			MethodDeclaration setGetOrder = buildSignature(coid, AT_TEST, AT_DISPLAY_NAME, displyValue, methodName);
			
			//Begin statements declaration
			Statement initialization = getOrderInitialization(localVar_order, typeName, customerField,
					localDateTimeType);
					
			Statement methodCall = getOrderSetterCall(localVar_order, customerField, setter);
			
			Statement assertEqual = getOrderAssertEqualStmt(localVar_order, customerField, method);
			
			NodeList<Statement> statements = setGetOrder.getBody()
					.get()
					.getStatements();
			
			statements.add(initialization);
			statements.add(methodCall);
			statements.add(assertEqual);
		}

	}

	// A model to instantiate an object
	private static ObjectCreationExpr setAttributes(String clazzName, Expression... attributes) {

		NodeList<Expression> arguments = new NodeList<>();
		Stream.of(attributes).forEach(attr -> arguments.add(attr));

		return objectCreation(clazzName, arguments);
	}

	public static void addEqualsHashCode(ClassOrInterfaceDeclaration coid, String clazzName, String methodName,
			String fieldName2, String fieldName3) {

		String message = "Similar objects provide the identical HashCode";

//		String displayValue = "Simliar objects provide similar hashcode.";
		MethodDeclaration method = buildAddSignature(coid, AT_TEST, /* AT_DISPLAY_NAME, displayValue, */ methodName);

		String left = getMethodCallExpr(new NameExpr(fieldName2), Constant.EQUALS_METH,
				new NodeList<>(new NameExpr(fieldName3))).toString();
		String innerLeft = getMethdExpr(fieldName2, Constant.HASH_CODE).toString();
		String innerRight = getMethdExpr(fieldName3, Constant.HASH_CODE).toString();
		Expression inner = getBinaryExpr(innerLeft, innerRight,
				com.github.javaparser.ast.expr.BinaryExpr.Operator.EQUALS);
		String right = new EnclosedExpr(inner).toString();

		Expression condition = getBinaryExpr(left, right, com.github.javaparser.ast.expr.BinaryExpr.Operator.EQUALS);
		Statement stmt = new ExpressionStmt(callAssert(Constant.ASSERT_TRUE, condition, message));

		method.getBody().get().addStatement(stmt);
	}

	// A model to initialize an array object
	public static ArrayInitializerExpr getArrayInitialization(NodeList<Expression> args1) {

		return new ArrayInitializerExpr(args1);
	}

	public static void addEqualsDifferentObjectsDifferentClasses(ClassOrInterfaceDeclaration coid, String clazzName,
			String fieldName4) {
		String assertFalseMessage = " equals is not correct when using objects from differnent class.";
		String displayValue = "equals is tested different objects from different classes.";
		String methodName = "equalsDifferentObjectsDifferentClasses";

		MethodDeclaration method = buildSignature(coid, AT_TEST, AT_DISPLAY_NAME, displayValue, methodName);

		Statement stmt = new ExpressionStmt(callAssert(Constant.ASSERT_FALSE,
				getMethodCallExpr(new NameExpr(fieldName4), Constant.EQUALS_METH,
						new NodeList<>(new NameExpr(new ThisExpr().toString()))),
				getMethdExpr(fieldName4, Constant.GET_CLASS).toString(), assertFalseMessage));

		method.getBody().get().addStatement(stmt);
	}

	public static void addEqualsDifferentObjects(ClassOrInterfaceDeclaration coid, String clazzName, String setter,
			String fieldName4, String fieldName2) {

		String assertFalseMessage = " equals is correct when using diffenrent objects of the same class";
		String displayValue = "equals is tested different objects.";
		String methodName = "equalsDifferentObjects";
//		String setter = "setName";
		String setterParam = "Anders";

		MethodDeclaration method = buildSignature(coid, AT_TEST, AT_DISPLAY_NAME, displayValue, methodName);

		Statement stmt1 = new ExpressionStmt(getMethodCallExpr(new NameExpr(fieldName4), setter,
				new NodeList<>(new StringLiteralExpr(setterParam))));
		Statement stmt2 = new ExpressionStmt(callAssert(Constant.ASSERT_FALSE,
				getMethodCallExpr(new NameExpr(fieldName4), Constant.EQUALS_METH,
						new NodeList<>(new NameExpr(fieldName2))),
				getMethdExpr(fieldName4, "getClass").toString(), assertFalseMessage));

		method.getBody().get().addStatement(stmt1);
		method.getBody().get().addStatement(stmt2);
	}

	public static void addEquals3EqualObjects(ClassOrInterfaceDeclaration coid, String clazzName, String fieldName2,
			String fieldName3, String fieldName4) {
		
		String displayValue = "equals is tested with three equal objects. Is it reflexive, symmetric and transitive according to the contract ";
		String methodName = "equals3EqualObjects";
		String assertFalseMessage1 = "It is reflexive: for any non-null reference value x, x.equals(x) should return true. ";
		String msg2 = "It is symmetric: for any non-null reference values x and y, x.equals(y) should return true if and only if y.equals(x) returns true. ";
		String msg3 = "It is transitive: for any non-null reference values x, y, and z, if x.equals(y) returns true and y.equals(z) returns true, then x.equals(z) should return true. ";
		String falseLitteral = "false";

		MethodDeclaration method = buildSignature(coid, AT_TEST, AT_DISPLAY_NAME, displayValue, methodName);

		Statement stmt1 = new ExpressionStmt(
				callAssert(Constant.ASSERT_TRUE, getMethodCallExpr(new NameExpr(fieldName2), Constant.EQUALS_METH,
						new NodeList<>(new NameExpr(fieldName3))), assertFalseMessage1));

		Statement stmt2 = new ExpressionStmt(callAssert(Constant.ASSERT_TRUE,
				getBinaryExpr(
						getMethodCallExpr(new NameExpr(fieldName2), Constant.EQUALS_METH,
								new NodeList<>(new NameExpr(fieldName3))).toString(),
						getMethodCallExpr(new NameExpr(fieldName2), Constant.EQUALS_METH,
								new NodeList<>(new NameExpr(fieldName3))).toString(),
						com.github.javaparser.ast.expr.BinaryExpr.Operator.EQUALS),
				msg2));

		Expression condition = new ConditionalExpr(
				getBinaryExpr(
						getMethodCallExpr(new NameExpr(fieldName2), Constant.EQUALS_METH,
								new NodeList<>(new NameExpr(fieldName3))).toString(),
						getMethodCallExpr(new NameExpr(fieldName3), Constant.EQUALS_METH,
								new NodeList<>(new NameExpr(fieldName4))).toString(),
						com.github.javaparser.ast.expr.BinaryExpr.Operator.AND),
				getMethodCallExpr(new NameExpr(fieldName2), Constant.EQUALS_METH,
						new NodeList<>(new NameExpr(fieldName4))),
				new NameExpr(falseLitteral));
		Statement stmt3 = new ExpressionStmt(callAssert(Constant.ASSERT_TRUE, condition, msg3));

		method.getBody().get().addStatement(stmt1);
		method.getBody().get().addStatement(stmt2);
		method.getBody().get().addStatement(stmt3);
	}

	public static void addEquals2IdenticalObjects(ClassOrInterfaceDeclaration coid, String clazzName,
			String fieldName3) {
		
		String displayValue = "equals is tested with  identical objects. ";
		String methodName = "equals2IdenticalObjects";

		MethodDeclaration method = buildSignature(coid, AT_TEST, AT_DISPLAY_NAME, displayValue, methodName);
		Statement stmt = new ExpressionStmt(callAssert(Constant.ASSERT_TRUE, getMethodCallExpr(new NameExpr(fieldName3),
				Constant.EQUALS_METH, new NodeList<>(new NameExpr(fieldName3)))));

		method.getBody().get().addStatement(stmt);
	}

	public static void addEquals2EqualObjects(ClassOrInterfaceDeclaration coid, String clazzName, String fieldName3,
			String fieldName2) {
		
		String displayValue = "equals is tested with two equal/similar objects, i.e different adresses and similar attributes. ";
		String methodName = "equals2EqualObjects";

		MethodDeclaration method = buildSignature(coid, AT_TEST, AT_DISPLAY_NAME, displayValue, methodName);

		BinaryExpr condition = getBinaryExpr(fieldName3, fieldName2,
				com.github.javaparser.ast.expr.BinaryExpr.Operator.EQUALS);

		Statement stmt1 = new ExpressionStmt(callAssert(Constant.ASSERT_FALSE, condition));
		Statement stmt2 = new ExpressionStmt(callAssert(Constant.ASSERT_TRUE, getMethodCallExpr(
				new NameExpr(fieldName3), Constant.EQUALS_METH, new NodeList<>(new NameExpr(fieldName2)))));

		method.getBody().get().addStatement(stmt1);
		method.getBody().get().addStatement(stmt2);

	}

	public static void addMethodEqualsNull(ClassOrInterfaceDeclaration coid, String clazzName, String fieldName) {
		
		String assertFalseMessage = "For any non-null reference value x, x.equals(null) should return false.";
		String failMessage = "Cannot invoke equals because one attribute is null. Should not throw a NullPointerException";
		String callFail = "fail";

		MethodDeclaration method = buildSignature(coid, AT_TEST, AT_DISPLAY_NAME, EQUALS_IS_TESTED_WITH_NULL,
				EQUALS_NULL);

		NodeList<Statement> statements = new NodeList<>();

		MethodCallExpr condition = getMethodCallExpr(new NameExpr(fieldName), Constant.EQUALS_METH,
				new NodeList<>(new NullLiteralExpr()));
		statements.add(new ExpressionStmt(callAssert(Constant.ASSERT_FALSE, condition, assertFalseMessage)));
		BlockStmt tryBlock = new BlockStmt().setStatements(statements);

		NodeList<CatchClause> catchClauses = new NodeList<>();
		Parameter parameter = new Parameter(new ClassOrInterfaceType().setName(Constant.NULL_POINTER_EXCEPTION),
				Constant.EXCEPTION_VAR);

		BlockStmt body = new BlockStmt().addStatement(new MethodCallExpr(callFail, new StringLiteralExpr(failMessage)));
		CatchClause catchClauseNode = new CatchClause(parameter, body);
		catchClauses.add(catchClauseNode);

		Statement statement = new TryStmt().setTryBlock(tryBlock).setCatchClauses(catchClauses);

		method.getBody().get().addStatement(statement);
	}

	private static List<FieldDeclaration> addTestAttributes(ClassOrInterfaceDeclaration coid, String clazzName,
			String... fields) {

		List<FieldDeclaration> fieldDeclarations = coid.getFields();
		NodeList<Modifier> modifiers = new NodeList<>();
		modifiers.add(Modifier.privateModifier());
		modifiers.add(Modifier.staticModifier());

		Type type = new ClassOrInterfaceType().setName(clazzName);

		Stream.of(fields).forEach(f -> {
			VariableDeclarator var2 = getVar(type, f);
			addNewField(coid, modifiers, var2);
		});

		return fieldDeclarations;
	}

	public static void addFirstOptionMethod(ClassOrInterfaceDeclaration coid, String clazzName, Properties prop) {

		String fieldName = getFirstFieldElement(coid);

		MethodDeclaration method = buildSignature(coid, AT_TEST, AT_DISPLAY_NAME,
				INITIALIZATION_CONSTRUCTOR_WITH_1_PARAMETERS, TEST_INI_CONSTRUCTOR01_PARAM);

		// build body
		Statement stmt1 = getStmt(Constant.STRING, prop.getProperty("last_name"), prop.getProperty("last_name_value"));

		NodeList<Expression> arguments = new NodeList<>();
		arguments.add(new NameExpr(prop.getProperty("last_name")));

		ObjectCreationExpr target = new ObjectCreationExpr().setType(new ClassOrInterfaceType().setName(clazzName))
				.setArguments(arguments);

		Statement stmt4 = getStmt(fieldName, target);

		Statement stmt5 = assertEqualsStmt(prop.getProperty("last_name"),
				getMethdExpr(fieldName, prop.getProperty("get_last_name"))); // fieldName,
		// GET_LAST_NAME

		method.getBody().get().addStatement(stmt1).addStatement(stmt4).addStatement(stmt5);
	}

	private static String getFirstFieldElement(ClassOrInterfaceDeclaration coid) {
		
		String fieldName = coid.getFields()
				.get(0)
				.getVariable(0)
				.getNameAsString();
		return fieldName;
	}

	public static MethodDeclaration addSecondOptionMethod(ClassOrInterfaceDeclaration coid, String clazzName,
			String displayValue, String methodName, Map<String, String> variables, Map<String, String> asserts,
			Properties prop) {

		String fieldName = getFirstFieldElement(coid);

		MethodDeclaration method = buildSignature(coid, AT_TEST, AT_DISPLAY_NAME, displayValue, methodName);

		NodeList<Expression> arguments = new NodeList<>();
		NodeList<Statement> otherList = new NodeList<>();

		variables.forEach((k, v) -> {
			Statement stmt = getStmt(Constant.STRING, k, v);
			arguments.add(new NameExpr(k));
			otherList.add(stmt);
		});
		
//		Statement stmt1 = getStmt(Constant.STRING, prop.getProperty("last_name"), prop.getProperty("last_name_value"));
//
//		Statement stmt2 = getStmt(Constant.STRING, prop.getProperty("first_name"), prop.getProperty("first_name_value"));
////		
//		
//		arguments.add(new NameExpr(prop.getProperty("last_name")));
//		arguments.add(new NameExpr(prop.getProperty("first_name")));

		ObjectCreationExpr target = new ObjectCreationExpr().setType(new ClassOrInterfaceType().setName(clazzName))
				.setArguments(arguments);

		Statement stmt4 = getStmt(fieldName, target);
		otherList.add(stmt4);

		asserts.forEach((k, v) -> {
			Statement stmt = assertEqualsStmt(k, getMethdExpr(fieldName, v));

			otherList.add(stmt);
		});

//		Statement stmt5 = assertEqualsStmt(
//				prop.getProperty("last_name"), 
//				getMethdExpr(fieldName, prop.getProperty("get_last_name"))); // fieldName,
//																								// GET_LAST_NAME
//
//		Statement stmt6 = assertEqualsStmt(prop.getProperty("first_name"), getMethdExpr(fieldName, prop.getProperty("get_first_name"))); // fieldName,
//																								// getFirstName

		method.getBody().get().getStatements().addAll(otherList);
//				.addStatement(stmt1)
//				.addStatement(stmt2)
//				.addStatement(stmt4)
//				.addStatement(stmt5)
//				.addStatement(stmt6);
//		
		return method;
	}

	public static MethodDeclaration buildSignature(ClassOrInterfaceDeclaration coid, String atTest, String atDisplay,
			String displyValue, String methodName) {

		NodeList<AnnotationExpr> annotations = new NodeList<>();
		AnnotationExpr expr = new MarkerAnnotationExpr(atTest);
		annotations.add(expr);

		MethodDeclaration node = coid.addMethod(methodName, Keyword.PUBLIC);
		node.addAnnotation(expr);

		node.addSingleMemberAnnotation(atDisplay, new StringLiteralExpr(displyValue));
		return node;
	}

	private static MethodDeclaration buildAddSignature(ClassOrInterfaceDeclaration coid, String atTest,
			String methodName) {
		NodeList<AnnotationExpr> annotations = new NodeList<>();
		AnnotationExpr expr = new MarkerAnnotationExpr(atTest);
		annotations.add(expr);

		MethodDeclaration node = coid.addMethod(methodName, Keyword.PUBLIC);
		node.addAnnotation(expr);

		return node;
	}

	private static Statement getStmt(String type, String variableName, String target) {

		VariableDeclarationExpr left = new VariableDeclarationExpr(new ClassOrInterfaceType().setName(type),
				variableName);
		return new ExpressionStmt(new AssignExpr(left, new StringLiteralExpr(String.valueOf(target)), Operator.ASSIGN));
	}

	private static Statement getStmt(String variableName, Expression target) {
		return new ExpressionStmt(new AssignExpr(new NameExpr(variableName), target, Operator.ASSIGN));
	}

	private static Statement getStmt(String type, String variableName, Expression target) {

		VariableDeclarationExpr left = new VariableDeclarationExpr(new ClassOrInterfaceType().setName(type),
				variableName);
		return new ExpressionStmt(new AssignExpr(left, target, Operator.ASSIGN));
	}

	private static VariableDeclarator getVar(Type type, String name) {
		return new VariableDeclarator(type, name);
	}

	private static void addNewField(ClassOrInterfaceDeclaration coid, NodeList<Modifier> modifiers,
			VariableDeclarator variableDeclarator) {
		coid.getMembers().addAfter(new FieldDeclaration(modifiers, variableDeclarator), coid.getMember(0));
	}

	private static ArrayCreationExpr getArrayCreation(String type, NodeList<Expression> args) {
		return new ArrayCreationExpr().setElementType(type).setInitializer(new ArrayInitializerExpr(args));
	}

	private static NodeList<Expression> addArgs(Expression expr, ArrayCreationExpr initializer, String value) {
		
		NodeList<Expression> result = new NodeList<>();
		result.add(expr);
		result.add(initializer);
		result.add(new NameExpr(value));
		return result;
	}

	public static NodeList<Expression> addArgs(Expression... expr) {
		
		NodeList<Expression> result = new NodeList<>();
		for (Expression expression : expr) {
			result.add(expression);
		}
		return result;
	}

	private static MethodCallExpr getMethdExpr(String name, String getter) {
		return new MethodCallExpr(new NameExpr(name), getter);
	}

	private static NodeList<Expression> addArgs(Expression string1, Expression string2, Expression string3) {
		
		NodeList<Expression> result = new NodeList<>();
		result.add(string1);
		result.add(string2);
		result.add(string3);
		return result;
	}

	private static NodeList<Expression> addArgs(String... string3) {
		
		NodeList<Expression> result = new NodeList<>();
		Stream.of(string3).forEach(value -> result.add(new StringLiteralExpr(value)));

		return result;
	}

	private static ObjectCreationExpr objectCreation(String javaFileName, NodeList<Expression> arguments) {
		return new ObjectCreationExpr().setType(javaFileName).setArguments(arguments);
	}

	private static ExpressionStmt getStmt(Expression target, Expression value) {
		return new ExpressionStmt(new AssignExpr(target, value, Operator.ASSIGN));
	}

	private static BinaryExpr getBinaryExpr(String left, String right,
			com.github.javaparser.ast.expr.BinaryExpr.Operator operator) {
		return new BinaryExpr().setLeft(new NameExpr(left)).setRight(new NameExpr(right)).setOperator(operator);
	}

	private static BinaryExpr getBinaryExpr(Expression left, Expression right,
			com.github.javaparser.ast.expr.BinaryExpr.Operator operator) {
		return new BinaryExpr().setLeft(left).setRight(right).setOperator(operator);
	}

	private static BinaryExpr getBinaryExpr(String left, Expression right,
			com.github.javaparser.ast.expr.BinaryExpr.Operator operator) {
		return new BinaryExpr().setLeft(new NameExpr(left)).setRight(right).setOperator(operator);
	}

	private static Statement assertEqualsStmt(String field, String objectInstance, String getter) {

		Statement result = new ExpressionStmt(callAssert(Constant.ASSERT_EQUALS, new NameExpr(field),
				getMethdExpr(objectInstance, getter).toString()));
		return result;
	}

	private static Statement assertEqualsStmt(String callAssertEqual, Expression expr1, Expression expr2,
			Expression expr3) {

		Statement result = new ExpressionStmt(callAssert(callAssertEqual, expr1, expr2, expr3));
		return result;
	}

	private static Statement assertEqualsStmt(Expression expr1, Expression expr2, Expression expr3, Expression expr4) {

		Statement result = new ExpressionStmt(callAssert(Constant.ASSERT_EQUALS, expr1, expr2, expr3, expr4));
		return result;
	}

	private static Statement assertEqualsStmt(String field, MethodCallExpr expr) {

		Statement result = new ExpressionStmt(callAssert(Constant.ASSERT_EQUALS, new NameExpr(field), expr));
		return result;
	}

	private static Statement assertEqualsStmt(Expression field, Expression expr) {

		Statement result = new ExpressionStmt(callAssert(Constant.ASSERT_EQUALS, field, expr));
		return result;
	}

	private static MethodCallExpr callAssert(String assertCall, Expression condition, String assertFalseMessage) {
		return new MethodCallExpr(assertCall, condition, new StringLiteralExpr(assertFalseMessage));
	}

	private static MethodCallExpr callAssert(String assertCall, Expression condition, Expression assertFalseMessage) {
		return new MethodCallExpr(assertCall, condition, assertFalseMessage);
	}

	private static MethodCallExpr callAssert(String assertCall, Expression condition, String supplier,
			String assertFalseMessage) {
		return new MethodCallExpr(assertCall, condition, getBinaryExpr(supplier,
				new StringLiteralExpr(assertFalseMessage), com.github.javaparser.ast.expr.BinaryExpr.Operator.PLUS));
	}

	private static MethodCallExpr callAssert(String assertCall, Expression condition, Expression supplier,
			Expression assertFalseMessage) {

		return new MethodCallExpr(assertCall, condition,
				getBinaryExpr(supplier, assertFalseMessage, com.github.javaparser.ast.expr.BinaryExpr.Operator.PLUS));
	}

	private static MethodCallExpr callAssert(String assertCall, Expression condition, Expression supplier,
			Expression assertFalseMessage, Expression expr) {

		return new MethodCallExpr(assertCall, condition, supplier,
				getBinaryExpr(assertFalseMessage, expr, com.github.javaparser.ast.expr.BinaryExpr.Operator.PLUS));
	}

	private static MethodCallExpr callAssert(String assertCall, Expression condition) {
		return new MethodCallExpr(assertCall, condition);
	}

	private static MethodCallExpr getMethodCallExpr(Expression scope, String methodName, NodeList<Expression> args) {
		return new MethodCallExpr(scope, methodName, args);
	}

	private static VariableDeclarationExpr getVarDeclarationExpr(String clazzName, List<String> varList) {
		NodeList<VariableDeclarator> variables = new NodeList<>();
		varList.stream()
				.forEach(v -> variables.add(new VariableDeclarator(new ClassOrInterfaceType().setName(clazzName), v)));

		return new VariableDeclarationExpr(new NodeList<>(), variables);
	}

	private static VariableDeclarationExpr getVarDeclarationExpr(String clazzName, String type,
			Map<String, Expression> varInitialazerMap) {
		NodeList<VariableDeclarator> variables = new NodeList<>();
		varInitialazerMap.forEach((k, v) -> {
			VariableDeclarator varD = new VariableDeclarator().setType(new ClassOrInterfaceType().setName(type))
					.setName(k).setInitializer(v);
			variables.add(varD);
		});

		return new VariableDeclarationExpr(new NodeList<>(), variables);
	}

	private static ExpressionStmt getAssignExpr(Expression target, Expression value) {
		return new ExpressionStmt(new AssignExpr().setTarget(target).setValue(value));
	}

	private static Expression getExprAssignment(Expression target, Expression value) {
		return new AssignExpr().setTarget(target).setValue(value);
	}

	public static MethodDeclaration getMethodByName(ClassOrInterfaceDeclaration coid, String methName) {
		MethodDeclaration method = coid.getMethodsByName(methName).stream().findFirst().get();
		return method;
	}

	private static void addEqualsOtherNoLastname(ClassOrInterfaceDeclaration coid, String clazzName, Properties prop,
			String localVar1, String localVar2, String key) {

		String displayValue = "equals is tested with other's lastname is null. ";
		String methodName = "equalsOtherNoLastname";
		MethodDeclaration method = buildSignature(coid, AT_TEST, AT_DISPLAY_NAME, displayValue, methodName);

		Expression target1 = new VariableDeclarationExpr(
				new VariableDeclarator(new ClassOrInterfaceType().setName(clazzName), localVar1));
		Expression target2 = new VariableDeclarationExpr(
				new VariableDeclarator(new ClassOrInterfaceType().setName(clazzName), localVar2));

		Expression value1 = setAttributes(clazzName, new StringLiteralExpr(prop.getProperty("nach_name")),
				new StringLiteralExpr(prop.getProperty("vor_name")), new NameExpr(prop.getProperty(key)));

		Expression value2 = setAttributes(clazzName, new NullLiteralExpr(),
				new StringLiteralExpr(prop.getProperty("vor_name")), new NameExpr(prop.getProperty(key)));

		Statement stmt1 = getAssignExpr(target1, value1);
		Statement stmt2 = getAssignExpr(target2, value2);
		Statement stmt3 = new ExpressionStmt(callAssert(Constant.ASSERT_FALSE, getMethodCallExpr(
				new NameExpr(localVar1), Constant.EQUALS_METH, new NodeList<>(new NameExpr(localVar2)))));

		method.getBody().get().addStatement(stmt1);
		method.getBody().get().addStatement(stmt2);
		method.getBody().get().addStatement(stmt3);

	}

	private static void addEqualsThisNoLastname(ClassOrInterfaceDeclaration coid, String clazzName, Properties prop,
			String localVar1, String localVar2, String key) {

		String displayValue = "equals is tested with this lastname is null. ";
		String methodName = "equalsThisNoLastname";
		String failMessage = "equals is tested with this lastname  is null and other not. Should not throw a NullPointerException";
		String callFail = "fail";

		MethodDeclaration method = buildSignature(coid, AT_TEST, AT_DISPLAY_NAME, displayValue, methodName);

		Expression target1 = new VariableDeclarationExpr(
				new VariableDeclarator(new ClassOrInterfaceType().setName(clazzName), localVar1));
		Expression target2 = new VariableDeclarationExpr(
				new VariableDeclarator(new ClassOrInterfaceType().setName(clazzName), localVar2));

		Expression value1 = setAttributes(clazzName, new NullLiteralExpr(),
				new StringLiteralExpr(prop.getProperty("vor_name")), new NameExpr(prop.getProperty(key)));

		Expression value2 = setAttributes(clazzName, new StringLiteralExpr(prop.getProperty("nach_name")),
				new StringLiteralExpr(prop.getProperty("vor_name")), new NameExpr(prop.getProperty(key)));

		Statement stmt1 = getAssignExpr(target1, value1);
		Statement stmt2 = getAssignExpr(target2, value2);
		Statement stmt3 = new ExpressionStmt(callAssert(Constant.ASSERT_FALSE, getMethodCallExpr(
				new NameExpr(localVar1), Constant.EQUALS_METH, new NodeList<>(new NameExpr(localVar2)))));

		NodeList<Statement> statements = new NodeList<>();

		statements.add(stmt3);
		BlockStmt tryBlock = new BlockStmt().setStatements(statements);

		NodeList<CatchClause> catchClauses = new NodeList<>();
		Parameter parameter = new Parameter(new ClassOrInterfaceType().setName(Constant.NULL_POINTER_EXCEPTION),
				Constant.EXCEPTION_VAR);

		BlockStmt body = new BlockStmt().addStatement(new MethodCallExpr(callFail, new StringLiteralExpr(failMessage)));
		CatchClause catchClauseNode = new CatchClause(parameter, body);
		catchClauses.add(catchClauseNode);

		Statement statement = new TryStmt().setTryBlock(tryBlock).setCatchClauses(catchClauses);

		method.getBody().get().addStatement(stmt1);
		method.getBody().get().addStatement(stmt2);
		method.getBody().get().addStatement(statement);

	}

	private static void addEqualsOtherNoFirstname(ClassOrInterfaceDeclaration coid, String clazzName, Properties prop,
			String localVar1, String localVar2, String key) {

		String displayValue = "equals is tested with other's firstname is null. ";
		String methodName = "equalsOtherNoFirstname";
		MethodDeclaration method = buildSignature(coid, AT_TEST, AT_DISPLAY_NAME, displayValue, methodName);

		Expression target1 = new VariableDeclarationExpr(
				new VariableDeclarator(new ClassOrInterfaceType().setName(clazzName), localVar1));
		Expression target2 = new VariableDeclarationExpr(
				new VariableDeclarator(new ClassOrInterfaceType().setName(clazzName), localVar2));

		Expression value1 = setAttributes(clazzName, new StringLiteralExpr(prop.getProperty("nach_name")),
				new StringLiteralExpr(prop.getProperty("vor_name")), new NameExpr(prop.getProperty(key)));

		Expression value2 = setAttributes(clazzName, new StringLiteralExpr(prop.getProperty("nach_name")),
				new NullLiteralExpr(), new NameExpr(prop.getProperty(key)));

		Statement stmt1 = getAssignExpr(target1, value1);
		Statement stmt2 = getAssignExpr(target2, value2);
		Statement stmt3 = new ExpressionStmt(callAssert(Constant.ASSERT_FALSE, getMethodCallExpr(
				new NameExpr(localVar1), Constant.EQUALS_METH, new NodeList<>(new NameExpr(localVar2)))));

		method.getBody().get().addStatement(stmt1);
		method.getBody().get().addStatement(stmt2);
		method.getBody().get().addStatement(stmt3);

	}

	private static void addEqualsThisNoFirstname(ClassOrInterfaceDeclaration coid, String clazzName, Properties prop,
			String localVar1, String localVar2, String key) {

		String displayValue = "equals is tested with this firstname is null. ";
		String methodName = "equalsThisNoFirstname";
		String failMessage = "equals is tested with this firstname  is null and other not. Should not throw a NullPointerException";
		String callFail = "fail";

		MethodDeclaration method = buildSignature(coid, AT_TEST, AT_DISPLAY_NAME, displayValue, methodName);

		Expression target1 = new VariableDeclarationExpr(
				new VariableDeclarator(new ClassOrInterfaceType().setName(clazzName), localVar1));
		Expression target2 = new VariableDeclarationExpr(
				new VariableDeclarator(new ClassOrInterfaceType().setName(clazzName), localVar2));

		Expression value1 = setAttributes(clazzName, new StringLiteralExpr(prop.getProperty("nach_name")),
				new NullLiteralExpr(), new NameExpr(prop.getProperty(key)));

		Expression value2 = setAttributes(clazzName, new StringLiteralExpr(prop.getProperty("nach_name")),
				new StringLiteralExpr(prop.getProperty("vor_name")), new NameExpr(prop.getProperty(key)));

		Statement stmt1 = getAssignExpr(target1, value1);
		Statement stmt2 = getAssignExpr(target2, value2);
		Statement stmt3 = new ExpressionStmt(callAssert(Constant.ASSERT_FALSE, getMethodCallExpr(
				new NameExpr(localVar1), Constant.EQUALS_METH, new NodeList<>(new NameExpr(localVar2)))));

		NodeList<Statement> statements = new NodeList<>();

		statements.add(stmt3);
		BlockStmt tryBlock = new BlockStmt().setStatements(statements);

		NodeList<CatchClause> catchClauses = new NodeList<>();
		Parameter parameter = new Parameter(new ClassOrInterfaceType().setName(Constant.NULL_POINTER_EXCEPTION),
				Constant.EXCEPTION_VAR);

		BlockStmt body = new BlockStmt().addStatement(new MethodCallExpr(callFail, new StringLiteralExpr(failMessage)));
		CatchClause catchClauseNode = new CatchClause(parameter, body);
		catchClauses.add(catchClauseNode);

		Statement statement = new TryStmt().setTryBlock(tryBlock).setCatchClauses(catchClauses);

		method.getBody().get().addStatement(stmt1);
		method.getBody().get().addStatement(stmt2);
		method.getBody().get().addStatement(statement);

	}

	private static void equalsOtherNoParam(ClassOrInterfaceDeclaration coid, String clazzName, String displayValue,
			String methodName, Properties prop, String localVar1, String localVar2, String key) {

		MethodDeclaration method = buildSignature(coid, AT_TEST, AT_DISPLAY_NAME, displayValue, methodName);

		Expression target1 = new VariableDeclarationExpr(
				new VariableDeclarator(new ClassOrInterfaceType().setName(clazzName), localVar1));
		Expression target2 = new VariableDeclarationExpr(
				new VariableDeclarator(new ClassOrInterfaceType().setName(clazzName), localVar2));

		Expression value1 = setAttributes(clazzName, new StringLiteralExpr(prop.getProperty("nach_name")),
				new StringLiteralExpr(prop.getProperty("vor_name")), new NameExpr(prop.getProperty(key)));

		Expression value2 = setAttributes(clazzName, new StringLiteralExpr(prop.getProperty("nach_name")),
				new StringLiteralExpr(prop.getProperty("vor_name")), new NullLiteralExpr());

		Statement stmt1 = getAssignExpr(target1, value1);
		Statement stmt2 = getAssignExpr(target2, value2);
		Statement stmt3 = new ExpressionStmt(callAssert(Constant.ASSERT_FALSE, getMethodCallExpr(
				new NameExpr(localVar1), Constant.EQUALS_METH, new NodeList<>(new NameExpr(localVar2)))));

		method.getBody().get().addStatement(stmt1);
		method.getBody().get().addStatement(stmt2);
		method.getBody().get().addStatement(stmt3);

	}

	private static void equalsThisNoParam(ClassOrInterfaceDeclaration coid, String clazzName, String displayValue,
			String methodName, Properties prop, String localVar1, String localVar2, String key, String failMessage) {

		String callFail = "fail";

		MethodDeclaration method = buildSignature(coid, AT_TEST, AT_DISPLAY_NAME, displayValue, methodName);

		Expression target1 = new VariableDeclarationExpr(
				new VariableDeclarator(new ClassOrInterfaceType().setName(clazzName), localVar1));
		Expression target2 = new VariableDeclarationExpr(
				new VariableDeclarator(new ClassOrInterfaceType().setName(clazzName), localVar2));

		Expression value1 = setAttributes(clazzName, new StringLiteralExpr(prop.getProperty("nach_name")),
				new StringLiteralExpr(prop.getProperty("vor_name")), new NullLiteralExpr());

		Expression value2 = setAttributes(clazzName, new StringLiteralExpr(prop.getProperty("nach_name")),
				new StringLiteralExpr(prop.getProperty("vor_name")), new NameExpr(prop.getProperty(key)));

		Statement stmt1 = getAssignExpr(target1, value1);
		Statement stmt2 = getAssignExpr(target2, value2);
		Statement stmt3 = new ExpressionStmt(callAssert(Constant.ASSERT_FALSE, getMethodCallExpr(
				new NameExpr(localVar1), Constant.EQUALS_METH, new NodeList<>(new NameExpr(localVar2)))));

		NodeList<Statement> statements = new NodeList<>();

		statements.add(stmt3);
		BlockStmt tryBlock = new BlockStmt().setStatements(statements);

		NodeList<CatchClause> catchClauses = new NodeList<>();
		Parameter parameter = new Parameter(new ClassOrInterfaceType().setName(Constant.NULL_POINTER_EXCEPTION),
				Constant.EXCEPTION_VAR);

		BlockStmt body = new BlockStmt().addStatement(new MethodCallExpr(callFail, new StringLiteralExpr(failMessage)));
		CatchClause catchClauseNode = new CatchClause(parameter, body);
		catchClauses.add(catchClauseNode);

		Statement statement = new TryStmt().setTryBlock(tryBlock).setCatchClauses(catchClauses);

		method.getBody().get().addStatement(stmt1);
		method.getBody().get().addStatement(stmt2);
		method.getBody().get().addStatement(statement);

	}

}
