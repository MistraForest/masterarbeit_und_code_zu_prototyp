package utils.exceptions;

public class InvalidParameterNumber extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public InvalidParameterNumber(String message) {
		super(message);
	}

}
