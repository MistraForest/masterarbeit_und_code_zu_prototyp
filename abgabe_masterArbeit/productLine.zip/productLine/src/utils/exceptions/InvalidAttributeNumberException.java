package utils.exceptions;

public class InvalidAttributeNumberException extends Exception {

	public InvalidAttributeNumberException(String message) {
		super(message);
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
