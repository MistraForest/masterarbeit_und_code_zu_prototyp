package utils.generator.handler;

import com.github.javaparser.ast.CompilationUnit;

/**
 * An interface that should be implemented by using a template to generate code into extra file 
 * @author forest
 *
 */
public interface IGeneratorToTemplate {
	/**
	 * use a template to generate code into extra file
	 * @param cu the compilation unit of the java file file
	 * @param directory the directory for the file
	 * @param file the java file name
	 */
	void getTemplate(CompilationUnit cu, String directory, String file);
}
