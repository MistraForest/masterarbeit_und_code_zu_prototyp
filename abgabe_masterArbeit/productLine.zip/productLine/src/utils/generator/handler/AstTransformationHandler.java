package utils.generator.handler;

import java.io.File;

public interface AstTransformationHandler {

	/**
	 * The method modify the abstract syntax tree representation of a java file
	 * @param level the directory level in which the file is located
	 * @param path  the path to the file                          
	 * @param file  the file itself                               
	 */
	void modifyAST(int level, String path, File file);
}
