package utils.generator.handler;

import java.io.File;

public interface Filter {

	/**
	 * Filter the correct file in a directory
	 * @param level the directory level in which the file is located
	 * @param path the path to the file
	 * @param file the file itself
	 * @return true if found
	 */
	boolean filterFile(int level, String path, File file);
}
