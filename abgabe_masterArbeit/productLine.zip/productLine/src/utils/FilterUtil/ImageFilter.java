package utils.FilterUtil;

import java.io.File;

import utils.generator.handler.Filter;

public class ImageFilter implements Filter {
	
	private String fileEnd;

	public ImageFilter(String fileEnd) {
		this.fileEnd = fileEnd;
	}

	@Override
	public boolean filterFile(int level, String path, File file) {
		
		return isPNGfilter(path);
	}
	
	private boolean isPNGfilter(String path) {
		boolean found = false;
		if(path.endsWith(fileEnd)) {
			found = true;
		}	
		return found;
	}

}
