package utils.FilterUtil;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class PatternFilter {
	public static boolean isSubstring(String matcherString, String patternString) {

		Pattern pattern = Pattern.compile(patternString, Pattern.CASE_INSENSITIVE);
		Matcher matcher = pattern.matcher(matcherString);
		boolean matchFound = matcher.find();

		return matchFound;
	}
}
