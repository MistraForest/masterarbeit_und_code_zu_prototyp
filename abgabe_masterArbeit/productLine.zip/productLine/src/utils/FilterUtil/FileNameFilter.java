package utils.FilterUtil;

import java.io.File;

import utils.generator.handler.Filter;

public class FileNameFilter implements Filter {
	
	private String javaFileName;

	public FileNameFilter(String javaFileName) {
		this.javaFileName = javaFileName;
	}

	@Override
	public boolean filterFile(int level, String path, File file) {
		
		return path.endsWith(this.javaFileName + ".java");
	}

}
