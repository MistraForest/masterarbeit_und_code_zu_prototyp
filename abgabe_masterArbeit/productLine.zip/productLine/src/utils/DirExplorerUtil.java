package utils;

import java.io.File;

import utils.generator.handler.AstTransformationHandler;
import utils.generator.handler.Filter;

/**
 * This class has the ability to search and filter a specific file in order 
 * to start processing some operation on it
 * @author forest
 *
 */
public class DirExplorerUtil {

	private AstTransformationHandler fileHandler;
	private Filter filter;

	public DirExplorerUtil(Filter filter, AstTransformationHandler fileHandler) {
		this.filter = filter;
		this.fileHandler = fileHandler;
	}
	
	public DirExplorerUtil(AstTransformationHandler fileHandler) {
		this.fileHandler = fileHandler;
	}

	public void explore(File root) {
		explore(0, "", root);
	}

	private void explore(int level, String path, File file) {
		if (file.isDirectory()) {
			for (File child : file.listFiles()) {
				explore(level + 1, path + "/" + child.getName(), child);		
			}
		} else {
			if (filter.filterFile(level, path, file)) {
				fileHandler.modifyAST(level, path, file);
			}
		}
	}
}
