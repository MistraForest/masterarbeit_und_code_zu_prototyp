package utils;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import com.github.javaparser.ast.Modifier;
import com.github.javaparser.ast.NodeList;
import com.github.javaparser.ast.body.ClassOrInterfaceDeclaration;
import com.github.javaparser.ast.body.FieldDeclaration;
import com.github.javaparser.ast.body.MethodDeclaration;
import com.github.javaparser.ast.body.VariableDeclarator;
import com.github.javaparser.ast.expr.AssignExpr;
import com.github.javaparser.ast.expr.AssignExpr.Operator;
import com.github.javaparser.ast.expr.BinaryExpr;
import com.github.javaparser.ast.expr.ConditionalExpr;
import com.github.javaparser.ast.expr.EnclosedExpr;
import com.github.javaparser.ast.expr.Expression;
import com.github.javaparser.ast.expr.IntegerLiteralExpr;
import com.github.javaparser.ast.expr.MethodCallExpr;
import com.github.javaparser.ast.expr.NameExpr;
import com.github.javaparser.ast.expr.NullLiteralExpr;
import com.github.javaparser.ast.expr.VariableDeclarationExpr;
import com.github.javaparser.ast.stmt.ExpressionStmt;
import com.github.javaparser.ast.stmt.ReturnStmt;
import com.github.javaparser.ast.stmt.Statement;
import com.github.javaparser.ast.type.ClassOrInterfaceType;
import com.github.javaparser.ast.type.Type;

import constants.Constant;

/**
 * This class store the reusable element to build the variants of the hashCode() method
 * @author forest
 *
 */
public class HashCodeUtil {

	private static final String _0 = "0";
	private static final String _1 = "1";
	private static final String _31 = "31";
	private static final String PRIME = "prime";
	private static final String RESULT = "result";

	public static MethodDeclaration buildLongVariant(ClassOrInterfaceDeclaration coid, String methodName,
			String javaFileName) {

		// build method signature
		NodeList<Modifier> modifiers = new NodeList<>();
		modifiers.add(Modifier.publicModifier());
		Type typeInt = new ClassOrInterfaceType().setName(Constant.INT_SIMPLE_NAME);

		MethodDeclaration method = new MethodDeclaration(modifiers, typeInt, methodName);
		method.addMarkerAnnotation(Constant.overrideClazz);

		NodeList<Statement> statements = new NodeList<>();
		Statement prime = new ExpressionStmt(new VariableDeclarationExpr(new VariableDeclarator(
				new ClassOrInterfaceType().setName(Constant.INT_SIMPLE_NAME), PRIME, new IntegerLiteralExpr(_31)))
						.setModifiers(Modifier.Keyword.FINAL));

		Statement result = new ExpressionStmt(new VariableDeclarationExpr(new VariableDeclarator(
				new ClassOrInterfaceType().setName(Constant.INT_SIMPLE_NAME), RESULT, new IntegerLiteralExpr(_1))));

		NameExpr resultExpr = null, primeExpr = null;

		for (FieldDeclaration field : coid.getFields()) {
			Expression right = null;
			NodeList<Expression> args = new NodeList<>();

			String fieldNameAsString = field.getVariable(0).getNameAsString();
			String typeAsString = field.getVariable(0).getTypeAsString();

			resultExpr = getVariableName(result);
			primeExpr = getVariableName(prime);
			Expression target = resultExpr;
			Expression left = getExpr(primeExpr, resultExpr,
					com.github.javaparser.ast.expr.BinaryExpr.Operator.MULTIPLY);
			
			if (typeAsString.equals(Constant.INT_SIMPLE_NAME)) {
				continue;
			}

			if (typeAsString.equals(Constant.STRING_ARRAYS_CLASS) || typeAsString.equals(Constant.FLOAT)) {

				if (typeAsString.equals(Constant.STRING_ARRAYS_CLASS)) {

					args.add(getExpr(fieldNameAsString));
					right = getExpr(getExpr(Constant.ARRAYS_CLASS), Constant.HASH_CODE, args);
				}
				if (typeAsString.equals(Constant.FLOAT)) {
					right = initExpression(fieldNameAsString, args);
				}
			} else {
				right = initExpression(fieldNameAsString);
			}

			Expression value = getExpr(left, right, com.github.javaparser.ast.expr.BinaryExpr.Operator.PLUS);
			AssignExpr assignExpr = getExpr(target, value, Operator.ASSIGN);
			statements.add(new ExpressionStmt(assignExpr));

		}

		//TODO Better Solution required
//		statements.removeFirst();
//		statements.removeFirst();
		
		statements.addFirst(prime);
		statements.addFirst(result);
		
		statements.add(new ReturnStmt().setExpression(resultExpr));
		method.getBody().get().getStatements().addAll(statements);
		
		return method;
	}

	public static MethodDeclaration buildShortVariant(ClassOrInterfaceDeclaration coid, String methodName,
			String javaFileName) {

		// build method signature
		NodeList<Modifier> modifiers = new NodeList<>();
		modifiers.add(Modifier.publicModifier());
		Type typeInt = new ClassOrInterfaceType().setName(Constant.INT_SIMPLE_NAME);

		MethodDeclaration method = new MethodDeclaration(modifiers, typeInt, methodName);
		method.addMarkerAnnotation(Constant.overrideClazz);

		NodeList<Statement> statements = new NodeList<>();
		Statement prime = new ExpressionStmt(new VariableDeclarationExpr(new VariableDeclarator(
				new ClassOrInterfaceType().setName(Constant.INT_SIMPLE_NAME), PRIME, new IntegerLiteralExpr(_31)))
						.setModifiers(Modifier.Keyword.FINAL));

		Statement result = new ExpressionStmt(new VariableDeclarationExpr(new VariableDeclarator(
				new ClassOrInterfaceType().setName(Constant.INT_SIMPLE_NAME), RESULT, new IntegerLiteralExpr(_1))));

		NameExpr resultExpr = null, primeExpr = null;
		NodeList<Expression> allArgs = new NodeList<>();
		StringBuffer buffer = new StringBuffer();
		String typeAsString = null, fieldNameAsString = "";
		Map<String, Boolean> map = new HashMap<>();
		NodeList<Expression> args = new NodeList<>();
		Expression right = null;
		Expression target = null;
		Expression left = null;
		
		List<FieldDeclaration> filteredList = filterIds(coid.getFields());
		
		// look up for class declaration for an array as field declaration
		boolean hasArray = false;
		for (FieldDeclaration field : filteredList) {
			typeAsString = field.getVariable(0).getTypeAsString();
			fieldNameAsString = field.getVariable(0).getNameAsString();
			hasArray = typeAsString.equals(Constant.STRING_ARRAYS_CLASS);
			map.put(fieldNameAsString, hasArray);
			buffer.append(fieldNameAsString).append(", ");
		}

		StringBuilder builder = new StringBuilder();

		// if so handle it separately
		if (hasArray) {
			statements.add(prime);
			statements.add(result);
			for (Map.Entry<String, Boolean> entry : map.entrySet()) {

				if (!entry.getValue()) {
					builder.append(entry.getKey()).append(", ");
				} else {

					args.add(getExpr(fieldNameAsString));
					resultExpr = getVariableName(result);

					primeExpr = getVariableName(prime);
					target = resultExpr;
					left = getExpr(primeExpr, resultExpr, com.github.javaparser.ast.expr.BinaryExpr.Operator.MULTIPLY);

					right = getExpr(getExpr(Constant.ARRAYS_CLASS), Constant.HASH_CODE, args);
					Expression value = getExpr(left, right, com.github.javaparser.ast.expr.BinaryExpr.Operator.PLUS);
					AssignExpr assignExpr = getExpr(target, value, Operator.ASSIGN);

					statements.add(new ExpressionStmt(assignExpr));
				}
			}

			resultExpr = getVariableName(result);
			target = resultExpr;
			primeExpr = getVariableName(prime);

			left = getExpr(primeExpr, resultExpr, com.github.javaparser.ast.expr.BinaryExpr.Operator.MULTIPLY);
			NodeList<Expression> withArrayNodes = new NodeList<>();

			withArrayNodes.add(getExpr(builder.substring(0, builder.length() - 2).toString()));
			right = getExpr(getExpr(Constant.OBJECTS), Constant.HASH, withArrayNodes);

			Expression value = getExpr(left, right, com.github.javaparser.ast.expr.BinaryExpr.Operator.PLUS);
			AssignExpr assignExpr = getExpr(target, value, Operator.ASSIGN);

			statements.add(new ExpressionStmt(assignExpr));
			statements.add(new ReturnStmt(target));

		} else { // otherwise

			allArgs.add(getExpr(buffer.substring(0, buffer.length() - 2).toString()));
			Expression returnStmt = getExpr(getExpr(Constant.OBJECTS), Constant.HASH, allArgs);
			statements.add(new ReturnStmt(returnStmt));
		}

		method.getBody().get().getStatements().addAll(statements);

		return method;
	}


	private static List<FieldDeclaration> filterIds(List<FieldDeclaration> fields) {
		String suffix_nextId = "Id";
		String suffix_id = "id";
		
		List<FieldDeclaration> filteredList = fields
				.stream()
				.filter(f->{
					String nameAsString = f.getVariable(0).getNameAsString();					
					return !(nameAsString.endsWith(suffix_nextId)||nameAsString.endsWith(suffix_id));
				}).collect(Collectors.toList());
		return filteredList;
	}

	private static Expression initExpression(String fieldNameAsString, NodeList<Expression> args) {
		Expression right;
		args.add(getExpr(fieldNameAsString));
		right = getExpr(new NameExpr(Constant.FLOAT_BIG), Constant.FLOAT_TO_INT_BITS, args);
		return right;
	}

	private static Expression initExpression(String fieldNameAsString) {
		Expression result;
		Expression condition = new EnclosedExpr(getExpr(getExpr(fieldNameAsString), new NullLiteralExpr(),
				com.github.javaparser.ast.expr.BinaryExpr.Operator.EQUALS));
		Expression thenExpr = new IntegerLiteralExpr(_0);
		Expression elseExpr = getExpr(getExpr(fieldNameAsString), Constant.HASH_CODE);
		result = new EnclosedExpr(new ConditionalExpr(condition, thenExpr, elseExpr));
		return result;
	}

	
	private static Expression getExpr(Expression left, Expression right,
			com.github.javaparser.ast.expr.BinaryExpr.Operator operator) {
		return new BinaryExpr(left, right, operator);
	}

	private static AssignExpr getExpr(Expression target, Expression value, Operator operator) {
		return new AssignExpr(target, value, operator);
	}

	private static NameExpr getExpr(String name) {
		return new NameExpr(name);
	}

	private static Expression getExpr(Expression expression, String name, NodeList<Expression> nodeList) {
		return new MethodCallExpr(expression, name, nodeList);
	}

	private static Expression getExpr(Expression expression, String name) {
		return new MethodCallExpr(expression, name);
	}

	private static NameExpr getVariableName(Statement result) {
		return getExpr(
				result.asExpressionStmt().getExpression().asVariableDeclarationExpr().getVariable(0).getNameAsString());
	}

}
