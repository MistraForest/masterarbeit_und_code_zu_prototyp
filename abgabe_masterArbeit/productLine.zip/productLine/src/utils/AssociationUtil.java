package utils;

import com.github.javaparser.ast.Modifier;
import com.github.javaparser.ast.NodeList;
import com.github.javaparser.ast.body.ClassOrInterfaceDeclaration;
import com.github.javaparser.ast.body.MethodDeclaration;
import com.github.javaparser.ast.comments.LineComment;
import com.github.javaparser.ast.expr.ArrayAccessExpr;
import com.github.javaparser.ast.expr.AssignExpr;
import com.github.javaparser.ast.expr.AssignExpr.Operator;
import com.github.javaparser.ast.expr.BinaryExpr;
import com.github.javaparser.ast.expr.Expression;
import com.github.javaparser.ast.expr.MethodCallExpr;
import com.github.javaparser.ast.expr.NameExpr;
import com.github.javaparser.ast.expr.NullLiteralExpr;
import com.github.javaparser.ast.expr.ObjectCreationExpr;
import com.github.javaparser.ast.expr.SimpleName;
import com.github.javaparser.ast.expr.StringLiteralExpr;
import com.github.javaparser.ast.expr.UnaryExpr;
import com.github.javaparser.ast.expr.VariableDeclarationExpr;
import com.github.javaparser.ast.stmt.BlockStmt;
import com.github.javaparser.ast.stmt.ExpressionStmt;
import com.github.javaparser.ast.stmt.ForStmt;
import com.github.javaparser.ast.stmt.IfStmt;
import com.github.javaparser.ast.stmt.Statement;
import com.github.javaparser.ast.type.ClassOrInterfaceType;
import com.github.javaparser.ast.type.Type;

import constants.Constant;

/**
 * This class store the model to build and generate the toString() method using StringBuffer.
 * This variant is an alternative implementation based on string methods.
 * @author forest
 *
 */
public class AssociationUtil {

	public static MethodDeclaration toStringVariantWithBuffer(
			ClassOrInterfaceDeclaration coid, String methodName) {
		
		// build method signature
		NodeList<Modifier> modifiers = new NodeList<>();
		modifiers.add(Modifier.publicModifier());
		Type typeInt = new ClassOrInterfaceType().setName(Constant.STRING);
		MethodDeclaration method = new MethodDeclaration(modifiers, typeInt, methodName);
		
		// Some comment 
		LineComment comment2 = new LineComment( "Solution with StringBuffer is efficient!");
		method.setComment(comment2);
		
		NodeList<Statement> statements = new NodeList<>();
		
		// Method local variable
		String localVar = "text";
		
		//Variable declaration
		Expression target = new VariableDeclarationExpr(
				new ClassOrInterfaceType()
				.setName(new SimpleName(Constant.STRING_BUFFER)), localVar);
		
		//Begin variable initialization
		ClassOrInterfaceType type = new ClassOrInterfaceType().setName(new SimpleName(Constant.STRING_BUFFER));
		NodeList<Expression> arguments = new NodeList<Expression>();
		
		NodeList<Expression> formatArgs = new NodeList<Expression>();
		String localMethodFlag = "OrderVO ";
		String formatTimestamp = " from %1$tm/%1$td/%1$tY %1$tH:%1$tM with delivery at  %1$tm/%1$td/%1$tY %2$tH:%2$tM\n";
		Expression formatTimeExpr = new StringLiteralExpr(formatTimestamp);
		formatArgs.add(
				new BinaryExpr()
				.setLeft(new StringLiteralExpr(localMethodFlag))
				.setRight(
						new BinaryExpr()
						.setLeft(new MethodCallExpr().setName(new SimpleName("getOrderNo")))
						.setRight(formatTimeExpr)
						.setOperator(com.github.javaparser.ast.expr.BinaryExpr.Operator.PLUS))
				.setOperator(com.github.javaparser.ast.expr.BinaryExpr.Operator.PLUS));
		
		String timestampStartedOrderField = "timestampStartedOrder";
		String timestampDeliveredOrderField = "timestampDeliveredOrder";
		formatArgs.add(new NameExpr(timestampStartedOrderField));
		formatArgs.add(new NameExpr(timestampDeliveredOrderField));
		
		Expression staticMethod_format = new MethodCallExpr().setScope(new NameExpr(Constant.STRING)) 
						.setName(Constant.FORMAT).setArguments(formatArgs);
		
		arguments.add(staticMethod_format);
		
		//variable initialization with "new"
		ObjectCreationExpr value = new ObjectCreationExpr();
		value.setType(type);
		value.setArguments(arguments);
		
		Expression initializationExpr = new AssignExpr(target, value, Operator.ASSIGN);
		
		
		Statement varDeclaration = new ExpressionStmt()
										.setExpression(initializationExpr);
		
		// method call txt.append(..)
		Expression scope = new NameExpr(localVar);
		String methodCallName = Constant.APPEND;
		NodeList<Expression> methodCallArgs = new NodeList<Expression>();
		String nameFlag = "of customer: ";
		String customerFieldVar = "customer";
		String getterLastName = "getLastName";
		SimpleName getterFirstName = new SimpleName("getFirstName");
		SimpleName getterId = new SimpleName("getId");
		Expression idFlag = new StringLiteralExpr(", ID of customer: ");
		
		// add arguments for the method
		methodCallArgs.add(
				new BinaryExpr()
				.setLeft(new StringLiteralExpr(nameFlag))
				.setRight(
						new BinaryExpr()
						.setLeft(
								new MethodCallExpr()
								.setScope(new NameExpr(customerFieldVar))
								.setName(getterLastName))
						.setRight(
								new BinaryExpr()
								.setLeft(new StringLiteralExpr(" "))
								.setRight(
										new BinaryExpr()
										.setLeft(new MethodCallExpr()
												.setScope(new NameExpr(customerFieldVar))
												.setName(getterFirstName))
										.setRight(
												new BinaryExpr()
												.setLeft(idFlag)
												.setRight(
														new BinaryExpr()
														.setLeft(new MethodCallExpr()
																.setScope(new NameExpr(customerFieldVar))
																.setName(getterId))
														.setRight(new StringLiteralExpr("\n"))
														.setOperator(com.github.javaparser.ast.expr.BinaryExpr.Operator.PLUS)
														)
												.setOperator(com.github.javaparser.ast.expr.BinaryExpr.Operator.PLUS)
												)
										.setOperator(com.github.javaparser.ast.expr.BinaryExpr.Operator.PLUS)
										)
								.setOperator(com.github.javaparser.ast.expr.BinaryExpr.Operator.PLUS)
								)
						.setOperator(com.github.javaparser.ast.expr.BinaryExpr.Operator.PLUS)
					)
				.setOperator(com.github.javaparser.ast.expr.BinaryExpr.Operator.PLUS)
				);
		
		Statement methodCall = new ExpressionStmt()
				.setExpression(new MethodCallExpr(scope, methodCallName, methodCallArgs));

		// beginn If-Statement
		String shopingBasketField = "shoppingBasket";
		Expression condition = new BinaryExpr()
				.setLeft(new NameExpr(shopingBasketField))
				.setRight(new NullLiteralExpr())
				.setOperator(com.github.javaparser.ast.expr.BinaryExpr.Operator.NOT_EQUALS);
		
		NodeList<Expression> initialization = new NodeList<Expression>();
		String iterator = "i";
		Expression targetExpr = new VariableDeclarationExpr(
				new ClassOrInterfaceType().setName(new SimpleName(Constant.INT_SIMPLE_NAME)), 
				iterator);
		Expression valueExpre = new NullLiteralExpr();
		initialization.add(new AssignExpr(targetExpr, valueExpre, Operator.ASSIGN));
		
		String field_index = "index";
		Expression compare = new BinaryExpr()
								.setLeft(new NameExpr(iterator))
								.setRight(new NameExpr(field_index))
								.setOperator(com.github.javaparser.ast.expr.BinaryExpr.Operator.LESS);
		
		NodeList<Expression> update = new NodeList<Expression>(
				new UnaryExpr(
						new NameExpr(iterator), 
						com.github.javaparser.ast.expr.UnaryExpr.Operator.POSTFIX_INCREMENT));
		
		Expression innerCondition = new BinaryExpr()
				.setLeft(new ArrayAccessExpr(new NameExpr(shopingBasketField), new NameExpr(iterator)))
				.setRight(new NullLiteralExpr())
				.setOperator(com.github.javaparser.ast.expr.BinaryExpr.Operator.NOT_EQUALS);
		
		NodeList<Statement> innerStatements = new NodeList<Statement>();
		NodeList<Expression> appendArguments = new NodeList<Expression>();
		appendArguments.add(
				new MethodCallExpr(
						new ArrayAccessExpr(new NameExpr(shopingBasketField), new NameExpr(iterator)), 
						Constant.TO_STRING));
		Expression expression = new MethodCallExpr(new NameExpr(localVar), Constant.APPEND, appendArguments);
		
		innerStatements.add(new ExpressionStmt(expression));
		innerStatements.add(
				new ExpressionStmt(
						new MethodCallExpr(
								new NameExpr(localVar), 
								Constant.APPEND, 
								new NodeList<Expression>(new StringLiteralExpr("\n")))));
		
		Statement innerthenStmt = new BlockStmt()
								.setStatements(innerStatements);
		Statement body = new BlockStmt()
				.setStatements(
						new NodeList<Statement>(
								new IfStmt()
								.setCondition(innerCondition)
								.setThenStmt(innerthenStmt)));
		
		Statement thenStmt = new BlockStmt()
				.setStatements(
						new NodeList<Statement>(
								new ForStmt(initialization, compare, update, body)));
		Statement ifStmt = new IfStmt()
				.setCondition(condition)
				.setThenStmt(thenStmt);
		
		// prepare the statments inside the method body
		statements.add(varDeclaration);
		statements.add(methodCall);
		statements.add(ifStmt);
		
		// add the statments to the method body
		method.getBody().get().getStatements().addAll(statements);
		
		return method;
	}

}
