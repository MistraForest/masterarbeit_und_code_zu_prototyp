package utils;

import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

import com.github.javaparser.ast.Modifier;
import com.github.javaparser.ast.NodeList;
import com.github.javaparser.ast.body.ClassOrInterfaceDeclaration;
import com.github.javaparser.ast.body.FieldDeclaration;
import com.github.javaparser.ast.body.MethodDeclaration;
import com.github.javaparser.ast.body.Parameter;
import com.github.javaparser.ast.expr.AssignExpr;
import com.github.javaparser.ast.expr.BinaryExpr;
import com.github.javaparser.ast.expr.BinaryExpr.Operator;
import com.github.javaparser.ast.expr.BooleanLiteralExpr;
import com.github.javaparser.ast.expr.CastExpr;
import com.github.javaparser.ast.expr.EnclosedExpr;
import com.github.javaparser.ast.expr.Expression;
import com.github.javaparser.ast.expr.FieldAccessExpr;
import com.github.javaparser.ast.expr.InstanceOfExpr;
import com.github.javaparser.ast.expr.MethodCallExpr;
import com.github.javaparser.ast.expr.NameExpr;
import com.github.javaparser.ast.expr.NullLiteralExpr;
import com.github.javaparser.ast.expr.ThisExpr;
import com.github.javaparser.ast.expr.UnaryExpr;
import com.github.javaparser.ast.expr.VariableDeclarationExpr;
import com.github.javaparser.ast.stmt.BlockStmt;
import com.github.javaparser.ast.stmt.ExpressionStmt;
import com.github.javaparser.ast.stmt.IfStmt;
import com.github.javaparser.ast.stmt.ReturnStmt;
import com.github.javaparser.ast.stmt.Statement;
import com.github.javaparser.ast.type.ClassOrInterfaceType;
import com.github.javaparser.ast.type.ReferenceType;
import com.github.javaparser.ast.type.Type;

import constants.Constant;

/**
 * This class store the reusable element to build the variants of the equals() method
 * @author forest
 *
 */
public class EqualsUtil {

	static com.github.javaparser.ast.expr.UnaryExpr.Operator LOGICAL_OPERATOR = com.github.javaparser.ast.expr.UnaryExpr.Operator.LOGICAL_COMPLEMENT;
	static Statement thenStmtFalse = new ReturnStmt(new BooleanLiteralExpr(false));
	static Statement thenStmtTrue = new ReturnStmt(new BooleanLiteralExpr(true));
	static String variableOther = Constant.OTHER;

	public static MethodDeclaration buildEqualsWithoutInstanceOf(ClassOrInterfaceDeclaration coid, String name,
			String javaFileName) {

		// build method signature
		NodeList<Modifier> modifiers = new NodeList<>();
		modifiers.add(Modifier.publicModifier());
		Type typeBoolean = new ClassOrInterfaceType().setName(Constant.BOOLEAN_SIMPLE_NAME);

		MethodDeclaration method = new MethodDeclaration(modifiers, typeBoolean, name);
		NodeList<Parameter> parameters = new NodeList<>();
		Parameter parameter = new Parameter(new ClassOrInterfaceType().setName(Constant.OBJECT_CLASS),
				Constant.PARAM_OBJ);
		parameters.add(parameter);
		method.setParameters(parameters);
		method.addMarkerAnnotation(Constant.overrideClazz);

		Operator operatorOut = Operator.EQUALS;

		// Begin - build method body
		NodeList<Statement> nodeList = new NodeList<>();

		// compare this-object with parameter
		Statement thenStmtTrue = new ReturnStmt(new BooleanLiteralExpr(true));
		IfStmt ifStmt1 = checkParameterWithThis(parameter, thenStmtTrue, operatorOut);

		// check parameter
		Statement thenStmtFalse = new ReturnStmt(new BooleanLiteralExpr(false));
		IfStmt ifStmt2 = checkParameter(parameter, thenStmtFalse, operatorOut);

		// check instance
		IfStmt clazzCompare = checkInstance(parameter, thenStmtFalse, Operator.NOT_EQUALS);

		Statement assignment = buildAssignStmt(javaFileName, parameter);

		nodeList.add(ifStmt1);
		nodeList.add(ifStmt2);
		nodeList.add(clazzCompare);
		nodeList.add(assignment);

		// Check class attributes for null pointer exception
		for (FieldDeclaration field : coid.getFields()) {

			NodeList<Expression> arguments = new NodeList<>();
			String typeAsString = field.getVariable(0).getTypeAsString();
			String fieldNameAsString = field.getVariable(0).getNameAsString();
			Expression scope = null;

			NameExpr variableNameExpr = getExpr(variableOther);
			NameExpr fieldNameExpr = getExpr(fieldNameAsString);
			FieldAccessExpr fieldAccessExpr = getExpr(variableNameExpr, fieldNameAsString);
			
			if (typeAsString.equals(Constant.INT_SIMPLE_NAME)) {
				continue;
			}

			if (!(typeAsString.equals(Constant.STRING_ARRAYS_CLASS) || typeAsString.equals(Constant.FLOAT))) {

				Expression leftOut = fieldNameExpr;
				Expression rightOut = new NullLiteralExpr();
				operatorOut = Operator.EQUALS;
				Expression conditionOut = getExpr(leftOut, rightOut, operatorOut);

				BinaryExpr conditionIN = getExpr(variableOther, fieldNameAsString);
				Statement thenStmtIN = getIfStmt(conditionIN, thenStmtFalse);

				scope = fieldNameExpr;
				arguments.add(fieldAccessExpr);

				UnaryExpr conditionExpr = getExpr(name, arguments, scope, LOGICAL_OPERATOR);
				IfStmt elseStmt = getIfStmt(conditionExpr, thenStmtFalse);
				BlockStmt thenStmt = new BlockStmt();
				thenStmt.getStatements().add(thenStmtIN);
				IfStmt ifStmtOUT = getIfStmt(conditionOut, thenStmt, elseStmt);

				nodeList.add(ifStmtOUT);
			} else {

				if (typeAsString.equals(Constant.STRING_ARRAYS_CLASS)) {
					arguments.add(fieldNameExpr);
					arguments.add(fieldAccessExpr);

					scope = getExpr(Constant.ARRAYS_CLASS);

					MethodCallExpr methodCallExpr = getExpr(arguments, scope, Constant.EQUALS_METH);
					UnaryExpr conditionExpr = getExpr(methodCallExpr, LOGICAL_OPERATOR);
					IfStmt ifStmt = getIfStmt(conditionExpr, thenStmtFalse);

					nodeList.add(ifStmt);
				}
				if (typeAsString.equals(Constant.FLOAT)) {

					scope = getExpr(Constant.FLOAT_BIG);
					arguments.add(fieldNameExpr);
					NodeList<Expression> rightArguments = new NodeList<>();
					rightArguments.add(fieldAccessExpr);

					MethodCallExpr leftExpr = getExpr(arguments, scope, Constant.FLOAT_TO_INT_BITS);
					MethodCallExpr rightExpr = getExpr(rightArguments, scope, Constant.FLOAT_TO_INT_BITS);
					BinaryExpr conditionExpr = getExpr(leftExpr, rightExpr, Operator.NOT_EQUALS);

					IfStmt ifStmt = getIfStmt(conditionExpr, thenStmtFalse);

//					System.out.println(ifStmt);
					nodeList.add(ifStmt);
				}
			}
		}
		
		Statement returnStmt = new ReturnStmt(new BooleanLiteralExpr(true));

		nodeList.add(returnStmt);

		method.getBody().get().getStatements().addAll(nodeList); // End method body

		return method;

	}

	public static MethodDeclaration buildEqualsWithInstanceOf(ClassOrInterfaceDeclaration coid, String name,
			String javaFileName) {

		// build method signature
		NodeList<Modifier> modifiers = new NodeList<>();
		modifiers.add(Modifier.publicModifier());
		Type typeBoolean = new ClassOrInterfaceType().setName(Constant.BOOLEAN_SIMPLE_NAME);

		MethodDeclaration method = new MethodDeclaration(modifiers, typeBoolean, name);
		NodeList<Parameter> parameters = new NodeList<>();
		Parameter parameter = new Parameter(new ClassOrInterfaceType().setName(Constant.OBJECT_CLASS),
				Constant.PARAM_OBJ);
		parameters.add(parameter);
		method.setParameters(parameters);
		method.addMarkerAnnotation(Constant.overrideClazz);

		Operator operatorOut = Operator.EQUALS;

		// Begin - build method body
		NodeList<Statement> nodeList = new NodeList<>();

		// compare this-object with parameter
		IfStmt ifStmt1 = checkParameterWithThis(parameter, thenStmtTrue, operatorOut);

		// check parameter
		IfStmt ifStmt2 = checkParameter(parameter, thenStmtFalse, operatorOut);

		// check instance
		IfStmt clazzCompare = checkInstanceOf(parameter, thenStmtFalse, LOGICAL_OPERATOR, javaFileName);

		// Assignment
		Statement assignment = buildAssignStmt(javaFileName, parameter);

		nodeList.add(ifStmt1);
		nodeList.add(ifStmt2);
		nodeList.add(clazzCompare);
		nodeList.add(assignment);

		// Check class attributes for null pointer exception
		for (FieldDeclaration field : coid.getFields()) {

			NodeList<Expression> arguments = new NodeList<>();
			String typeAsString = field.getVariable(0).getTypeAsString();
			String fieldNameAsString = field.getVariable(0).getNameAsString();
			
			Expression scope = null;
			com.github.javaparser.ast.expr.UnaryExpr.Operator LOGICAL_OPERATOR = com.github.javaparser.ast.expr.UnaryExpr.Operator.LOGICAL_COMPLEMENT;

			NameExpr variableNameExpr = getExpr(variableOther);
			NameExpr fieldNameExpr = getExpr(fieldNameAsString);
			FieldAccessExpr fieldAccessExpr = getExpr(variableNameExpr, fieldNameAsString);

			if (typeAsString.equals(Constant.INT_SIMPLE_NAME)) {
				continue;
			}

			if (!(typeAsString.equals(Constant.STRING_ARRAYS_CLASS) || typeAsString.equals(Constant.FLOAT))) {

				Expression leftOut = fieldNameExpr;
				Expression rightOut = new NullLiteralExpr();
				operatorOut = Operator.EQUALS;
				Expression conditionOut = getExpr(leftOut, rightOut, operatorOut);

				BinaryExpr conditionIN = getExpr(variableOther, fieldNameAsString);
				Statement thenStmtIN = getIfStmt(conditionIN, thenStmtFalse);

				scope = fieldNameExpr;
				arguments.add(fieldAccessExpr);

				UnaryExpr conditionExpr = getExpr(name, arguments, scope, LOGICAL_OPERATOR);
				IfStmt elseStmt = getIfStmt(conditionExpr, thenStmtFalse);
				BlockStmt thenStmt = new BlockStmt();
				thenStmt.getStatements().add(thenStmtIN);
				IfStmt ifStmtOUT = getIfStmt(conditionOut, thenStmt, elseStmt);

				nodeList.add(ifStmtOUT);
			} else {

				if (typeAsString.equals(Constant.STRING_ARRAYS_CLASS)) {
					arguments.add(fieldNameExpr);
					arguments.add(fieldAccessExpr);

					scope = getExpr(Constant.ARRAYS_CLASS);

					MethodCallExpr methodCallExpr = getExpr(arguments, scope, Constant.EQUALS_METH);
					UnaryExpr conditionExpr = getExpr(methodCallExpr, LOGICAL_OPERATOR);
					IfStmt ifStmt = getIfStmt(conditionExpr, thenStmtFalse);

					nodeList.add(ifStmt);
				}
				if (typeAsString.equals(Constant.FLOAT)) {

					scope = getExpr(Constant.FLOAT_BIG);
					arguments.add(fieldNameExpr);
					NodeList<Expression> rightArguments = new NodeList<>();
					rightArguments.add(fieldAccessExpr);

					MethodCallExpr leftExpr = getExpr(arguments, scope, Constant.FLOAT_TO_INT_BITS);
					MethodCallExpr rightExpr = getExpr(rightArguments, scope, Constant.FLOAT_TO_INT_BITS);
					BinaryExpr conditionExpr = getExpr(leftExpr, rightExpr, Operator.NOT_EQUALS);

					IfStmt ifStmt = getIfStmt(conditionExpr, thenStmtFalse);

//					System.out.println(ifStmt);
					nodeList.add(ifStmt);
				}
			}
		}
		Statement returnStmt = new ReturnStmt(new BooleanLiteralExpr(true));

		nodeList.add(returnStmt);

		method.getBody().get().getStatements().addAll(nodeList); // End method body

		return method;

	}

	private static Statement buildAssignStmt(String javaFileName, Parameter parameter) {
		
		Type type = new ClassOrInterfaceType().setName(javaFileName);
		Expression target = new VariableDeclarationExpr(type, variableOther);
		Expression value = new CastExpr(type, new NameExpr(parameter.getNameAsString()));
		com.github.javaparser.ast.expr.AssignExpr.Operator assignOperator = com.github.javaparser.ast.expr.AssignExpr.Operator.ASSIGN;
		Expression expression = new AssignExpr(target, value, assignOperator);

		Statement assignment = new ExpressionStmt(expression);
		return assignment;
	}

	private static StringBuffer equalsReturnBody(ClassOrInterfaceDeclaration coid) {
		
		List<FieldDeclaration> fields = coid.getFields();
//		
		StringBuffer buffer = new StringBuffer();
		String operator = Operator.AND.asString();
		Collection<Modifier> c = new NodeList<Modifier>();
		c.add(Modifier.privateModifier());
		c.add(Modifier.staticModifier());
		
		List<FieldDeclaration> filteredList = filterIds(fields);
		
		for (FieldDeclaration field : filteredList) {
			NodeList<Expression> arguments = new NodeList<>();
			NameExpr fieldNameAsExpression = field.getVariable(0).getNameAsExpression();
			arguments.add(fieldNameAsExpression);
			String fieldNameAsString = field.getVariable(0).getNameAsString();
			arguments.add(
					new FieldAccessExpr(
							new NameExpr(variableOther), 
							fieldNameAsString));
			
			String typeAsString = field.getVariable(0).getTypeAsString();
			Expression left = null;
			
			if(typeAsString.equals(Constant.STRING_ARRAYS_CLASS) || typeAsString.equals(Constant.FLOAT)) {
				if (typeAsString.equals(Constant.STRING_ARRAYS_CLASS)) 
					left = new MethodCallExpr(new NameExpr(Constant.ARRAYS_CLASS), Constant.EQUALS_METH, arguments);
				
				if (typeAsString.equals(Constant.FLOAT)) {
					
					NodeList<Expression> leftArgs = new NodeList<>();
					NodeList<Expression> rightArgs = new NodeList<>();
					
					leftArgs.add(new NameExpr(fieldNameAsString));
					rightArgs.add(new FieldAccessExpr(new NameExpr(variableOther), fieldNameAsString));
					
					Expression leftOut = new MethodCallExpr(new NameExpr(Constant.FLOAT_BIG), Constant.FLOAT_TO_INT_BITS, leftArgs);
		
					Expression rightOut =  new MethodCallExpr(new NameExpr(Constant.FLOAT_BIG), Constant.FLOAT_TO_INT_BITS, rightArgs);
					left = new EnclosedExpr(getExpr(leftOut, rightOut, Operator.EQUALS));
				}
					
					
			}else
				left = new MethodCallExpr(new NameExpr("Objects"), Constant.EQUALS_METH, arguments);
			
			buffer.append(left).append(" ").append(operator).append(" ");
		}
			buffer.delete(buffer.length()-4, buffer.length());
			
		return buffer;
	}

	private static List<FieldDeclaration> filterIds(List<FieldDeclaration> fields) {
		String suffix_nextId = "Id";
		String suffix_id = "id";
		
		List<FieldDeclaration> filteredList = fields
				.stream()
				.filter(f->{
					String nameAsString = f.getVariable(0).getNameAsString();					
					return !(nameAsString.endsWith(suffix_nextId)||nameAsString.endsWith(suffix_id));
				}).collect(Collectors.toList());
		return filteredList;
	}

	public static MethodDeclaration explicitEqualsWithInstanceOf(ClassOrInterfaceDeclaration coid, String name,
			String javaFileName) {

		// build method signature
		NodeList<Modifier> modifiers = new NodeList<>();
		modifiers.add(Modifier.publicModifier());
		Type typeBoolean = new ClassOrInterfaceType().setName(Constant.BOOLEAN_SIMPLE_NAME);

		MethodDeclaration method = new MethodDeclaration(modifiers, typeBoolean, name);
		NodeList<Parameter> parameters = new NodeList<>();
		Parameter parameter = new Parameter(new ClassOrInterfaceType().setName(Constant.OBJECT_CLASS),
				Constant.PARAM_OBJ);
		parameters.add(parameter);
		method.setParameters(parameters);
		method.addMarkerAnnotation(Constant.overrideClazz);

		Operator operatorOut = Operator.EQUALS;

		// Begin - build method body
		NodeList<Statement> nodeList = new NodeList<>();

		// compare this-object with parameter
		Statement thenStmtTrue = new ReturnStmt(new BooleanLiteralExpr(true));
		IfStmt ifStmt1 = checkParameterWithThis(parameter, thenStmtTrue, operatorOut);

		// check instance
		IfStmt clazzCompare = checkInstanceOf(parameter, thenStmtFalse, LOGICAL_OPERATOR, javaFileName);

		// Assignment
		Statement assignment = buildAssignStmt(javaFileName, parameter);
		Statement returnStmt = new ReturnStmt(new NameExpr(equalsReturnBody(coid).toString()));

		nodeList.add(ifStmt1);
		nodeList.add(clazzCompare);
		nodeList.add(assignment);
		nodeList.add(returnStmt);

		method.getBody().get().getStatements().addAll(nodeList); // End method body

		return method;
		
	}

	public static MethodDeclaration explicitEqualsWithoutInstanceOf(ClassOrInterfaceDeclaration coid, String name,
			String javaFileName) {

		// build method signature
		NodeList<Modifier> modifiers = new NodeList<>();
		modifiers.add(Modifier.publicModifier());
		Type typeBoolean = new ClassOrInterfaceType().setName(Constant.BOOLEAN_SIMPLE_NAME);

		MethodDeclaration method = new MethodDeclaration(modifiers, typeBoolean, name);
		NodeList<Parameter> parameters = new NodeList<>();
		Parameter parameter = new Parameter(new ClassOrInterfaceType().setName(Constant.OBJECT_CLASS),
				Constant.PARAM_OBJ);
		parameters.add(parameter);
		method.setParameters(parameters);
		method.addMarkerAnnotation(Constant.overrideClazz);

		Operator operatorOut = Operator.EQUALS;

		// Begin - build method body
		NodeList<Statement> nodeList = new NodeList<>();

		// compare this-object with parameter
		Statement thenStmtTrue = new ReturnStmt(new BooleanLiteralExpr(true));
		IfStmt ifStmt1 = checkParameterWithThis(parameter, thenStmtTrue, operatorOut);

		// check parameter
		IfStmt ifStmt2 = checkParameter(parameter, thenStmtFalse, operatorOut);

		// check instance
		IfStmt clazzCompare = checkInstance(parameter, thenStmtFalse, Operator.NOT_EQUALS);

		// Assignment
		Statement assignment = buildAssignStmt(javaFileName, parameter);
		Statement returnStmt = new ReturnStmt(new NameExpr(equalsReturnBody(coid).toString()));

		nodeList.add(ifStmt1);
		nodeList.add(ifStmt2);
		nodeList.add(clazzCompare);
		nodeList.add(assignment);
		nodeList.add(returnStmt);

		method.getBody().get().getStatements().addAll(nodeList); // End method body

		return method;
	}

	private static IfStmt checkParameter(Parameter parameter, Statement thenStmtFalse, Operator operator2) {
		Expression left2 = new NameExpr(parameter.getNameAsString());
		Expression right2 = new NullLiteralExpr();

		Expression condition2 = getExpr(left2, right2, operator2);

		IfStmt ifStmt2 = getIfStmt(condition2, thenStmtFalse);
		return ifStmt2;
	}

	private static IfStmt checkParameterWithThis(Parameter parameter, Statement thenStmtFalse, Operator operator2) {
		Expression left2 = getExpr();
		Expression right2 = getExpr(parameter.getNameAsString());

		Expression condition2 = getExpr(left2, right2, operator2);

		IfStmt ifStmt2 = getIfStmt(condition2, thenStmtFalse);
		return ifStmt2;
	}

	private static IfStmt checkInstance(Parameter parameter, Statement thenStmtFalse, Operator operator2) {
		Expression left = new MethodCallExpr().setName(Constant.GET_CLASS);
		Expression right = new MethodCallExpr(getExpr(parameter.getNameAsString()), Constant.GET_CLASS);
		Expression conditionClazz = getExpr(left, right, operator2);

		IfStmt clazzCompare = getIfStmt(conditionClazz, thenStmtFalse);
		return clazzCompare;
	}

	private static IfStmt checkInstanceOf(Parameter parameter, Statement thenStmtFalse,
			com.github.javaparser.ast.expr.UnaryExpr.Operator operator2, String referenceType) {
		
		Expression expression = getExpr(parameter.getNameAsString());
		ReferenceType type = new ClassOrInterfaceType().setName(referenceType);
		InstanceOfExpr instanceOf = new InstanceOfExpr(expression, type);
		UnaryExpr condition = new UnaryExpr(new EnclosedExpr(instanceOf), operator2);

		IfStmt clazzCompare = getIfStmt(condition, thenStmtFalse);
		return clazzCompare;
	}

	private static UnaryExpr getExpr(Expression methodCallExpr,
			com.github.javaparser.ast.expr.UnaryExpr.Operator operator2) {
		return new UnaryExpr(methodCallExpr, operator2);
	}

	private static MethodCallExpr getExpr(NodeList<Expression> arguments, Expression scope, String name) {
		return new MethodCallExpr(scope, name, arguments);
	}

	private static FieldAccessExpr getExpr(NameExpr nameExpr, String fieldNameAsString) {
		return new FieldAccessExpr(nameExpr, fieldNameAsString);

	}

	private static ThisExpr getExpr() {
		return new ThisExpr();
	}

	private static NameExpr getExpr(String variableName) {
		return new NameExpr(variableName);
	}

	private static UnaryExpr getExpr(String name, NodeList<Expression> arguments, Expression scope,
			com.github.javaparser.ast.expr.UnaryExpr.Operator LOGICAL_OPERATOR) {
		return new UnaryExpr().setExpression(new MethodCallExpr(scope, name, arguments)).setOperator(LOGICAL_OPERATOR);
	}

	// outer if statement
	private static BinaryExpr getExpr(Expression leftOut, Expression rightOut, Operator operatorOut) {
		return new BinaryExpr(leftOut, rightOut, operatorOut);
	}

	// inner if statement
	private static BinaryExpr getExpr(String variableName, String fieldNameAsString) {
		BinaryExpr conditionIN = new BinaryExpr(new FieldAccessExpr(getExpr(variableName), fieldNameAsString),
				new NullLiteralExpr(), Operator.NOT_EQUALS);
		return conditionIN;
	}

	private static IfStmt getIfStmt(Expression condition, Statement thenStmt) {
		return new IfStmt().setCondition(condition).setThenStmt(thenStmt);
	}

	private static IfStmt getIfStmt(Expression condition, BlockStmt thenStmt, Statement elseStmt) {
		return getIfStmt(condition, thenStmt).setElseStmt(elseStmt);
	}

}
