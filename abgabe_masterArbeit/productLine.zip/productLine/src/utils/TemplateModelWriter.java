package utils;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.logging.Logger;

import com.github.javaparser.ast.CompilationUnit;

import freemarker.cache.FileTemplateLoader;
import freemarker.template.Configuration;
import freemarker.template.Template;
import freemarker.template.TemplateException;
import freemarker.template.TemplateExceptionHandler;
import freemarker.template.Version;

public class TemplateModelWriter {
	
	Logger logger = Logger.getLogger(this.getClass().getSimpleName());

	private static TemplateModelWriter templateModel = new TemplateModelWriter();
	private Template template;

	private static Map<String, Object> compilationModel = new HashMap<String, Object>();
	private final String TEMPLATE_FILE = "compilationUnit.ftl";

	private TemplateModelWriter() {
		initTemplate();
	}

	public void initTemplate() {

		Configuration configuration = new Configuration(new Version(2, 3, 31));

		configuration.setIncompatibleImprovements(new Version(2, 3, 31));
		configuration.setDefaultEncoding("UTF-8");
		configuration.setLocale(Locale.GERMAN);
		configuration.setTemplateExceptionHandler(TemplateExceptionHandler.RETHROW_HANDLER);

		FileTemplateLoader templateLoader = null;

		try {
			templateLoader = new FileTemplateLoader(new File("src/utils/template"));
			configuration.setTemplateLoader(templateLoader);

			template = configuration.getTemplate(TEMPLATE_FILE);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	/**
	 * Is use to get a single instance of this class
	 * @param compilationUnit the compilation unit to be written in a directory
	 * @return the instance of this class
	 */
	public static TemplateModelWriter getTemplateModel(CompilationUnit compilationUnit) {
		compilationModel.put("compilationUnit", compilationUnit);
		return templateModel;
	}

	/**
	 * The method write a java file into a given directory
	 * @param directory the destination directory 
	 * @param clazzName the java file name
	 */
	public void writeFileTo(String directory, String clazzName) {

		Writer file = Writer.nullWriter();

		new File(directory).mkdirs();
		try {
			file = new FileWriter(new File(directory+clazzName));
		} catch (IOException e) {
			e.printStackTrace();
		}
		try {
			template.process(compilationModel, file);
		} catch (TemplateException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		try {
			file.flush();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
