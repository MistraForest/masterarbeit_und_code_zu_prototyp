package utils;

import java.util.List;
import java.util.Properties;

import com.github.javaparser.ast.Modifier;
import com.github.javaparser.ast.NodeList;
import com.github.javaparser.ast.body.ClassOrInterfaceDeclaration;
import com.github.javaparser.ast.body.FieldDeclaration;
import com.github.javaparser.ast.body.MethodDeclaration;
import com.github.javaparser.ast.expr.Expression;
import com.github.javaparser.ast.expr.FieldAccessExpr;
import com.github.javaparser.ast.expr.MethodCallExpr;
import com.github.javaparser.ast.expr.NameExpr;
import com.github.javaparser.ast.expr.ThisExpr;
import com.github.javaparser.ast.expr.TypeExpr;
import com.github.javaparser.ast.type.ClassOrInterfaceType;

import constants.Constant;
import utils.exceptions.InvalidAttributeNumberException;

/**
 * This class is an element of the core asset to be reused in features, which will generate e toString() method
 * @author forest
 *
 */
public class ToStringUtil {
	
	static Properties prop = PropertiesUtil.readPropertiesFile("resources/general.properties");
	
	private static final String DATE_OF_BIRTH = prop.getProperty("date_of_birth");
	private static final String DOB_TO_STRING = prop.getProperty("dob_to_string");

	public static StringBuffer toStringBody(ClassOrInterfaceDeclaration coid, int attributNumber, String javaFileName,
			String methodName) throws InvalidAttributeNumberException {

		List<FieldDeclaration> fields = coid.getFields();
		StringBuffer buffer = new StringBuffer();
		
		buffer.append(Constant.DOUBLE_QUOTE + javaFileName + Constant.SQUARED_BRACKET_OPEN + Constant.DOUBLE_QUOTE);

		if (attributNumber < 0 || attributNumber > fields.size()) {
			throw new InvalidAttributeNumberException(javaFileName+": Number of attributs " + attributNumber + " is invalid. Max size = "+fields.size() );
		}
		for (int i = 0; i < attributNumber; i++) {

			if (fields.get(i).getModifiers().contains(Modifier.staticModifier())) {
				continue;
			}
			if (i == fields.size()) {
				buildTostring(coid, methodName, fields, buffer, i - 1);
			} else {
				buildTostring(coid, methodName, fields, buffer, i);
			}
		}

		buffer.deleteCharAt(buffer.lastIndexOf(Constant.DOUBLE_QUOTE));
		buffer.deleteCharAt(buffer.lastIndexOf(Constant.COMMA));

		buffer.append(Constant.SQUARED_BRACKET_CLOSE + Constant.DOUBLE_QUOTE);
		return buffer;
	}

	private static void buildTostring(ClassOrInterfaceDeclaration coid, String methodName,
			List<FieldDeclaration> fields, StringBuffer buffer, int index) {
		
		NodeList<Expression> arguments = new NodeList<>();
		String node = fields.get(index).getVariable(0).getNameAsString();
		buffer.append(Constant.PLUS + Constant.DOUBLE_QUOTE + node + Constant.EQUAL_AND_QUOTE + Constant.PLUS);

		if (fields.get(index).getVariable(0).getTypeAsString().equals(Constant.STRING_ARRAYS_CLASS)) {

			arguments.add(new NameExpr(node));

			buffer.append(new MethodCallExpr(new TypeExpr(new ClassOrInterfaceType().setName(Constant.ARRAYS_CLASS)),
					methodName, arguments))
					.append(Constant.PLUS + Constant.DOUBLE_QUOTE + Constant.COMMA + Constant.DOUBLE_QUOTE);
		} else {
			List<MethodDeclaration> methodDeclaration = coid.getMethodsByName(DOB_TO_STRING);
			
			if (!methodDeclaration.isEmpty() && node.equals(DATE_OF_BIRTH)) {
				buffer.append(new MethodCallExpr(new ThisExpr(), methodDeclaration.get(0).getNameAsString()));
			}else
				buffer.append(new FieldAccessExpr(new ThisExpr(), node));
			
			buffer.append(Constant.PLUS + Constant.DOUBLE_QUOTE + Constant.COMMA + Constant.DOUBLE_QUOTE);
		}
	}

	public static void removeOldMethod(ClassOrInterfaceDeclaration coid, String methodName) {
		coid.getMembers().removeAll(coid.getMethodsByName(methodName));
	}

}
