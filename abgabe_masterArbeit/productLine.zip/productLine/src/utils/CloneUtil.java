package utils;

import com.github.javaparser.ast.Modifier;
import com.github.javaparser.ast.NodeList;
import com.github.javaparser.ast.body.ClassOrInterfaceDeclaration;
import com.github.javaparser.ast.body.MethodDeclaration;
import com.github.javaparser.ast.expr.CastExpr;
import com.github.javaparser.ast.expr.MethodCallExpr;
import com.github.javaparser.ast.expr.SuperExpr;
import com.github.javaparser.ast.stmt.ReturnStmt;
import com.github.javaparser.ast.type.ClassOrInterfaceType;
import com.github.javaparser.ast.type.ReferenceType;
import com.github.javaparser.ast.type.Type;

import constants.Constant;

/**
 * This class store the model to build and generate the clone() method - an element of core asset
 * @author forest
 *
 */
public class CloneUtil {

	
	public static MethodDeclaration buildCloneMethod(ClassOrInterfaceDeclaration coid, String name,
			String javaFileName) {


		// build method signature
		NodeList<Modifier> modifiers = new NodeList<>();
		modifiers.add(Modifier.protectedModifier());
		Type type = new ClassOrInterfaceType().setName(javaFileName);

		MethodDeclaration method = new MethodDeclaration(modifiers, type, name);
		NodeList<ReferenceType> thrownExceptions = new NodeList<>();
		thrownExceptions.add(new ClassOrInterfaceType().setName(Constant.CLONE_EXCEPTION));
		method.setThrownExceptions(thrownExceptions);
		method.addMarkerAnnotation(Constant.overrideClazz);
		
		method.getBody().get().getStatements()
										.add(
												new ReturnStmt(
														new CastExpr(
																new ClassOrInterfaceType()
																.setName(javaFileName), 
																new MethodCallExpr(new SuperExpr(), name))));
		
		return method;
	}

}
