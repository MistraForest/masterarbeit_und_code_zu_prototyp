package utils;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import com.github.javaparser.ast.NodeList;
import com.github.javaparser.ast.body.BodyDeclaration;
import com.github.javaparser.ast.body.ClassOrInterfaceDeclaration;
import com.github.javaparser.ast.body.ConstructorDeclaration;
import com.github.javaparser.ast.body.Parameter;
import com.github.javaparser.ast.expr.Expression;
import com.github.javaparser.ast.expr.IntegerLiteralExpr;
import com.github.javaparser.ast.expr.MethodCallExpr;
import com.github.javaparser.ast.expr.NameExpr;
import com.github.javaparser.ast.expr.NullLiteralExpr;
import com.github.javaparser.ast.expr.ThisExpr;
import com.github.javaparser.ast.stmt.BlockStmt;
import com.github.javaparser.ast.stmt.ExpressionStmt;
import com.github.javaparser.ast.stmt.Statement;

import constants.Constant;
import utils.exceptions.InvalidParameterNumber;

/**
 * This class store the model to build and generate a constructor - an element of core asset
 * @author forest
 *
 */
public class ConstructorUtil {

	/**
	 * 
	 * @param numberOfParameter    positive integer less than the number of parameter of the
	 *             constructor with the highest number of parameters. It represent
	 *             the number of parameter to build the new constructor
	 * @param coid the given ClassOrInterfaceDeclaration
	 * @throws InvalidParameterNumber Thrown when the number of parameters is out of range.
	 */
	public static void addNewConstructor(int numberOfParameter, ClassOrInterfaceDeclaration coid) throws InvalidParameterNumber {

		ConstructorDeclaration constructorDeclaration = highestParamNumberConstructor(coid);

		String[] parameterTypes = getParameterTypes(constructorDeclaration);

		Optional<ConstructorDeclaration> constructorByParameterTypes = coid
				.getConstructorByParameterTypes(parameterTypes);
		if (constructorByParameterTypes.isEmpty()) {
			return;
		}
		ConstructorDeclaration constructorHelper = constructorByParameterTypes.get();
		BodyDeclaration<?> afterThisNode = constructorHelper;

		if (numberOfParameter < 0 || numberOfParameter > parameterTypes.length) {
			throw new InvalidParameterNumber("the number of parameter " + numberOfParameter + " is invalid");
		}

		Parameter[] parametersArray = new Parameter[numberOfParameter];
		NodeList<Expression> arguments = buildThisArguments(numberOfParameter, parameterTypes, constructorHelper, parametersArray);
		NodeList<Parameter> parameters = buildParameters(parametersArray);

		NodeList<Statement> statements = buildStmts(arguments);
		BlockStmt body = new BlockStmt(statements);

		BodyDeclaration<?> newNode = buildNewNode(constructorHelper, parameters, body);
		coid.getMembers().addAfter(newNode, afterThisNode);
	}

	private static ConstructorDeclaration highestParamNumberConstructor(ClassOrInterfaceDeclaration coid) {
		List<ConstructorDeclaration> constructors = coid.getConstructors().stream()
				.filter(f -> f.getParameters().size() >= 0 && !coid.getConstructors().isEmpty())
				.collect(Collectors.toList());

		int counter = (int) coid.getConstructors().stream().count();
		int[] myConst = new int[counter];
		ConstructorDeclaration constructorDeclaration = new ConstructorDeclaration();

		if (!constructors.isEmpty()) {
			ConstructorDeclaration[] copy = sortConstructorByParameterNumber(constructors, counter, myConst);

			constructorDeclaration = findWithHighestParamNumber(copy);// findWithHighParamNumber(myConst,
		} // copy);
		return constructorDeclaration;
	}

	private static ConstructorDeclaration[] sortConstructorByParameterNumber(List<ConstructorDeclaration> constructors,
			int counter, int[] myConst) {
		ConstructorDeclaration[] copy = new ConstructorDeclaration[(int) counter];
		for (int i = 0; i < constructors.size(); i++) {
			myConst[i] = constructors.get(i).getParameters().size();
			copy[i] = constructors.get(i);
		}
		Arrays.sort(myConst);
		return copy;
	}

	private static ConstructorDeclaration findWithHighestParamNumber(ConstructorDeclaration[] copy) {
		ConstructorDeclaration result = copy[0];
		return result;
	}

	private static BodyDeclaration<?> buildNewNode(ConstructorDeclaration constructorHelper,
			NodeList<Parameter> parameters, BlockStmt body) {
		BodyDeclaration<?> newNode = new ConstructorDeclaration(constructorHelper.getNameAsString())
				.setParameters(parameters).setBody(body);
		return newNode;
	}

	private static NodeList<Statement> buildStmts(NodeList<Expression> arguments) {
		Statement nodeStmt = new ExpressionStmt(new MethodCallExpr().setName(new ThisExpr().toString()).setArguments(arguments));

		NodeList<Statement> statements = new NodeList<>();
		statements.add(nodeStmt);
		return statements;
	}

	private static NodeList<Parameter> buildParameters(Parameter[] parametersArray) {
		NodeList<Parameter> parameters = new NodeList<>();
		for (Parameter parameter : parametersArray) {
			parameters.add(parameter);
		}
		return parameters;
	}

	private static NodeList<Expression> buildThisArguments(int n, String[] parameterTypes,
			ConstructorDeclaration constructorHelper, Parameter[] parametersArray) {

		NodeList<Expression> arguments = new NodeList<>();
		for (int i = 0; i < parameterTypes.length; i++) {

			if (i < n) {
				Parameter parameter = constructorHelper.getParameter(i);
				parametersArray[i] = parameter;
				arguments.add(new NameExpr(parameter.getNameAsString()));
			} else {
				boolean initFloat = constructorHelper.getParameter(i).getTypeAsString().equals(Constant.FLOAT);
	
				arguments.add(initFloat?new IntegerLiteralExpr("0.0f"):new NullLiteralExpr());
			}
				
		}
		return arguments;
	}

	private static String[] getParameterTypes(ConstructorDeclaration constructorDeclaration) {
		NodeList<Parameter> parameters = constructorDeclaration.getParameters();
		String[] parameterTypes = new String[parameters.size()];
		for (int i = 0; i < parameters.size(); i++) {
			parameterTypes[i] = parameters.get(i).getType().asString();
		}
		return parameterTypes;
	}

}
