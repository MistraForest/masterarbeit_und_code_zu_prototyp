package utils;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;

import com.github.javaparser.ast.CompilationUnit;

/**
 * This class will create an extra directory for the generated code by
 * keeping logical relationship in place.
 * @author forest
 *
 */
public class DirCreatorUtil {

	public static final String U1 = "u1/";
	public static final String U2 = "u2/";
	public static final String U3 = "u3/";
	public static final String GUI = "pizzaProntoGUI";
	public static final String TEST = "test/";

	public static void createDir(String directory) {
		new File(directory).mkdirs();
	}

	public static String getPackageName(CompilationUnit compilationUnit) {
		return compilationUnit.getPackageDeclaration().get().getNameAsString();
	}

	public static String buildDir(CompilationUnit cu) {
		String packageName = getPackageName(cu);

		String directory = packageName.concat(".").replace(".", "/");
		return directory;
	}

	public static void deleteDir(String pathname) {
		try {
			File file = new File(pathname);
			file.setWritable(true);
			file.setExecutable(true);
			if (file.exists())
				FileUtils.deleteDirectory(file);
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

}
