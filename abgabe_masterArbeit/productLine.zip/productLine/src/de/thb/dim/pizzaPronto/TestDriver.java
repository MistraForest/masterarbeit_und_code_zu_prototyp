package de.thb.dim.pizzaPronto;

import java.awt.Color;
import java.io.File;
import java.io.IOException;
import java.nio.file.FileVisitResult;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.SimpleFileVisitor;
import java.nio.file.attribute.BasicFileAttributes;
import java.time.LocalDate;
import java.time.Period;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;
import java.util.stream.Stream;

/**
 * Testdriver of ChefVO, CustomerVO and PizzaVO as well as LocalDate
 * 
 * Special assert statements are used for testing <br>
 * 
 * @author Gabriele Schmidt
 * @version 1.0 09.03.2022
 */
public class TestDriver {
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		LocalDate today = LocalDate.now();
		
		LocalDate dob = LocalDate.of(1990, 5, 24);
		
		//Testing of constructors
		ChefVO myChef = new ChefVO("Bocusen", "Bruno", Color.BLUE);
//		CustomerVO myCustomer = new CustomerVO("Mueller", "Monika", "weiblich", LocalDate.of(1997, 1, 1));
//		CustomerVO customer = new CustomerVO();
		CustomerVO customer1 = new CustomerVO("Martin","Mampf","maennlich",dob);
//		CustomerVO customer2 = new CustomerVO("Maier","Marta","weiblich",dob);
		PizzaVO myPizza = new PizzaVO("Salami", new String[]{"Salami", "Tomate", "Kaese", "Zwiebel"}, 7.5f);
		
		String s[] = {"Salami", "Tomate", "Kaese", "Zwiebel"};
//		PizzaVO myPizza2 = new PizzaVO("Salami", s, 7.5f);
		
		//System.out.println(myChef);
		//System.out.println(today); //What is the difference to the output of myChef?
		//System.out.println(customer2);
		//System.out.println(myPizza);
		
		//System.out.println(customer1.dobToString());
	
		printKoch(myChef);
		//System.out.println(dob);

		printKunde(customer1);
		customer1.setDateOfBirth(LocalDate.of(1990, 11, 24));
//		printKunde(customer1);
		
//		printKunde(customer2);
		listDir("beispielUebung/exercise_01_SampleSolution/gui/", 0);
		try {
//			walkToDir("beispielUebung/exercise_01_SampleSolution/gui/");
			Set<String> files = listFilesUsingFileWalkAndVisitor("beispielUebung/exercise_01_SampleSolution/gui/");
			int count =1;
			for (String fileName : files) {
//				System.out.println("fileName: "+count+++" - "+fileName);
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	public static void walkToDir(String dir) throws IOException {
        try (Stream<Path> paths = Files.walk(Paths.get(dir))) {
//            paths.filter(Files::isRegularFile)
//                    .forEach(System.out::println);
//            paths.filter(Files::isDirectory).forEach(System.out::println);
        }
    }
	
	public static void listDir(String path, int level) {
		System.out.println("\n***********\tListDir-Method\t***********\n");
		File dir = new File(path);
		File[] firstLevelFiles = dir.listFiles();
		int count =1;
		if(firstLevelFiles != null && firstLevelFiles.length > 0) {
			for(File file : firstLevelFiles) {
				for(int i = 0 ; i<level;i++) {
//					System.out.print("\t");
				}
				if(file.isDirectory()) {
//					System.out.println(file.getName()+"/");
					listDir(file.getAbsolutePath(), level+1);
				}else {
//					System.out.println(count++ +" - "+file.getName());
				}
			}
		}
	}
	
	public static Set<String> listFilesUsingFileWalkAndVisitor(String dir) throws IOException {
		System.out.println("\n***********\tlistFilesUsingFileWalkAndVisitor-Method\t***********\n");
		Set<String> fileList = new HashSet<>();
	    Files.walkFileTree(Paths.get(dir), new SimpleFileVisitor<Path>() {
	        @Override
	        public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) {
	            if (!Files.isDirectory(file)) {
	                fileList.add(file.getFileName().toString());
	            }else {
//	            	System.out.println(file.getFileName()+"/");
	            }
	            return FileVisitResult.CONTINUE;
	        }
	    });
	    return fileList;
	}
	
	// helper methods for formating of the output
	private static void printKunde(CustomerVO kunde) {
//		System.out.printf("%s, %s: %s\n",kunde.getLastName(), kunde.getFirstName(), kunde.dobToString());
	}
	
	private static void printKoch(ChefVO koch) {
//		System.out.printf("%s, %s\n",koch.getLastName(), koch.getFirstName());
	}
}
