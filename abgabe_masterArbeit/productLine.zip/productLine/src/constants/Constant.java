package constants;

import java.time.LocalDate;
import java.time.Period;

public class Constant {

	public static final String COMMA = ",  ";
	public static final String EQUAL_AND_QUOTE = "= \"";
	public static final String PLUS = "+";
	public static final String SQUARED_BRACKET_CLOSE = "]";
	public static final String SQUARED_BRACKET_OPEN = " [";
	public static final String DOUBLE_QUOTE = "\"";
	public static final String SLASH = "/";
	public static final String POINT = ".";

	public static final Class<Override> overrideClazz = Override.class;
	public static final String STRING_ARRAYS_CLASS = String[].class.getSimpleName();
	public static final String FLOAT = float.class.getSimpleName();
	public static final String FLOAT_BIG = Float.class.getSimpleName();
	public static final String BOOLEAN_SIMPLE_NAME = boolean.class.getSimpleName();
	public static final String INT_SIMPLE_NAME = int.class.getSimpleName();
	public static final String SHORT = short.class.getSimpleName();
	public static final String PERIOD = Period.class.getSimpleName();
	public static final String LOCAL_DATE = LocalDate.class.getSimpleName();

	//Method's call
	public static final String CONTAINS = "contains";
	public static final String TO_STRING = "toString";
	public static final String STRING = "String";
	public static final String STRING_BUFFER = "StringBuffer";
	public static final String VALUE_OF = "valueOf";
	public static final String FORMAT = "format";
	public static final String OF = "of";
	public static final String NOW = "now";
	public static final String GET_YEARS = "getYears";
	public static final String GET_CLASS = "getClass";
	public static final String OBJECT_CLASS = "Object";
	public static final String OBJECTS = "Objects";
	public static final String ARRAYS_CLASS = "Arrays";
	public static final String EQUALS_METH = "equals";//hashCode
	public static final String HASH_CODE = "hashCode";
	public static final String BETWEEN = "between";
	public static final String APPEND = "append";

	public static final String ASSERT_FALSE = "assertFalse";
	public static final String ASSERT_TRUE = "assertTrue";
	public static final String ASSERT_EQUALS = "assertEquals";
	public static final String ASSERT_NOT_EQUALS = "assertNotEquals";
	public static final String ASSERT_NOT_NULL = "assertNotNull";

	public static final String JAVA = ".java";
	public static final String CLONE = "clone";
	public static final String OTHER = "other";
	public static final String PARAM_OBJ = "obj";
	public static final String EXCEPTION_VAR = "e";

	public static final String FLOAT_TO_INT_BITS = "floatToIntBits";
	public static final String HASH = "hash";
	public static final String NULL_POINTER_EXCEPTION = "NullPointerException";
	public static final String CLONE_EXCEPTION = CloneNotSupportedException.class.getSimpleName();


}
