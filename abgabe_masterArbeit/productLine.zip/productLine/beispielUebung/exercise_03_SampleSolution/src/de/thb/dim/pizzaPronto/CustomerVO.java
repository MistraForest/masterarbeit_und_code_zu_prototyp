package de.thb.dim.pizzaPronto;
import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;

/**
 * CustomerVO represents objects of customer.
 * @author Robert Fischer, Gabriele Schmidt
 * @version 3.0
 *
 */
public class CustomerVO  {
	
	private static int nextId = 0;
	private int id;
	
	private String lastName;
	private String firstName;
	private String gender;
	private LocalDate dateOfBirth;
	
	private OrderVO order;

	/**
	 * initializing constructor
	 * Initialize all instance attributes with values. 
	 * 
	 * @param lastName - Customer's second name
	 * @param firstName - Customer's first name
	 * @param gender - Customer's gender
	 * @param dateOfBirth - Customer's date of birth
	 * 
	 */
	public CustomerVO(String lastName, String firstName, String gender, LocalDate dob) {
		id = nextId;
		nextId++;
		setLastName(lastName);
		setFirstName(firstName);
		setGender(gender);
		setDateOfBirth(dob);

	}
	
	/**
	 * initializing constructor
	 * Initialize all instance attributes with values. 
	 * 
	 * @param lastName - Customer's second name
	 * @param firstName - Customer's first name
	 * @param dateOfBirth - Customer's date of birth
	 * 
	 */
	public CustomerVO(String lastName, String firstName, LocalDate dob) {
		this(lastName, firstName, null, dob);

	}

	/**
	 * default constructor 
	 * calls initializing constructor with default values for instance attributes
	 * 
	 */
	public CustomerVO() {
		this(null, null, null, null);
		
	}
	
	/**
	 * the age of customer is a drived attribute, i.e. age is only calculated 
	 * in the method and is not a instance variable
	 * 
	 * @return age - short
	 */
	public short calculateAge() {
		short alter = -1;
		Period age;
		LocalDate today = LocalDate.now();

		if (dateOfBirth != null) {
			age = Period.between(dateOfBirth, today);
			alter = (short) age.getYears();
		}
		return alter;
	}
	
	/**
	 * Checks whether there is a current orderVO or not
	 * 
	 * @return true => orderVO available, false => there is no orderVO
	 * 
	 */
	public boolean hasOrder() {
		if (order != null) return true;
		else return false;
	}
	
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((dateOfBirth == null) ? 0 : dateOfBirth.hashCode());
		result = prime * result + ((firstName == null) ? 0 : firstName.hashCode());
		result = prime * result + ((lastName == null) ? 0 : lastName.hashCode());
		return result;
	}
	
	

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CustomerVO other = (CustomerVO) obj;
		if (dateOfBirth == null) {
			if (other.dateOfBirth != null)
				return false;
		} else if (!dateOfBirth.equals(other.dateOfBirth))
			return false;
		if (firstName == null) {
			if (other.firstName != null)
				return false;
		} else if (!firstName.equals(other.firstName))
			return false;
		if (lastName == null) {
			if (other.lastName != null)
				return false;
		} else if (!lastName.equals(other.lastName))
			return false;
		return true;
	}


	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return String.format("Customer:\n" + "\tId: %d\n" + "\tName: %s, %s\n"
				+ "\tGender: %s\n" + "\tDate of Birth: %s\n" + "\tAge: %d\n",
				this.getId(), this.getLastName(), this.getFirstName(),
				this.getGender(), this.dobToString(),
				this.calculateAge(),
				hasOrder());
	}
	
	
	/**
	 * Returns the birth date in human-readable form.
	 * 
	 * @return - the complete string
	 *  
	 */
	private String dobToString() {
		return dateOfBirth.format(DateTimeFormatter.ofPattern("dd MMM yyyy"));
	}
	
	//Setter getter
	//only getter für nextID and id
	public static int getNextId() {
		return nextId;
	}
	
	public int getId() {
		return id;
	}

	

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}


	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}
	

	public LocalDate getDateOfBirth() {
		return dateOfBirth;
	}

	

	/**
	 * older than 17 years else dateOfBirth is set null
	 * 
	 * @param dateOfBirth
	 *        -     java.time.LocalDate
	 */
	public void setDateOfBirth(LocalDate dob) {
		this.dateOfBirth = dob;
		if (this.calculateAge() < 18)
			this.dateOfBirth = null;
	}
	
	public OrderVO getOrder() {
		return order;
	}

	public void setOrder(OrderVO orderVO) {
		this.order = orderVO;
	}
	

	
} // end of class