package de.thb.dim.pizzaPronto;
import java.time.LocalDate;
import java.time.LocalDateTime;

/**
 * Die Klasse zum Testen von OrderVO
 * 
 * 
 * @author Gabriele Schmidt
 * 
 * @version 1.0
 * 
 */
public class TestDriverOrder {

	public static void main(String[] args) {
		PizzaVO[] pizzen = new PizzaVO[6];

		pizzen[0] = new PizzaVO("Popeye", new String[] { "Schinken", "Spinat", "Champignon", "Ei" }, 7.00f);
		pizzen[1] = new PizzaVO("Popeye", new String[] { "Schinken", "Spinat", "Champignon", "Ei" }, 8.90f);
		pizzen[2] = new PizzaVO("Hawaii", new String[] { "Schinken", "Ananas", "Curry" }, 5.80f);
		pizzen[3] = new PizzaVO("Hawaii", new String[] { "Schinken", "Ananas", "Curry" }, 7.40f);
		pizzen[4] = new PizzaVO("Prima", new String[] { "Schinken", "Salami", "Zwiebeln", "Ei" }, 7.00f);
		pizzen[5] = new PizzaVO("Prima", new String[] { "Schinken", "Salami", "Zwiebeln", "Ei" }, 8.90f);

		CustomerVO customer = new CustomerVO("Mampf", "Manfred", "männlich", LocalDate.of(1990, 6, 28));
		OrderVO orderVO = new OrderVO(LocalDateTime.now(),  customer);
		customer.setOrder(orderVO);

		for (int i = 0; i < pizzen.length; i++) {
			orderVO.addDish(pizzen[i]);
		}

		System.out.println(orderVO.getNumberOfDishes());

		System.out.println(customer.toString());

		System.out.println(orderVO.toString());
		
		System.out.println("Size of shoppingbasket: " + orderVO.getShoppingBasket().length);
		System.out.println();
		// try to delete too much pizzas What will happen with number of dishes, i.e. index?
		for (int i = 0; i < orderVO.getShoppingBasket().length; i++) {
			orderVO.deleteDish();
			System.out.println(orderVO.getNumberOfDishes());
		}
		System.out.println();
		// try to add too much pizzas What will happen with number of dishes, i.e. index?
		for (int i = 0; i <= OrderVO.getMAX_DISHES(); i++) {
			orderVO.addDish(pizzen[0]);
			System.out.println(orderVO.getNumberOfDishes());
		}
		System.out.println();
		//Number of objects of OrderVO increases
		System.out.println(orderVO.getOrderNo());
		OrderVO orderVO2 = new OrderVO(LocalDateTime.now(),  customer);
		System.out.println(orderVO2.getOrderNo());
	}

}
