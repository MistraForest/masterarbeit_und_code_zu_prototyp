package de.thb.dim.pizzaPronto;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

/**
 * CustomerVO represents objects of customer.
 * @author Robert Fischer, Gabriele Schmidt
 * @version 3.0
 *
 */
public class CustomerVO  {
	
	private String lastName;
	private String firstName;
	private String gender;
	private LocalDate dateOfBirth;

	/**
	 * initializing constructor
	 * Initialize all instance attributes with values. 
	 * 
	 * @param lastName - Customer's second name
	 * @param firstName - Customer's first name
	 * @param gender - Customer's gender
	 * @param dateOfBirth - Customer's date of birth
	 * 
	 */
	public CustomerVO(String lastName, String firstName, String gender, LocalDate dob) {
		setLastName(lastName);
		setFirstName(firstName);
		setGender(gender);
		setDateOfBirth(dob);

	}
	
	public CustomerVO(String lastName, String firstName, LocalDate dob) {
		this(lastName, firstName, null, dob);

	}
	

	/**
	 * default constructor 
	 * calls initializing constructor with default values for instance attributes
	 * 
	 */
	public CustomerVO() {
		this(null, null, null, null);
	}
	
	
	/**
	 * Returns the birth date in human-readable form.
	 * 
	 * @return - the complete string
	 *  
	 */
	public String dobToString() {
		return dateOfBirth.format(DateTimeFormatter.ofPattern("dd MMM yyyy"));
	}
	
	

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}


	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}
	

	public LocalDate getDateOfBirth() {
		return dateOfBirth;
	}

	
	public void setDateOfBirth(LocalDate dob) {
		this.dateOfBirth = dob;
	}

	
} // end of class