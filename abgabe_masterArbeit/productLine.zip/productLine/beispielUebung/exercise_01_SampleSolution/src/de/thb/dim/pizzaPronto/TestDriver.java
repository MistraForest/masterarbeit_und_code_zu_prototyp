package de.thb.dim.pizzaPronto;

import java.awt.Color;
import java.time.LocalDate;


/**
 * Testdriver of ChefVO, CustomerVO and PizzaVO as well as LocalDate
 * 
 * Special assert statements are used for testing <br>
 * 
 * @author Gabriele Schmidt
 * @version 1.0 09.03.2022
 */
public class TestDriver {
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		LocalDate today = LocalDate.now();
		
		LocalDate dob = LocalDate.of(1990, 5, 24);
		
		//Testing of constructors
		ChefVO myChef = new ChefVO("Bocusen", "Bruno", Color.BLUE);
		CustomerVO myCustomer = new CustomerVO("Mueller", "Monika", "weiblich", LocalDate.of(1997, 1, 1));
		CustomerVO customer = new CustomerVO();
		CustomerVO customer1 = new CustomerVO("Martin","Mampf","maennlich",dob);
		CustomerVO customer2 = new CustomerVO("Maier","Marta","weiblich",dob);
		PizzaVO myPizza = new PizzaVO("Salami", new String[]{"Salami", "Tomate", "Kaese", "Zwiebel"}, 7.5f);
		
		String s[] = {"Salami", "Tomate", "Kaese", "Zwiebel"};
		PizzaVO myPizza2 = new PizzaVO("Salami", s, 7.5f);
		
		
		System.out.println(myChef);
		System.out.println(today); //What is the difference to the output of myChef?
		System.out.println(customer2);
		System.out.println(myPizza);
		
		System.out.println(customer1.dobToString());
	
		printKoch(myChef);
		System.out.println(dob);

		printKunde(customer1);
		customer1.setDateOfBirth(LocalDate.of(1990, 11, 24));
		printKunde(customer1);
		
		printKunde(customer2);
	}
	
	
	// helper methods for formating of the output
	private static void printKunde(CustomerVO kunde) {
		System.out.printf("%s, %s: %s\n",kunde.getLastName(), kunde.getFirstName(), kunde.dobToString());
	}
	
	private static void printKoch(ChefVO koch) {
		System.out.printf("%s, %s\n",koch.getLastName(), koch.getFirstName());
	}
}
