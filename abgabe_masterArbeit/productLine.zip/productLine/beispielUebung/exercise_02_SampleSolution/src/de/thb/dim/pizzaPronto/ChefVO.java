package de.thb.dim.pizzaPronto;
import java.awt.Color;

/**
 * ChefVO represents the objects of chef 
 * @author Robert Fischer, Gabriele Schmidt
 * @version 3.0
 *
 */
public class ChefVO {
	private String lastName;
	private String firstName;
	private Color colorApron;
	
	/**
	 * initializing constructor
	 * Initialize all instance attributes with values. 
	 * 
	 * @param lastName - Chef's second name
	 * @param firstName - Chef's first name
	 * @param colorApron - Color of apron
	 *  
	 */
	public ChefVO(String lastName, String firstName, Color colorApron) {
		setLastName(lastName);
		setFirstName(firstName);
		setColorApron(colorApron);
	}
	
	/**
	 * default constructor 
	 * calls initializing constructor with default values for instance attributes
	 * 
	 */
	public ChefVO() {
		this(null, null,null);
	}
	
	//Standard methode of Java
	
	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((colorApron == null) ? 0 : colorApron.hashCode());
		result = prime * result + ((firstName == null) ? 0 : firstName.hashCode());
		result = prime * result + ((lastName == null) ? 0 : lastName.hashCode());
		return result;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ChefVO other = (ChefVO) obj;
		if (colorApron == null) {
			if (other.colorApron != null)
				return false;
		} else 
			if (!colorApron.equals(other.colorApron))
			return false;
		if (firstName == null) {
			if (other.firstName != null)
				return false;
		} else 
			if (!firstName.equals(other.firstName))
			return false;
		if (lastName == null) {
			if (other.lastName != null)
				return false;
		} else 
		if (!lastName.equals(other.lastName))
			return false;
		return true;
	}
	
	
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "ChefVO [lastName=" + lastName + ", firstName=" + firstName + ", colorApron=" + colorApron + "]";
	}

	
	/// 
	/// Setter und Getter
	///
	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public Color getColorApron() {
		return colorApron;
	}

	public void setColorApron(Color colorApron) {
		this.colorApron = colorApron;
	}
} // End  of class
