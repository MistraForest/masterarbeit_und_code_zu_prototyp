package de.thb.dim.pizzaPronto;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String ingredi [] = {"Salami", "Tomate"};
		
		PizzaVO pizza = new PizzaVO("Salami", ingredi, 12.50f);
		
		PizzaVO pizzaClone;
		
		pizzaClone = pizza.clone();
		
		System.out.println(pizza == pizzaClone);
		System.out.println(pizza.getClass());
		
		System.out.println(pizza instanceof Object);
		
		System.out.println(pizzaClone.equals(pizza));
		System.out.println("Equals: " + pizzaClone.equals(pizza));
		System.out.println("Hashcode: " + (pizzaClone.hashCode() == pizza.hashCode()));
		
		pizzaClone.setPrice(13.00f);
		
		System.out.println("Equals: " + pizzaClone.equals(pizza));
		System.out.println("Hashcode: " + (pizzaClone.hashCode() == pizza.hashCode()));
		
		System.out.println(pizzaClone.toString());
		
		System.out.println(pizzaClone);
		

	}

}
